﻿<#PSScriptInfo

.VERSION 
    1.0

.DATE LAST UPDATED
    06/09/2020

.AUTHOR 
    prmarri

.COMPANYNAME 
    Microsoft Corporation

.COPYRIGHT 
    Copyright (C) Microsoft Corporation. All rights reserved.

.TAGS
    WindowsDefender,DLP

.LICENSEURI 
    //*********************************************************
    //
    //    Copyright (c) Microsoft Corporation. All rights reserved.
    //    This code is licensed under the Microsoft Public License.
    //    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
    //    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
    //    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
    //    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
    //
    //*********************************************************

.PROJECTURI 

.ICONURI 

.EXTERNALMODULEDEPENDENCIES 

.REQUIREDSCRIPTS 

.EXTERNALSCRIPTDEPENDENCIES 

.RELEASENOTES


#>

<# 

.DESCRIPTION
   DLP Self Diagnosing Tool

#> 



### LOGGING RELATED. 
[string]$global:DLP_DIAGNOSE_LOGPATH = join-path ($env:systemdrive) DLPDiagnoseLogs
[string]$global:DLP_DIAGNOSE_FILENAME = "DLPDiagnosing.log"
[string]$global:LogFileName = ""
[string]$global:DLPBackPortFile = "FeatureToastDlpImg.png"
[int]$global:OSBuildNum = 0

[string]$global:CurEngVer = ""
[string]$global:CurMoCAMPVer=""
[string]$global:MIN_MOCAMPVER_NEEDED = "4.18.2005.3"
[string]$global:MIN_ENGINEVER_NEEDED = "1.1.17046.0"


[boolean]$global:bDLPMinReqOS = $true


############################################################################################

### FUNCTION: WRITE CONSOLE OUTPUT IN COLOR

############################################################################################

function Write-ColorOutput($foregroundColor)
{

    LogToFile $args
    # save the current color
    $fc = $host.UI.RawUI.ForegroundColor

    # set the new color
    $host.UI.RawUI.ForegroundColor = $foregroundColor

    # output
    if ($args)
    {
        Write-Output $args
    }
    else
    {
        $input | Write-Output
    }

    # restore the original color
    $host.UI.RawUI.ForegroundColor = $fc
}




############################################################################################

# GENERIC FUNCTION: TO LOG MESSAGES TO A CONFIGURED LOG FILE

############################################################################################

function LogToFile
{
    param($message);

    if (($global:LogFileName -ne "") -and (Test-Path ($global:LogFileName)))
    {
        $currenttime = Get-Date -format u;
        $outputstring = "[" +  $currenttime + "] " + $message;
        $outputstring | Out-File $global:LogFileName -Append;
    }        
}


############################################################################################

### FUNCTION: CHECKS IF DEFENDER AND WD FILTER ARE ACTUALLY RUNNING OR NOT 

############################################################################################
function DisplayMachineInfo
{
    
    Write-ColorOutput Cyan "SYSTEM INFO:"    
    Write-ColorOutput White " "
    Start-Sleep -s 1
    
    try
    {
        $MachineInfo = Get-ComputerInfo
        
    }
    catch [system.exception]
    {
        Write-ColorOutput Red "    Exception while querying computer Info. Skipping it..."  
        return
    }

    $tmp = $MachineInfo.CsDNSHostName
    Write-ColorOutput Yellow "   Computer Name:        $tmp  "
    
    $tmp = $MachineInfo.CsDomain
    Write-ColorOutput White "   Domain:               $tmp  "
    
    $tmp = $MachineInfo.WindowsBuildLabEx
    Write-ColorOutput White "   OS Build Name:        $tmp  "
    
    $tmp = $MachineInfo.WindowsProductName 
    Write-ColorOutput White "   Product Name:         $tmp  "
    
    #$tmp = $MachineInfo.OsHotFixes
    #Write-ColorOutput White "   Hot fix (KB):    $tmp  "    
    
    $tmp = $MachineInfo.CsSystemType
    Write-ColorOutput White "   Device Arch:          $tmp  "
    
    $tmp = $MachineInfo.CsModel
    Write-ColorOutput White "   Model:                $tmp  "
    
    $tmp = $MachineInfo.OsName
    Write-ColorOutput White "   OS Name:              $tmp  "

    $tmp = $MachineInfo.CsPrimaryOwnerName
    Write-ColorOutput White "   Primary User:         $tmp  "
    
    $tmp = $MachineInfo.CsPartOfDomain
    Write-ColorOutput White "   PartOfDomain?:        $tmp  "

}


############################################################################################

### FUNCTION: CHECKS IF DEFENDER AND WD FILTER ARE ACTUALLY RUNNING OR NOT 

############################################################################################

function CheckWDRunning
{

    Write-ColorOutput Cyan "CHECKING IF DEFENDER SERVICE RUNNING:"    
    Write-ColorOutput White " "
        
    try 
    { 
        $defenderOptions = Get-MpComputerStatus -ErrorAction SilentlyContinue
 
        if([string]::IsNullOrEmpty($defenderOptions)) 
        { 
            Write-ColorOutput Red "   Windows Defender Service not running. DLP won't work without WD"   
            $global:bDLPMinReqOS = $false                       

        } 
        else 
        { 
            
            if($defenderOptions.AntivirusEnabled -eq $true)
            {
                Write-ColorOutput Green "    Windows Defender Service running. Looks Good"             
            }
            else
            {
                Write-ColorOutput Red "    Windows Defender Service not running. DLP won't work without WD..."  
                $global:bDLPMinReqOS = $false            
            }
        } 
    } 
    catch [System.Exception]
    {

        Write-ColorOutput Red "Unable to query Windows Defender service status "        
    }
    Start-Sleep -s 1
}



############################################################################################

### FUNCTION: GET THE CURRENT INSTALLED MoCAMP VERSION 

############################################################################################

function GetCurrentMoCAMPVersion
{

    Write-ColorOutput Cyan "CHECKING MOCAMP VERSION:" 
    Write-ColorOutput White " "   
    [string]$MoCAMPInstPath = ""
    [string]$MoCAMPInstVer = ""
    [string]$keyreg = "HKLM:\SOFTWARE\Microsoft\Windows Defender"
    
    
    ## query the MoCAMP installation path
    try
    {
        $MoCAMPInstPath = (Get-ItemProperty -Path $keyreg).InstallLocation       
    }
    catch [System.Exception]
    {
        Write-ColorOutput red "    ERROR: Exception while querying the MoCAMP installation path. Exiting..."
        Write-ColorOutput White " "
    
        return
    }

    ## If NULL string, then something went wrong with the above query. Log and Exit...
    if( $MoCAMPInstPath -eq "" -or $MoCAMPInstPath -eq " ")
    {
        Write-ColorOutput Red "    WARN: Unable to query MoCAMP installation path: $MoCAMPInstPath. Exiting..."
        Write-ColorOutput White " "    
        return
    }


    #Write-ColorOutput Yellow "    INFO: MoCAMP Install path is-> $MoCAMPInstPath"
    Start-Sleep -s 1
    ##Check if it has inbox version or installed MoCAMP version    
    if($MoCAMPInstPath.Contains("platform"))
    {
        $ArrStr = $MoCAMPInstPath.Split("\")
        
        if(-Not($ArrStr.Count -lt 2))
        {
            $MoCAMPInstVer = $ArrStr[$ArrStr.Count-2]
        }

        #Write-ColorOutput White "    MoCAMP version read: $MoCAMPInstVer"
        
        ### strip off the multi install number for the same version
        if($MoCAMPInstVer.Contains("-"))
        {
            $MoCAMPInstVer = $MoCAMPInstVer.Substring(0, $MoCAMPInstVer.IndexOf("-"))
        }
        
        Write-ColorOutput Yellow "    Current MoCAMP version ==> $MoCAMPInstVer"
        $global:CurMoCAMPVer = $MoCAMPInstVer        
    }
    else
    {
        Write-ColorOutput Green "    It has an inbox MoCAMP version"
    }
 
    IsMoCAMPUpdateNeeded
    Start-Sleep -s 1
}




############################################################################################

### FUNCTION: NOTIFIES USER IF MOCAMP UPDATE IS NEEDED

############################################################################################

function IsMoCAMPUpdateNeeded
{
    
    Write-ColorOutput White "    Min MoCAMP version needed : $global:MIN_MOCAMPVER_NEEDED"

    $ArrCurVer = ($global:CurMoCAMPVer).Split(".")
    $ArrMinMoCAMPVer = ($global:MIN_MOCAMPVER_NEEDED).Split(".")

    if(-Not($ArrCurVer.Count -eq $ArrMinMoCAMPVer.count) -or ($ArrCurVer.Count -lt 4))
    {
        Write-ColorOutput Red "    ERROR: SubPart count for Cur-> $ArrCurrVer.count  MinMoCAMPVer->$ArrMinMoCAMPVer.count. Skipping update..."
        return
    }
    
    
    if( ([int]$ArrCurVer[0] -lt [int]$ArrMinMoCAMPVer[0]) -or  
        ([int]$ArrCurVer[1] -lt [int]$ArrMinMoCAMPVer[1]) -or 
        ([int]$ArrCurVer[2] -lt [int]$ArrMinMoCAMPVer[2]) -or 
        ([int]$ArrCurVer[3] -lt [int]$ArrMinMoCAMPVer[3]) )
    {
        Write-ColorOutput Red "    INFO: Current MoCAMP version is old. Might need update for DLP feature to work"
    
    }
    else
    {
        Write-ColorOutput White " "
        Write-ColorOutput Green "    INFO: Min MoCAMP Version requirements met. Looks Good"
    }
}




############################################################################################

### FUNCTION: GET THE CURRENT ENGINE VERSION 

############################################################################################

function GetCurrentEngVersion
{

    Write-ColorOutput Cyan "CHECKING ENGINE VERSION:"    
    Write-ColorOutput White " "
    
    [string]$EngInstPath = ""
    [string]$EngRegKey = "HKLM:\SOFTWARE\Microsoft\Windows Defender\Signature Updates"

    try
    {
        $EngInstPath = (Get-ItemProperty -Path $EngRegKey).SignatureLocation
    }
    catch [System.Exception]
    {
        Write-ColorOutput Red "    ERROR: Exception while querying the Engine installation path.Exiting...."
        return
    }

    [string]$EngInstDll = $EngInstPath + "\mpengine.dll"
    
    #Write-ColorOutput White "    Curr Eng Dll full Path-> $EngInstDll"
    
    if(-Not(Test-Path($EngInstDll)))
    {
        Write-ColorOutput Red "    WARN: Unable to findout the current engine dll. Can't find the Engine version "
        Write-ColorOutput Red "    WARN: Path-> $EngInstDll"        
        $global:bDLPMinReqOS = $false            
        return
    }
    
    try
    {
        $global:CurEngVer = (get-command $EngInstDll).FileVersionInfo.Productversion        
    }
    catch [System.Exception]
    { 
        Write-ColorOutput Red "    ERROR: Exception while querying the engine version. Exiting...."
        return
    }

    Write-ColorOutput Yellow "    Current Installed Engine Version is ===> $global:CurEngVer"
    IsEngineUpdateNeeded
    Start-Sleep -s 1

}




############################################################################################

### FUNCTION: NOTIFIES USER IF ENGINE UPDATE IS NEEDED

############################################################################################

function IsEngineUpdateNeeded
{
    
    Write-ColorOutput White "    Min MoCAMP version needed : $global:MIN_ENGINEVER_NEEDED"

    $ArrCurrEngVer = ($global:CurEngVer).Split(".")
    $ArrMinEngVer = ($global:MIN_ENGINEVER_NEEDED).Split(".")

    if(-Not($ArrCurrEngVer.Count -eq $ArrMinEngVer.count) -or ($ArrCurrEngVer.Count -ne 4))
    {
        Write-ColorOutput Red "    ERROR:Engine ver check. SubPart count for Cur-> $ArrCurrEngVer.count Min-> $ArrMinEngVer.count. Skipping update"
        return
    }

    
    if( ([int]$ArrCurrEngVer[0] -lt [int]$ArrMinEngVer[0]) -or  
        ([int]$ArrCurrEngVer[1] -lt [int]$ArrMinEngVer[1]) -or 
        ([int]$ArrCurrEngVer[2] -lt [int]$ArrMinEngVer[2]) -or 
        ([int]$ArrCurrEngVer[3] -lt [int]$ArrMinEngVer[3]) )
    {
        
        Write-ColorOutput Red "    INFO: Current Engine version is old. Might need update for DLP feature to work"
        $global:bDLPMinReqOS = $false 
    
    }
    else
    {
        Write-ColorOutput White " "
        Write-ColorOutput Green "    INFO: Min Engine Version requirements met. Looks Good"
        
    }
}





############################################################################################

### FUNCTION: CHECKS THE OS VERISON 

############################################################################################

function GetOSBuildNum
{
    
    Write-ColorOutput Cyan "CHECKING OS BUILD VERSION:"
    Write-ColorOutput White " "
    
    try
    {
        $global:OSBuildNum = Invoke-Expression "([System.Environment]::OSVersion.Version).Build"
    }
    catch [system.exception]
    {
        Write-ColorOutput Red "  Exception while querying the OS build version number $Error"
    }
        

    if($OSBuildNum -lt 17763)
    {
        Write-ColorOutput Red "   Build version Num:$global:OSBuildNum  Min OS needed is RS5. Current OS does not support DLP"     
        $global:bDLPMinReqOS = $false       
    }
    elseif($OSBuildNum -eq 17763)
    {
        Write-ColorOutput Green "   Build version Num:$global:OSBuildNum  OS: RS5 Release"            
    }
    elseif($OSBuildNum -eq 18362)
    {
        Write-ColorOutput Green "   Build version Num:$global:OSBuildNum  OS: 19H1 Release"            
            
    }
    elseif($OSBuildNum -eq 18363)
    {
        Write-ColorOutput Green "   Build version Num:$global:OSBuildNum  OS: 19H2 Release"                        
    }
    elseif($OSBuildNum -eq 19041)
    {
        Write-ColorOutput Green "   Build version Num:$global:OSBuildNum  OS: VB Release"                        
    }
    else
    {
        Write-ColorOutput Green "   Build version Num:$global:OSBuildNum  OS: Mn or Fe Release"
    } 

    Start-Sleep -s 1
}




############################################################################################

### FUNCTION: CHECKS THE SENSE ONBOARD REG ARE ALREADY PRESENT OR NOT

############################################################################################

function CheckSenseOnBoardReg
{
    Write-ColorOutput Cyan "CHECKING SENSE ONBOARDING REGS:"
    Write-ColorOutput White " "
    
    Write-ColorOutput White "   Reg1 check-->"
    ### ATP Reg1 check
    try
    {  
        $a = Get-ItemProperty -Path "HKLM:SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection" | Select-Object -ExpandProperty "GroupIds" -ErrorAction SilentlyContinue 

        if($a -eq $null)
        {
            Write-ColorOutput Yellow "   Missing ATP Reg entry. Key='GroupIds' Value='EnableDlpEnforcement' under 'HKLM:SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection'"
            Write-ColorOutput Red "   Please add above mentioned Registry entry without which DLP feature may not work for older OS [RS5 or 19H1]"
            
        }
        else
        {
            if($a -eq "EnableDlpEnforcement")
            {
                Write-ColorOutput Green "   Reg1->GroupIds (ATP)Regkey set properly for EnableDlpEnforcement. Looks Good"
            }
            else
            {
                Write-ColorOutput Yellow "   GroupIds (ATP)Regkey exists but not properly set as EnableDlpEnforcement"
            }
        }
    }
    catch [System.exception]
    {
        Write-ColorOutput Red "   Exception while querying or adding reg keys to onboard SENSE OS"
    }


    Write-ColorOutput White " "
    Write-ColorOutput White "   Reg2 check-->"
    ### ATP Reg2 check
    try
    {
        if(-Not(Test-Path("HKLM:SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection\DeviceTagging")))
        {
            
            Write-ColorOutput Yellow "   Missing ATP Reg Entry: Key='DLP' Value='EnableDlpEnforcement' under 'HKLM:SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection\DeviceTagging'"
            Write-ColorOutput Red "   Please add above mentioned Registry entry without which DLP feature may not work for older OS [RS5 or 19H1]"
            return
        }
        
        
        $b = Get-ItemProperty -Path "HKLM:SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection\DeviceTagging" | Select-Object -ExpandProperty "DLP" -ErrorAction SilentlyContinue 
        if($b -eq $null)
        {
            Write-ColorOutput Yellow "   Missing ATP Reg Entry: Key='DLP' Value='EnableDlpEnforcement' under 'HKLM:SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection\DeviceTagging'"
            Write-ColorOutput Red "   Please add above mentioned Registry entry without which DLP feature may not work"
            
        }
        else
        {
            if($b -eq "EnableDlpEnforcement")
            {
                Write-ColorOutput Green "   Reg2->DLP (ATP)Regkey set properly for EnableDlpEnforcement. Looks Good"
            }
            else
            {
                Write-ColorOutput Green "   DLP (ATP)Regkey exists but not properly as EnableDlpEnforcement"
            }
        }
    }
    catch [System.exception]
    {
        Write-ColorOutput Red "   Exception while querying or adding reg keys to onboard SENSE OS"
    }

    Start-Sleep -s 1
}





############################################################################################

### FUNCTION: CHECKS IF DLP FEATURE IS ENABLED ON THIS MACHINE

############################################################################################

function CheckDLPEnabled
{

    Write-ColorOutput Cyan "CHECK REG IF DLP FEATURE IS ENABLED:"
    Write-ColorOutput White " "
        
    try
    {
        if(-Not(Test-Path("HKLM:SOFTWARE\Microsoft\Windows Defender\Features")))
        {
            
            Write-ColorOutput Red "   ERROR: Do not find the reg path 'SOFTWARE\Microsoft\Windows Defender\Features'"
            return
        }
        
        
        $b = Get-ItemProperty -Path "HKLM:SOFTWARE\Microsoft\Windows Defender\Features" | Select-Object -ExpandProperty "SenseDlpEnabled" -ErrorAction SilentlyContinue 
        if($b -eq $null)
        {
            Write-ColorOutput Red "  Do not find the DLP enable reg key. Key=SenseDlpEnabled  path: 'HKLM:SOFTWARE\Microsoft\Windows Defender\Features'"
            $global:bDLPMinReqOS = $false
            return            
        }
        else
        {
            if($b -eq 1)
            {
                Write-ColorOutput Green "   Enabled DLP reg key is enabled. Looks Good"
            }
            else
            {
                Write-ColorOutput Red "   Sense is not enabled for the DLP feature. Please contact your administrator"
                $global:bDLPMinReqOS = $false
            }
               
        }
    }
    catch [System.exception]
    {
        Write-ColorOutput Red "   Exception while querying or adding reg keys to onboard SENSE OS"
    }

    Start-Sleep -s 1
}



############################################################################################

### FUNCTION: CHECKS IF UX CONFIGURATION SETTINGS ARE ENABLED OR DISABLED

############################################################################################

function CheckUXConfiguraitonSettings
{

    Write-ColorOutput Cyan "CHECKING UX CONFIGURATION REG SETTINGS:"
    Write-ColorOutput White " "
    

    ### Post June 2020 MoCAMP, these GP controlled registries will not impact DLP toast display
    ## However, have them checked and display info to the user 
    ## Below is for UILockdown registry
    Write-ColorOutput White "   Reg1 -> checking..."
    try
    {
        if(-Not(Test-Path("HKLM:SOFTWARE\Policies\Microsoft\Microsoft Antimalware\UX Configuration")))
        {
            
            Write-ColorOutput Yellow "   INFO: Do not find the reg path 'HKLM:SOFTWARE\Policies\Microsoft\Microsoft Antimalware\UX Configuration'"
            Write-ColorOutput Yellow "   INFO: Goes with default behavior which is to enable toast. If you still see issues with toasts, please contact your administrator"
            return
        }
        
        
        $b = Get-ItemProperty -Path "HKLM:SOFTWARE\Policies\Microsoft\Microsoft Antimalware\UX Configuration" | Select-Object -ExpandProperty "UILockdown" -ErrorAction SilentlyContinue 
        if($b -eq $null)
        {
            Write-ColorOutput Yellow "   Do not find 'UILockdown' registry under the path 'HKLM:SOFTWARE\Policies\Microsoft\Microsoft Antimalware\UX Configuration'"
            Write-ColorOutput Yellow "   INFO: Goes with default behavior which is to enable toasts. If you still see issues with toasts, please contact your administrator"
            return
            
        }
        else
        {
           if($b -eq 0)
           {

                Write-ColorOutput Green "   Group Policy Notification settings for UI lockdown is disabled. Looks Good"                                
                
           }
           else
           {
                Write-ColorOutput Red "   WARNING: Group policy settings for UILockdown is enabled. "                 
                Write-ColorOutput Yellow "   Please contact your administrator in case no DLP toast is observed"
                
           }
        }
    }
    catch [System.exception]
    {
        Write-ColorOutput Red "   Exception while querying the GPM UILockdown reg settings "
    }

    Start-Sleep -s 1
    Write-ColorOutput White " "
    Write-ColorOutput White " "


    ### Do the same reg check but this time under WDAV reg path
    try
    {
        if(-Not(Test-Path("HKLM:SOFTWARE\Microsoft\Windows Defender\UX Configuration")))
        {
            
            Write-ColorOutput Yellow "   INFO: Do not find the reg path 'HKLM:SOFTWARE\Microsoft\Windows Defender\UX Configuration'"
            Write-ColorOutput Yellow "   INFO: Goes with default behavior which is to enable toast. If you still see issues with toasts, please contact your administrator"
            return
        }
        
        
        $b = Get-ItemProperty -Path "HKLM:SOFTWARE\Microsoft\Windows Defender\UX Configuration" | Select-Object -ExpandProperty "UILockdown" -ErrorAction SilentlyContinue 
        if($b -eq $null)
        {
            Write-ColorOutput Yellow "   Do not find 'UILockdown' registry under the path 'HKLM:SOFTWARE\Microsoft\Windows Defender\UX Configuration'"
            Write-ColorOutput Yellow "   INFO: Goes with default behavior which is to enable toasts. If you still see issues with toasts, please contact your administrator"
            return
            
        }
        else
        {
           if($b -eq 0)
           {

                Write-ColorOutput Green "   WDAV settings for UI lockdown is disabled. Looks Good"                                
                
           }
           else
           {
                Write-ColorOutput Red "   WARNING: WDAV settings for UILockdown is enabled. "                 
                Write-ColorOutput Yellow "   Please contact your administrator in case no DLP toast is observed"
                
           }
        }
    }
    catch [System.exception]
    {
        Write-ColorOutput Red "   Exception while querying the WDAV UILockdown reg settings "
    }

    Start-Sleep -s 1
    Write-ColorOutput White " "
    Write-ColorOutput White " "





    ### Post June 2020 MoCAMP, these GP controlled registries will not impact DLP toast display
    ## However, have them checked and display info to the user 
    ## Below is for Notification_Suppress registry
    Write-ColorOutput White "   Reg2 -> checking..."
    try
    {
        
        $b = Get-ItemProperty -Path "HKLM:SOFTWARE\Policies\Microsoft\Microsoft Antimalware\UX Configuration" | Select-Object -ExpandProperty "Notification_Suppress" -ErrorAction SilentlyContinue 
        if($b -eq $null)
        {
            Write-ColorOutput Yellow "   Do not find 'Notification_Suppress' registry under the path 'HKLM:SOFTWARE\Policies\Microsoft\Microsoft Antimalware\UX Configuration'"
            Write-ColorOutput Yellow "   INFO: Goes with default behavior which is to enable toast. If you still see issues with toasts, please contact your administrator"
            return
            
        }
        else
        {
           if($b -eq 0)
           {

                Write-ColorOutput Green "   Group Policy Notification settings for Notification supress is disabled. Looks Good"                                
                
           }
           else
           {
                Write-ColorOutput Red "   WARNING: Group policy settings for Notification Supress is enabled "                 
                Write-ColorOutput Yellow "   Please contact your administrator in case no DLP toast is observed"
                
           }
        }
    }
    catch [System.exception]
    {
        Write-ColorOutput Red "   Exception while querying the Notification_Suppress reg settings "
    }


    ## do the same reg check but this time under WDAV reg path
    try
    {
        
        $b = Get-ItemProperty -Path "HKLM:SOFTWARE\Microsoft\Windows Defender\UX Configuration" | Select-Object -ExpandProperty "Notification_Suppress" -ErrorAction SilentlyContinue 
        if($b -eq $null)
        {
            Write-ColorOutput Yellow "   Do not find 'Notification_Suppress' registry under the path 'HKLM:SOFTWARE\Microsoft\Windows Defender\UX Configuration'"
            Write-ColorOutput Yellow "   INFO: Goes with default behavior which is to enable toast. If you still see issues with toasts, please contact your administrator"
            return
            
        }
        else
        {
           if($b -eq 0)
           {

                Write-ColorOutput Green "   WDAV Notification settings for Notification supress is disabled. Looks Good"                                
                
           }
           else
           {
                Write-ColorOutput Red "   WARNING: WDAV settings for Notification Supress is enabled "                 
                Write-ColorOutput Yellow "   Please contact your administrator in case no DLP toast is observed"
                
           }
        }
    }
    catch [System.exception]
    {
        Write-ColorOutput Red "   Exception while querying the Notification_Suppress reg settings "
    }


    Start-Sleep -s 1

}




############################################################################################

### FUNCTION: CHECKS IF TOAST SETTINGS ARE ENABLED OR DISABLED

############################################################################################

function CheckNotificationSettings
{

    Write-ColorOutput Cyan "CHECKING NOTIFICATION SETTINGS:"
    Write-ColorOutput White " "
        

    #### Reg1 check
    Write-ColorOutput White "   Reg1 -> checking..."
    try
    {
        if(-Not(Test-Path("HKCU:SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications")))
        {
            
            Write-ColorOutput Yellow "   WARN: Do not find the reg path 'HKCU:SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications'"
            return
        }
        
        
        $b = Get-ItemProperty -Path "HKCU:SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications" | Select-Object -ExpandProperty "ToastEnabled" -ErrorAction SilentlyContinue 
        if($b -eq $null)
        {
            Write-ColorOutput Yellow "   Missing ToastEnabled registry under the path 'HKCU:SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications'"
            Write-ColorOutput Yellow "   WARN: If DLP toasts missing, please make sure 'Settings->System->Notification & Action->Get notifications from apps' setting is enabled "            
            return
            
        }
        else
        {
           if($b -eq 1)
           {
                Write-ColorOutput Green "   Reg1 -> Notification settings for toast is enabled. Looks Good"                
           }
           else
           {
                Write-ColorOutput Red "   WARNING: Notification settings for toast is disabled. You may not see DLP toasts for  block/warn operations"                 
                Write-ColorOutput Yellow "   Goto Settings -> System -> Notification & Action -> Enable the Notification button for better DLP experience"
           }
        }
    }
    catch [System.exception]
    {
        Write-ColorOutput Red "   Exception while querying the toast settings "
    }

    Start-Sleep -s 1
    

    Write-ColorOutput White " "
    #### Reg2 check
    Write-ColorOutput White "   Reg2 -> checking..."
    try
    {
        if(-Not(Test-Path("HKCU\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\PushNotifications")))
        {            
            Write-ColorOutput Yellow "   WARN: Do not find the reg path 'HKCU\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\PushNotifications'"
            Write-ColorOutput Green "   Reg2 -> Default behavior is to enable the toasts. Looks Good"                
            return
        }
        
        
        $b = Get-ItemProperty -Path "HKCU\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\PushNotifications" | Select-Object -ExpandProperty "NoToastApplicationNotification" -ErrorAction SilentlyContinue 
        if($b -eq $null)
        {
            Write-ColorOutput Yellow "   Missing NoToastApplicationNotification registry under the path 'HKCU\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\PushNotifications'"
            Write-ColorOutput Green "   INFO: Policy not set to disable DLP toasts, looks good. If still issue with toasts, please contact your administrator"            
            return            
        }
        elseif($b -eq 1)
        {
            Write-ColorOutput Yellow "   INFO: Registry 'NoToastApplicationNotification' is set under the path 'HKCU\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\PushNotifications'"
            Write-ColorOutput Red "   WARN: Policies set to disable toast notification. You may not see DLP toasts for block/warn operations. Please contact your administrator"                                 
        }
        
    }
    catch [System.exception]
    {
        Write-ColorOutput Red "   Exception while querying the toast settings "
    }

}




############################################################################################

### FUNCTION: CHECKS IF DLP SHOW DIALOG REG IS ENABLED OR NOT 

############################################################################################

function CheckDLPShowDialog
{

    Write-ColorOutput Cyan "CHECKING DLP DIALOG BOX SETTINGS:"
    Write-ColorOutput White " "
    
    try
    {
        if(-Not(Test-Path("HKLM:software\microsoft\windows defender\Miscellaneous Configuration")))
        {
            
            Write-ColorOutput Red "   ERROR: Reg path not found. HKLM:software\microsoft\windows defender\Miscellaneous Configuration'"
            return
        }
        
        
        $b = Get-ItemProperty -Path "HKLM:software\microsoft\windows defender\Miscellaneous Configuration" | Select-Object -ExpandProperty "DlpShowDialogs" -ErrorAction SilentlyContinue 
        if( ($b -eq $null) -or ($b -eq 1) )
        {

            if($b -eq $null)
            {
                Write-ColorOutput Yellow "   INFO: DlpShowDialogs is missing. Default behavior is to show error dialog boxes for DLP operations "            
            }
            else
            {
                Write-ColorOutput Yellow "   INFO: DlpShowDialogs is set to 1. Shows the error dialog boxes for DLP operations "            
            }
            return
        }
        else
        {
            Write-ColorOutput Yellow "   INFO: DlpShowDialogs reg is set to 0. Error dialog box will be suppressed for DLP operations "                                 
           
        }
    }
    catch [System.exception]
    {
        Write-ColorOutput Red "   Exception while querying the toast settings "
    }

    Start-Sleep -s 1
}




############################################################################################

### FUNCTION: CHECKS IF INBOX OS BACKPORT CHANGES ARE AVAILABLE OR MISSING ON THIS PC

############################################################################################

function DLPInboxChangesBackportedToOS
{
    Write-ColorOutput Cyan "DLP INBOX BACKPORT CHANGE VERIFICATION:"
    Write-ColorOutput White " "
    
    [string]$BackPortFile = join-path $env:windir "System32"
    $BackPortFile = join-path $BackPortFile $global:DLPBackPortFile 


    #Write-ColorOutput White " Filepath is: $BackPortFile "
    if(Test-Path($BackPortFile))
    {        
        Write-ColorOutput Green "   DLP Inbox backport changes. Looks good"
        Write-ColorOutput White " "   
        ## Check if Mp capability reg is set properly 
        MpCapabilityCheck
    }
    else
    {
        Write-ColorOutput Red "   DLP Inbox backport changes seems missing on this PC. DLP user experience may not be as expected on this device"
        Write-ColorOutput Yellow "   Windows Upgrade might be helpful"
    }

    Start-Sleep -s 1
 }




############################################################################################

### FUNCTION: CHECKS THE MP CAPABILITY FLAG FROM THE REGISTRY

############################################################################################

function MpCapabilityCheck
{

    Write-ColorOutput Cyan "MPCAPABILITY CONFIGURATION CHECK:"
    Write-ColorOutput White " "
    
    try
    {

        if(-Not(Test-Path("HKLM:SOFTWARE\Microsoft\Windows Defender\Features")))
        {
            
            Write-ColorOutput Red "   ERROR: Do not find the reg path 'SOFTWARE\Microsoft\Windows Defender\Features'"
            return
        }
        
        
        $b = Get-ItemProperty -Path "HKLM:SOFTWARE\Microsoft\Windows Defender\Features" | Select-Object -ExpandProperty "MpCapability" -ErrorAction SilentlyContinue 
        if($b -eq $null)
        {
            Write-ColorOutput Yellow "   Missing MpCapability registry under the path 'HKLM:SOFTWARE\Microsoft\Windows Defender\Features'"
            Write-ColorOutput Red "   DLP may not work as expected. Machine REBOOT might help..."
            return
            
        }
        else
        {
           Write-ColorOutput Yellow "   Capability key: $b"
           if($b[0] -ne 1)
           {
                Write-ColorOutput Red "   MpCapability reg key is not set as expected. DLP may not give best user experience"                
           }
           else
           {
                Write-ColorOutput Green "   MpCapability reg key is set as needed. Looks Good"                 
           }
        }
    }
    catch [System.exception]
    {
        Write-ColorOutput Red "   Exception while querying or adding reg keys to onboard SENSE OS"
    }

    Start-Sleep -s 1
}


############################################################################################

### FUNCTION: CHECKS THE CONFIGURATION FOR BEHAVIOUR MONITORING UNDER POLICY MANAGER

############################################################################################

function CheckBMConfig_PolManager
{

    Write-ColorOutput Cyan "BEHAVIOR MONITORING CONFIGURATION CHECK [POLICY MANAGER]:"
    Write-ColorOutput White " "
    
    try
    {

        Write-ColorOutput White "   Checking Behavior and Realtime Monitoring registry settings under policy manager "

        if(-Not(Test-Path("HKLM:SOFTWARE\Policies\Microsoft\Windows Defender\Policy Manager")))
        {
            
            Write-ColorOutput Red "   INFO: Did not find the reg path 'SOFTWARE\Policies\Microsoft\Windows Defender\Policy Manager'"
            return
        }
        
        
        $a = Get-ItemProperty -Path "HKLM:SOFTWARE\Policies\Microsoft\Windows Defender\Policy Manager" | Select-Object -ExpandProperty "AllowBehaviorMonitoring" -ErrorAction SilentlyContinue 
        if($a -eq $null)
        {
            Write-ColorOutput Yellow "   INFO: Missing Allow Behavior Monitoring regkey under the path 'HKLM:SOFTWARE\Policies\Microsoft\Windows Defender\Policy Manager'"
            
        }
        else
        {
           if($a -eq 1)
           {

                Write-ColorOutput Green "   Behavior Monitoring settings under policy manager is enabled. Looks Good"                                
                
           }
           else
           {
                Write-ColorOutput Red "   WARN: Behavior Monitoring settings under policy manager is disabled"                                 
                
           }
        }
        Write-ColorOutput White " "
        

        $b = Get-ItemProperty -Path "HKLM:SOFTWARE\Policies\Microsoft\Windows Defender\Policy Manager" | Select-Object -ExpandProperty "AllowRealtimeMonitoring" -ErrorAction SilentlyContinue 
        if($b -eq $null)
        {
            Write-ColorOutput Yellow "   INFO: Missing Allow RealTime Monitoring regkey under the path 'HKLM:SOFTWARE\Policies\Microsoft\Windows Defender\Policy Manager'"            
        }
        else
        {
           if($a -eq 1)
           {

                Write-ColorOutput Green "   Realtime Monitoring settings under policy manager is enabled. Looks Good"                                
                
           }
           else
           {
                Write-ColorOutput Red "   WARN: Realtime Monitoring settings under policy manager is disabled"                                 
                
           }
        }
        Write-ColorOutput White " "
        Write-ColorOutput White " "

        
        
    }
    catch [System.exception]
    {
        Write-ColorOutput Red "   Exception while querying or adding reg keys to onboard SENSE OS"
    }

    Start-Sleep -s 1
}



############################################################################################

### FUNCTION: CHECKS THE POLICY CONFIGURATION FOR BEHAVIOUR MONITORING

############################################################################################

function CheckBMConfig
{

    Write-ColorOutput Cyan "BEHAVIOR MONITORING CONFIGURATION CHECK:"
    Write-ColorOutput White " "
    
    try
    {

        Write-ColorOutput White "   Checking Behavior and Realtime Monitoring registry settings under RTP policies..."

        if(-Not(Test-Path("HKLM:SOFTWARE\Policies\Microsoft\Windows Defender\real-time protection")))
        {
            
            Write-ColorOutput Red "   ERROR: Do not find the reg path 'SOFTWARE\Policies\Microsoft\Windows Defender\real-time protection'"
            return
        }
        
        
        $a = Get-ItemProperty -Path "HKLM:SOFTWARE\Policies\Microsoft\Windows Defender\real-time protection" | Select-Object -ExpandProperty "DisableBehaviorMonitoring" -ErrorAction SilentlyContinue 
        if($a -eq $null)
        {
            Write-ColorOutput Yellow "   Missing Behavior Monitoring regkey under the path 'HKLM:SOFTWARE\Policies\Microsoft\Windows Defender\real-time protection'"
            Write-ColorOutput Yellow "   DLP user experience may not be as expected "            
        }

        $b = Get-ItemProperty -Path "HKLM:SOFTWARE\Policies\Microsoft\Windows Defender\real-time protection" | Select-Object -ExpandProperty "DisableRealTimeMonitoring" -ErrorAction SilentlyContinue 
        if($b -eq $null)
        {
            Write-ColorOutput Yellow "   Missing RealTime Monitoring regkey under the path 'HKLM:SOFTWARE\Policies\Microsoft\Windows Defender\real-time protection'"
            Write-ColorOutput Red "   DLP toasts may not work on this PC"
            $global:bDLPMinReqOS = $false            
            return
        }
        
        Write-ColorOutput Green "   Reg settings for Behaviour and Realtime Monitoring are enabled. Looks Good "           
        
    }
    catch [System.exception]
    {
        Write-ColorOutput Red "   Exception while querying or adding reg keys to onboard SENSE OS"
    }

    Start-Sleep -s 1
}




# function to read Registry Value
function Get-RegistryValue { param (
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$Path,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$Value
    )

    if (Test-Path -path $Path) {
        return Get-ItemProperty -Path $Path | Select-Object -ExpandProperty $Value -ErrorAction silentlycontinue
    } else {
        return $false
    }
}





############################################################################################

### FUNCTION: CHECKS IF DLP POLICIES CONFIGURED FOR A SPECIFIC DLP ACTION TYPE

############################################################################################

function policychecker($CheckPolicyLogFile, $StrB, $StrW, $StrA, $Category)
{

    if ( (Get-Content -Path $CheckPolicyLogFile).Contains($StrB) -and
         (Get-Content -Path $CheckPolicyLogFile).Contains($StrW) -and
         (Get-Content -Path $CheckPolicyLogFile).Contains($StrA) )
            
    {
        Write-ColorOutput Yellow "   DLP Feature: $Category"
        Write-ColorOutput Green "    -- All Block/Warn/Audit policies found"
    }
    elseif(
            (Get-Content -Path $CheckPolicyLogFile).Contains($StrB) -or
            (Get-Content -Path $CheckPolicyLogFile).Contains($StrW) -or
            (Get-Content -Path $CheckPolicyLogFile).Contains($StrA) )
             
    {
    
        Write-ColorOutput Yellow "   DLP Feature: $Category"
        if(-Not((Get-Content -Path $CheckPolicyLogFile).Contains($StrB)))
       {
            
            Write-ColorOutput Yellow "   -- Block policy not found"
       }
       else
       {
            Write-ColorOutput Green "   -- Block policy found"
       }

       if(-Not((Get-Content -Path $CheckPolicyLogFile).Contains($StrW)))
       {
            Write-ColorOutput Yellow "   -- Warn policy not found"
            
       }
       else
       {
            Write-ColorOutput Green "   -- Warn policy found"
       }


       if(-Not((Get-Content -Path $CheckPolicyLogFile).Contains($StrA)))
       {
            Write-ColorOutput Yellow "   -- Audit policy not found"
       }
       else
       {
            Write-ColorOutput Green "   -- Audit policy found"
       }           

    }
    else
    {   
        Write-ColorOutput Yellow "Feature: $Category "
        Write-ColorOutput Red "  - No policies found for this feature"
    }
}





############################################################################################

### FUNCTION: FUNCTION TO CHECK MACHINE LEVEL DLP POLICES

############################################################################################

function CheckDeviceDLPPolicies($CheckPolicyLogFile)
{
        
        if(Test-Path $CheckPolicyLogFile)
        {
            $USBBlock = 'CopyToRemovableMedia":{"EnforcementMode":3}'
            $USBWarn = 'CopyToRemovableMedia":{"EnforcementMode":2}'
            $USBAudit = 'CopyToRemovableMedia":{"EnforcementMode":1}'
            policychecker $CheckPolicyLogFile $USBBlock $USBWarn $USBAudit "CopyToRemovableMedia"
            Write-ColorOutput White " "
            

            $NetworkBlock = 'CopyToNetworkShare":{"EnforcementMode":3}'
            $NetworkWarn = 'CopyToNetworkShare":{"EnforcementMode":2}'
            $NetworkAudit = 'CopyToNetworkShare":{"EnforcementMode":1}'
            policychecker $CheckPolicyLogFile $NetworkBlock $NetworkWarn $NetworkAudit "CopyToNetworkShare"
            Write-ColorOutput White " " 

            
            $ClipboardBlock = 'CopyToClipboard":{"EnforcementMode":3}'
            $ClipboardWarn = 'CopyToClipboard":{"EnforcementMode":2}'
            $ClipboardAudit = 'CopyToClipboard":{"EnforcementMode":1}'
            policychecker $CheckPolicyLogFile $ClipboardBlock $ClipboardWarn $ClipboardAudit "CopyToClipboard"
            Write-ColorOutput White " "


            $PrintBlock = 'Print":{"EnforcementMode":3}'
            $PrintWarn = 'Print":{"EnforcementMode":2}'
            $PrintAudit = 'Print":{"EnforcementMode":1}'
            policychecker $CheckPolicyLogFile $PrintBlock $PrintWarn $PrintAudit "Print"
            Write-ColorOutput White " "


            $UnallAppBlock = 'AccessByUnallowedApps":{"EnforcementMode":3}'
            $UnallAppWarn = 'AccessByUnallowedApps":{"EnforcementMode":2}'
            $UnallAppAudit = 'AccessByUnallowedApps":{"EnforcementMode":1}'
            policychecker $CheckPolicyLogFile $UnallAppBlock $UnallAppWarn $UnallAppAudit "AccessByUnallowedApps"
            Write-ColorOutput White " "
           
        }
        else
        {
            Write-ColorOutput "    WARN: DLP device policy log not generated "
            return
        }
}




############################################################################################

### FUNCTION: FUNCTION TO POPULATE MACHINE LEVEL DLP RULES AND POLICES

############################################################################################

function PopulateDLPPolicies($CheckPolicyLogFile)
{

    Write-ColorOutput Cyan "POPULATE DLP POLICES:"
    if(-Not(Test-Path($CheckPolicyLogFile)))
    {
        Write-ColorOutput Red "dlp policy file not found. Can't popluate policies. Skipping..."
        return        
    }


    $line = Get-Content $CheckPolicyLogFile     

    ## Check if any apps are configured as enlightened apps
    $indx = $line.IndexOf("EnlightenedApplications")    
    if($indx -ge 0)
    {
        Write-ColorOutput white " "
        Write-ColorOutput yellow "ENLIGHTENED APPLICATIONS:"
        Write-ColorOutput white "------------------------"
        $line = $line.Substring($indx)        
        $startIndx = $line.IndexOf('[')
        $endIndx = $line.IndexOf(']')

        $enlightenStr = $line.Substring($startIndx+1, $endIndx - $startIndx + 1)
        $line = $line.Substring($endIndx)        
        #Write-ColorOutput yellow "enlighten string is $enlightenStr "
        
        $arr = $enlightenStr.Split('}')       
        for($i = 0; $i -lt $arr.count -1; $i++) 
        {
            if($i -eq 0) 
            {
                $temp = $arr[$i].Substring(1)
            }
            else
            {
                $temp = $arr[$i].Substring(2)
            }
            Write-ColorOutput white " $temp"
        }
    }


            
    $indx = $line.IndexOf("UnallowedApplications")    
    if($indx -ge 0)
    {
        Write-ColorOutput white " "
        Write-ColorOutput yellow "UNALLOWED APPLICATIONS:"
        Write-ColorOutput white "--------------------"
    
        $line = $line.Substring($indx)        
        $startIndx = $line.IndexOf('[')
        $endIndx = $line.IndexOf(']')

       
        $unallowedStr = $line.Substring($startIndx+1, $endIndx - $startIndx + 1)
        $line = $line.Substring($endIndx)          
        
        #Write-ColorOutput yellow "Unallowed apps string is $unallowedStr "
                       
        $arr = $unallowedStr.Split('}')
        for($i = 0; $i -lt $arr.count - 1; $i++) 
        {
            if($i -eq 0) 
            {
                $temp = $arr[$i].Substring(1)
            }
            else
            {
                $temp = $arr[$i].Substring(2)
            }
            Write-ColorOutput white " $temp"
        }    
    }      

         

    $indx = $line.IndexOf("UnallowedBrowsers")    
    if($indx -ge 0)
    {
        Write-ColorOutput white " "
        Write-ColorOutput yellow "UNALLOWED BROWSERS:"
        Write-ColorOutput white "------------------"
        $line = $line.Substring($indx)        
        $startIndx = $line.IndexOf('[')
        $endIndx = $line.IndexOf(']')

        $unallowedBrowserStr = $line.Substring($startIndx+1, $endIndx - $startIndx + 1)
        $line = $line.Substring($endIndx)        

        #Write-ColorOutput yellow "Unallowed browser string is $unallowedBrowserStr "
        
        $arr = $unallowedBrowserStr.Split('}')
        for($i = 0; $i -lt $arr.count - 1; $i++) 
        {
            if($i -eq 0) 
            {
                $temp = $arr[$i].Substring(1)
            }
            else
            {
                $temp = $arr[$i].Substring(2)
            }
            Write-ColorOutput white " $temp"
        }            
    }


    $indx = $line.IndexOf('"Policies":')    
    if($indx -ge 0)
    {

        $line = $line.Substring($indx)        
        $startIndx = $line.IndexOf('"Id"')
        $endIndx = $line.IndexOf(']')

        $PoliciesStr = $line.Substring($startIndx, $endIndx - $startIndx + 1)
        $line = $line.Substring($endIndx)        

        #Write-ColorOutput yellow "Unallowed browser string is $PoliciesStr "
        
        $arr = $PoliciesStr.Split(',')
        if($arr.count -gt 0)
        {
            Write-ColorOutput white " "
            Write-ColorOutput yellow "CURRENT POLICIES APPLIED:" 
            Write-ColorOutput white "------------------------"           
            Write-ColorOutput white " "
        }


        foreach($aaa in $arr) 
        {
            if($aaa.contains('"Id"')) 
            {
                Write-ColorOutput white "   ---------------------"                
                $aaa = $aaa.substring(1)
                Write-ColorOutput white "   $aaa"
                
            }
            elseif($aaa.contains('PolicyName')) 
            {
                Write-ColorOutput yellow "   $aaa"                                        
            }
            elseif($aaa.contains('RuleName')) 
            {
                Write-ColorOutput white "   $aaa"
                Write-ColorOutput white " "                
                
            }
            elseif($aaa.contains('CloudEgress')) 
            {
                $aaa = $aaa.substring(0, $aaa.length - 3)
                Write-ColorOutput white "   -> $aaa"
                Write-ColorOutput white "   ------------------"                
                Write-ColorOutput white " "
                
            }
            else
            {
                if($aaa.contains('"Actions":{')) 
                {
                    $aaa = $aaa.replace('"Actions":{', '')
                    Write-ColorOutput white "   -> $aaa"                    
                }
                Write-ColorOutput white "   -> $aaa"
            }
        }            
    }
   
    
    if(Test-Path($CheckPolicyLogFile))
    {
        Remove-Item $CheckPolicyLogFile -Force -ErrorAction SilentlyContinue
    }

    Write-ColorOutput Cyan "POPULATE DLP POLICES COMPLETE:"    

}


############################################################################################

### FUNCTION: READ DLP POLICY FROM REG KEY ON THE DEVICE AND THEN DECOMPRESSES IT

############################################################################################

function ReadDlpPolicy($policyName)
{
    $byteArray = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection' -Name $policyName
    $memoryStream = New-Object System.IO.MemoryStream(,$byteArray)
    $deflateStream = New-Object System.IO.Compression.DeflateStream($memoryStream,  [System.IO.Compression.CompressionMode]::Decompress)
    $streamReader =  New-Object System.IO.StreamReader($deflateStream, [System.Text.Encoding]::Unicode)
    $policyStr = $streamReader.ReadToEnd()
    $policy = $policyStr | ConvertFrom-Json

    
    $policyBodyCmd = ($policy.body | ConvertFrom-Json).cmd 

    Set-Content -Path "dlppol.txt" $policyBodyCmd 
    CheckDeviceDLPPolicies("dlppol.txt")
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White ""
    
    Write-ColorOutput White ""
    Write-ColorOutput White ""
    Write-ColorOutput White ""
    Write-ColorOutput White "------------------------------------"
    ## Now populate all the dlp policies and rules
    PopulateDLPPolicies("dlppol.txt")    
    
}


############################################################################################

### FUNCTION: CHECKS THE BEHAVIOUR MONITOR CONFIGUREAITON 

############################################################################################

function CheckDLPPolices
{

    Write-ColorOutput Cyan "CHECK IF DLP POLICIES ARE SET ON THIS DEVICE:"
    Write-ColorOutput White " "
    Start-Sleep -s 1

    # Dump DLP related policy information from registry
    if (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection" -Value dlpPolicy) 
    {
        ReadDlpPolicy dlppolicy
		#ReadDlpPolicy dlpSensitiveInfoTypesPolicy
	} 
    else 
    {
		Write-Coloroutput Red "    INFO: No DLP polices found in the registry of this machine"
	}

    Start-Sleep -s 1
}




############################################################################################

### FUNCTION: CHECK IF THE BUILD IS PR SIGNED OR NOT 

############################################################################################

function CheckBuildPRSigned
{
    Write-ColorOutput Cyan "CHECK IF OS BUILD IS SIGNED OR NOT:"
    Write-ColorOutput White " "

    [string]$Sys32Path = join-path $env:windir "System32"
    $File1 = $Sys32Path + "\services.exe"
    $File2 = $Sys32Path + "\crypt32.dll"
    $File3 = $Sys32Path + "\wow64.dll"   
    $TargetFile = ""
    
    if(Test-Path($File1))
    {
        $TargetFile = $File1
    }
    
    if(($TargetFile -eq "") -and (Test-Path($File2)))
    {
        $TargetFile = $File2
    }
    if(($TargetFile -eq "") -and (Test-Path($File3)))
    {
        $TargetFile = $File3
    }



    if(($TargetFile -ne "") -and (Test-Path($TargetFile)))
    {
        
        $SignedBuild = Get-AuthenticodeSignature $TargetFile
        $SignMsg = $SignedBuild.StatusMessage
        Write-ColorOutput White "   Checking sign on file -> $TargetFile"

        
        if($SignMsg.contains("Signature verified"))
        {
            Write-ColorOutput Green "   The OS Build is signed. Looks Good"            
            
        }
        else
        {
            Write-ColorOutput Red "   The OS Build is does not seem to be signed. DLP may not work"            
            $global:bDLPMinReqOS = $false            
        }
        return
    }
    else
    {
        Write-ColorOutput Yellow "   Samples files taken from System32 does not exists. Try from Windows folder"
        Write-ColorOutput White " "
    }


    ### If can't be verified due to missing bins in System32 folder, then try few more in Windows folder
    $File1 = $env:windir + "\explorer.exe"
    $File2 = $env:windir + "\splwow64.exe"    
    $File3 = $env:windir + "\win.ini"
    $TargetFile = ""
    
    if(Test-Path($File1))
    {
        $TargetFile = $File1
    }
    
    if(($TargetFile -eq "") -and (Test-Path($File2)))
    {
        $TargetFile = $File2
    }
    if(($TargetFile -eq "") -and (Test-Path($File3)))
    {
        $TargetFile = $File3
    }


    if(($TargetFile -ne "") -and (Test-Path($TargetFile)))
    {
        Write-ColorOutput White "   Checking sign on file -> $TargetFile"
        $SignedBuild = Get-AuthenticodeSignature $TargetFile
        $SignMsg = $SignedBuild.StatusMessage
        
        if($SignMsg.contains("Signature verified"))
        {
            Write-ColorOutput Green "   The OS Build is signed. Looks Good"                    
        }
        else
        {
            Write-ColorOutput Red "   The OS Build is does not seem to be signed. DLP may not work"            
            $global:bDLPMinReqOS = $false            
        }
        return
    }
    else
    {
        Write-ColorOutput Yellow "   Samples files taken from Windows folder does not exists "
    }

    Write-ColorOutput Red "   Can't verify if Windows Build is signed or not"    

}




############################################################################################

### FUNCTION: PUTS A FINAL HELP MESSAGE 

############################################################################################

function PrintFinalMessage
{
    
    Write-ColorOutput White " "
    Write-ColorOutput Cyan "ADDITIONAL HELP NOTES:"
    Write-ColorOutput White " "    
    Write-ColorOutput Cyan "********************************************************************************************"
    Write-ColorOutput Yellow "  ==> If issues with DLP still persist after fixing all the above, follow the below steps"
    Write-ColorOutput White " "

    Write-ColorOutput White '   1. Download the MDATP Client Analyzer Tool from http://aka.ms/betamdatpanalyzer'
    Write-ColorOutput White '   2. Extract the downloaded zip file to any local folder'
    Write-ColorOutput White '   2. Open CMD prompt as admin in above path and run the command "MDATPClientAnalyzer.cmd -t"'
    Write-ColorOutput White '   3. Reproduce the issue'
    Write-ColorOutput White '   4. Stop the trace collection'
    Write-ColorOutput White '   5. Share the created MDATPClientAnalyzerResult.zip file with the DLP support team'
    Write-ColorOutput White " "
    Write-ColorOutput Cyan "*********************************************************************************************"
    Write-ColorOutput White " "
    Write-ColorOutput White " "
    
    
    Write-ColorOutput White "**********************************************************************************************"
    Write-ColorOutput Yellow "  ==> To check the extended attributes on individual files "
    Write-ColorOutput White " "
    Write-ColorOutput White '   1. Download the MDATP Client Analyzer Tool from http://aka.ms/betamdatpanalyzer'
    Write-ColorOutput White '   2. Extract the downloaded zip file which contains the tool DisplayExtendedAttributes.exe'
    Write-ColorOutput White '   3. Open cmd as admin and run the command "DisplayExtendedAttributes.exe <filename>"'
    Write-ColorOutput White " "
    Write-ColorOutput White "**********************************************************************************************"
    
    Write-ColorOutput White " "
    
}



function DLPMinReqFromOS
{

    ## Check if Windows Defender and Wd filter are actually running
    Write-ColorOutput White "------------------------------------"
    CheckWDRunning
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " " 
    Write-ColorOutput White " " 

    
    ## Get Defender Engine version.
    Write-ColorOutput White "------------------------------------"
    GetCurrentEngVersion                     
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " "
    Write-ColorOutput White " " 
    
    
    ## Get Defender MoCAMP version.
    Write-ColorOutput White "------------------------------------"
    GetCurrentMoCAMPVersion
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " " 
    Write-ColorOutput White " " 
        
    ## Check DLP feature enabled from end client
    Write-ColorOutput White "------------------------------------"
    CheckDLPEnabled
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " " 
    Write-ColorOutput White " " 
    
    ## Check the OS version 
    Write-ColorOutput White "------------------------------------"
    GetOSBuildNum
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " " 
    Write-ColorOutput White " " 


    ## Check if reg entries are present to onboard SENSE 
    ## This check is no longer needed for Public Preview phase. 
    <#
    Write-ColorOutput White "------------------------------------"
    CheckSenseOnBoardReg
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " " 
    Write-ColorOutput White " " 
    #>

    ## Check if BM and RTM flags are set properly
    Write-ColorOutput White "------------------------------------"
    CheckBMConfig
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " " 
    Write-ColorOutput White " " 

    ## Check if BM and RTM flags are set properly under policy manager reg path
    Write-ColorOutput White "------------------------------------"
    CheckBMConfig_PolManager
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " " 
    Write-ColorOutput White " " 


    ## Check if the build is PR signed
    Write-ColorOutput White "------------------------------------"
    CheckBuildPRSigned
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " " 
    Write-ColorOutput White " " 
    
    Start-Sleep -s 1
}


############################################################################################

### MAIN: ENTRY POINT TO THE SCRIPT

############################################################################################

try
{

    $arch = ($env:PROCESSOR_ARCHITECTURE)    # Get the OS architecture.
    
    
    ## LOGGING RELATED   
    ############################################  
    if ( -Not(Test-Path -Path $global:DLP_DIAGNOSE_LOGPATH) )
    {
        try
        {
            New-Item -Path $global:DLP_DIAGNOSE_LOGPATH -ItemType Directory | Out-Null
            Start-Sleep -s 2
            #Write-ColorOutput Yellow ("    INFO: Folder created $global:DLP_DIAGNOSE_LOGPATH")   
        }
        catch [System.Exception]
        {
            Write-ColorOutput Red  "    ERROR: Failed to create the directory: $global:DLP_DIAGNOSE_OUTPUT_LOG "
            Write-ColorOutput Yellow  "    WARN: Continuing the script without logging to a file "            
        }
    }

    [string]$OutputLogFileName = "DLPDiagnosing" + (Get-Date -Format "MMddyyyy-HHmmss").ToString() + ".log"
    #Write-ColorOutput Yellow "    File name is --> $OutputLogFileName"

    $global:LogFileName = join-path $global:DLP_DIAGNOSE_LOGPATH  $OutputLogFileName     
    #Write-ColorOutput Yellow "    File path is -->  $global:LogFileName"

    try
    {
        $logF = New-Item $global:LogFileName 
        #Write-ColorOutput Yellow "    Logging to a file started: $global:LogFileName"
    }
    catch [System.Exception]
    {
        Write-ColorOutput Red ("ERROR: Failed to create the log file. Exiting")   
        return
    }
    ############################################
        
    
    Write-ColorOutput White " "   
    Write-ColorOutput cyan "DLP Quick diagnosis ($arch) started..."


    Write-ColorOutput White " " 
    Write-ColorOutput White " " 

    ## Displays machine information 
    Write-ColorOutput White "------------------------------------"
    DisplayMachineInfo
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " " 
    Write-ColorOutput White " " 
    

    ## Check the mandatory requisites for DLP
    DLPMinReqFromOS

    ## If min requisites does not meet, no need of checking additional stuff
    if($global:bDLPMinReqOS -eq $false)
    {
        Write-ColorOutput Red "   ERROR: Does not meet the minimum requisites needed for DLP. Feature may not work without fixing them. Continue checking..."           
    }

    # Check if the device is part of a domain.
    Write-ColorOutput White " " 
    Write-ColorOutput White "------------------"
    Write-ColorOutput Cyan "CHECKING DOMAIN:"
    Write-ColorOutput White " " 
    [string] $machineDomain = 'Machine domain: ' + (Get-WmiObject Win32_ComputerSystem).Domain
    
    if ((gwmi win32_computersystem).partofdomain -eq $true)   
    {

        Write-ColorOutput Green "   Device is part of the domain $machineDomain"        
    }
    else
    {
        Write-ColorOutput Red "   Device is not part of the domain"        
    }
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " " 
    Write-ColorOutput White " " 

    
    
    ## Check if device and file polices are set properly
    Write-ColorOutput White "------------------------------------"
    CheckDLPPolices
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " " 
    Write-ColorOutput White " " 

    
    ## Check if reg entries are present to onboard SENSE 
    Write-ColorOutput White "------------------------------------"
    CheckNotificationSettings
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " " 
    Write-ColorOutput White " " 


    ## Check if UX configuration settings controlled by Group Policy are set correctly for toast display
    Write-ColorOutput White "------------------------------------"
    CheckUXConfiguraitonSettings
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " " 
    Write-ColorOutput White " " 


    ## Check if OS back port changes have been available in this OS    
    Write-ColorOutput White "------------------------------------"
    DLPInboxChangesBackportedToOS
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " " 
    Write-ColorOutput White " " 



    ## Check if dlp show dialog reg settings
    ## Decided not to have this check as it will be controlled by signs
    <#
    Write-ColorOutput White "------------------------------------"
    CheckDLPShowDialog
    Write-ColorOutput White "------------------------------------"
    Write-ColorOutput White " " 
    Write-ColorOutput White " " 
    #>    
    
    PrintFinalMessage
    
    
    Write-ColorOutput Cyan "DLP quick diagnosis complete"
    Write-ColorOutput White " "
    Write-Output " => Log saved at: $global:LogFileName"

}
catch [System.Exception]
{
    Write-ColorOutput Magenta $Error
}


# SIG # Begin signature block
# MIIjhgYJKoZIhvcNAQcCoIIjdzCCI3MCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAKTQOaGvX4dsmn
# RiEcSYNVDWQzlixSZ3snivLOEfyjt6CCDYEwggX/MIID56ADAgECAhMzAAABh3IX
# chVZQMcJAAAAAAGHMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAwMzA0MTgzOTQ3WhcNMjEwMzAzMTgzOTQ3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOt8kLc7P3T7MKIhouYHewMFmnq8Ayu7FOhZCQabVwBp2VS4WyB2Qe4TQBT8aB
# znANDEPjHKNdPT8Xz5cNali6XHefS8i/WXtF0vSsP8NEv6mBHuA2p1fw2wB/F0dH
# sJ3GfZ5c0sPJjklsiYqPw59xJ54kM91IOgiO2OUzjNAljPibjCWfH7UzQ1TPHc4d
# weils8GEIrbBRb7IWwiObL12jWT4Yh71NQgvJ9Fn6+UhD9x2uk3dLj84vwt1NuFQ
# itKJxIV0fVsRNR3abQVOLqpDugbr0SzNL6o8xzOHL5OXiGGwg6ekiXA1/2XXY7yV
# Fc39tledDtZjSjNbex1zzwSXAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhov4ZyO96axkJdMjpzu2zVXOJcsw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU4Mzg1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAixmy
# S6E6vprWD9KFNIB9G5zyMuIjZAOuUJ1EK/Vlg6Fb3ZHXjjUwATKIcXbFuFC6Wr4K
# NrU4DY/sBVqmab5AC/je3bpUpjtxpEyqUqtPc30wEg/rO9vmKmqKoLPT37svc2NV
# BmGNl+85qO4fV/w7Cx7J0Bbqk19KcRNdjt6eKoTnTPHBHlVHQIHZpMxacbFOAkJr
# qAVkYZdz7ikNXTxV+GRb36tC4ByMNxE2DF7vFdvaiZP0CVZ5ByJ2gAhXMdK9+usx
# zVk913qKde1OAuWdv+rndqkAIm8fUlRnr4saSCg7cIbUwCCf116wUJ7EuJDg0vHe
# yhnCeHnBbyH3RZkHEi2ofmfgnFISJZDdMAeVZGVOh20Jp50XBzqokpPzeZ6zc1/g
# yILNyiVgE+RPkjnUQshd1f1PMgn3tns2Cz7bJiVUaqEO3n9qRFgy5JuLae6UweGf
# AeOo3dgLZxikKzYs3hDMaEtJq8IP71cX7QXe6lnMmXU/Hdfz2p897Zd+kU+vZvKI
# 3cwLfuVQgK2RZ2z+Kc3K3dRPz2rXycK5XCuRZmvGab/WbrZiC7wJQapgBodltMI5
# GMdFrBg9IeF7/rP4EqVQXeKtevTlZXjpuNhhjuR+2DMt/dWufjXpiW91bo3aH6Ea
# jOALXmoxgltCp1K7hrS6gmsvj94cLRf50QQ4U8Qwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVWzCCFVcCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAYdyF3IVWUDHCQAAAAABhzAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQga9DInnkj
# oudpyh/dYtlnwhFpAHOM7gLX/DhxJdix3AswQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQBhfaAEeVmlelUYatUM66Eb88Xk4QyO3BNZajHJ1f/n
# mVJzQmqRZIx/Nwf6JS4AcRPV5hu/opQSi/S1dbIkhcybhBbFWSk0ats90BU8p5xM
# DPv1tcfpyfP7rnRq1IZOkkFRw8atezHomfCqssIWh0nY5cDQjqOqk86cRFQRsIxq
# 80PXdB1nKhR/kSZb4LfApRiuO1NiGDtgJMLFJ+01O4lSs02Dr8KCG27XA2lvpvaL
# xV61MieYUcgUka25TkdkqF+5zKbJGf5U/OxY+JTPDwpNQcxvtv5+ldE0Kcii2cfH
# A0yN3EU/NsRGWTaOagUDmcfztRQaZsM4V/NqWzEHZDwCoYIS5TCCEuEGCisGAQQB
# gjcDAwExghLRMIISzQYJKoZIhvcNAQcCoIISvjCCEroCAQMxDzANBglghkgBZQME
# AgEFADCCAVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIJVOAIgwLJlanKtbnxaCTgnoY6YKwfUa+QC5eFrt
# wTb/AgZfFh//9i0YEzIwMjAwODE3MDc1ODM4LjQxMlowBIACAfSggdCkgc0wgcox
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1p
# Y3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1Mg
# RVNOOjIyNjQtRTMzRS03ODBDMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBTZXJ2aWNloIIOPDCCBPEwggPZoAMCAQICEzMAAAEY/jr32RvUsTMAAAAAARgw
# DQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcN
# MTkxMTEzMjE0MDM1WhcNMjEwMjExMjE0MDM1WjCByjELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2Eg
# T3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MjI2NC1FMzNFLTc4
# MEMxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDC+ANcEX8/NRj1t5YkXYB1ZHPxQSwr
# hOOfXX1c5aes0t2gTI6OeH4ntcwpyTvSk7+9BBVoqTvHwfbDZmb15nQ94q+UPfBq
# a/8m1tes/6Fbt1AeVHy4By1AVFi6Yi1vWd3bVRyY2SAeVonIzEFGGtQveRv2Yj6j
# bCHE2+xP3Q+AcgxweE8l6/nAN5S/mTDKV2flHNQg+d5X9SSN7MdLC5OAJgSy374I
# i/AnYEKyIgnOFJVkIxkLDxOyrnV/gORloaxyVGlDemnLBNahwsxnmkrpChcwvDie
# Ax4g/Z1fJ0+C+wdA+EtA7rrgnRkjhKHfWkZj40bmx4GpQdJmF1zAZ0FxAgMBAAGj
# ggEbMIIBFzAdBgNVHQ4EFgQU8VvlsC4PYAnYOU/05iPr+LTHKD4wHwYDVR0jBBgw
# FoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDov
# L2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENB
# XzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAx
# MC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDAN
# BgkqhkiG9w0BAQsFAAOCAQEAcyWdvg6cgs//AmxoQZm+WASpJzUXEPhMp30bWc5H
# yCwQB+Ma6YPncSoFdct/5V1K4p/rMcMLBn5LzELVH+uztg6ERK48YtbJb9A7Jp+f
# JZj7loXaP9mVP7tJs2tGuubcXpGbgo5HGCjn7gzMBHY45Q8LScfa1JFQEAiS2gCK
# KRlrKMsGaIbi+UuBtsbQ8JknvmiEwCCwSmRTX0viAZusm4mJVqKBe3Bmj+yBDJVW
# cv0MyrEYQ74oa0VSW3JBc+xSrqT2Jgm2Cc6IlSbm8AsiVE/Vc4yahfmLeeFHfTcr
# K0flu6VGzjf1GNA1SDXR4bUinrBli3lfhwtKhx6x5eRsSjCCBnEwggRZoAMCAQIC
# CmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRp
# ZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIx
# NDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF
# ++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRD
# DNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSx
# z5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1
# rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16Hgc
# sOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB
# 4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqF
# bVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1Ud
# EwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYD
# VR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwv
# cHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEB
# BE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCB
# kjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQe
# MiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQA
# LiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUx
# vs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GAS
# inbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1
# L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWO
# M7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4
# pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45
# V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x
# 4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEe
# gPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKn
# QqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp
# 3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvT
# X4/edIhJEqGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBP
# cGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoyMjY0LUUzM0UtNzgw
# QzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcG
# BSsOAwIaAxUAzdeb1yAva2kJJ2mFfDdeSfFJMdyggYMwgYCkfjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOLkNkcwIhgPMjAy
# MDA4MTcwNjQ4MzlaGA8yMDIwMDgxODA2NDgzOVowdzA9BgorBgEEAYRZCgQBMS8w
# LTAKAgUA4uQ2RwIBADAKAgEAAgIlGAIB/zAHAgEAAgIRtDAKAgUA4uWHxwIBADA2
# BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIB
# AAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAB5ETljOcZygXEqAYdq/qF16bXN1i7dP
# rImAesOg01pRq8otI7ggusuEKid8A4nC3t3nf7DNU/Kl/oGjO/ZsFCmklpgvUcC3
# BGOHttIq/0qYGbC1lfJc7wTHSNYbI8PQa+RRD61hYLpDUGEj3nCgW6rlAoNCQzdq
# bGfKIv7B2ZzwMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAEY/jr32RvUsTMAAAAAARgwDQYJYIZIAWUDBAIBBQCgggFKMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgTUcJaB2j
# zg0QQABbNQRgzqwDTEK7s462toK45wDiDmwwgfoGCyqGSIb3DQEJEAIvMYHqMIHn
# MIHkMIG9BCCgzwcUm6pSA48AVS+9m5Z+k6cHH7WyNjvPil0oMg0H9zCBmDCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABGP4699kb1LEzAAAA
# AAEYMCIEIODe2Mq4vQtacI1gUaQdSSaRDyG5h8jl43pTlnSOQaS2MA0GCSqGSIb3
# DQEBCwUABIIBAEKieivbattol4hobl+chuDXH+89U4dPySvjXrrSSfAQ0ihmxDgi
# 9l4n1szt+UUr4Z5D4Bet7zZDOTxsgu2VM9FUiWIvBgxWn/F6YkWjvUZtFRZRxHLI
# 4LX3spuy7QQzLOwcDxlO2ugv5u0CIl6SUF44GBLFMG27xLaRO+TaBTIp2EZmXDoj
# Mf1C3o6pzn7OvtNFIJ0tD0eYplo9wwOGFNLK6I3vSks7TkF3IOmZ8uqICGmduxGW
# Koc9A+f/SIFpQq7C1RMmK7jAwm0uEPA2bhlmje5dNaPmUiYyqrzPlKkbBciZFfvH
# nTQ24/1s1deGL9LyDHg3Wj5nvJj0Z0+9ZVY=
# SIG # End signature block
