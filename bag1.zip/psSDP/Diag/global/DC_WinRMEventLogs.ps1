﻿if ((($OSVersion.Major -eq 6) -and ($OSVersion.Minor -eq 0)) -or 	#Vista, 2008
	(($OSVersion.Major -eq 6) -and ($OSVersion.Minor -eq 1)) -or	#Win7, 2008 R2
	(($OSVersion.Major -eq 6) -and ($OSVersion.Minor -eq 2)) -or 	#Win8, 2012
	($OSVersion.Major -eq 10))
{
	$EventLogNames = "Microsoft-Windows-WinRM/Operational"
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames
}
