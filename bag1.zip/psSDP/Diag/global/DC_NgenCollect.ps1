﻿#************************************************
# DC_NgenCollect.ps1
# Version 1.0
# Date: 2009-2019
# Author: Walter Eder (waltere@microsoft.com)
# Description: Collects .Net Framework nGen files
# Called from: TS_AutoAddCommands_Apps.ps1
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}


Write-verbose "$(Get-Date -UFormat "%R:%S") : Start of script DC_NgenCollect.ps1"

"==================== Starting NgenCollect.ps1 script ====================" | WriteTo-StdOut
#_# Import-LocalizedData -BindingVariable ScriptStrings

# Registry keys


# Saved Directories

"Getting .Net Framework nGen files" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_NetFrameworknGenfiles_Title -Status $ScriptStrings.ID_NetFrameworknGenfiles_Status
$sectionDescription = " .Net Framework nGen files"
if(test-path "$env:windir\Microsoft.NET\Framework64\v4.0.30319\ngen.log")
{	$OutputFile = $ComputerName + "_ngen64.log"
	copy-item -Path "$env:windir\Microsoft.NET\Framework64\v4.0.30319\ngen.log" -Destination $OutputFile -Force
	CollectFiles -filesToCollect $OutputFile -fileDescription ".NET Framework v4 ngen.log (64-bit)" -sectionDescription $sectionDescription
}

if(test-path "$env:windir\Microsoft.NET\Framework\v4.0.30319\ngen.log")
{	$OutputFile = $ComputerName + "_ngen.log"
	copy-item -Path "$env:windir\Microsoft.NET\Framework\v4.0.30319\ngen.log" -Destination $OutputFile -Force
	CollectFiles -filesToCollect $OutputFile -fileDescription ".NET Framework v4 ngen.log" -sectionDescription $sectionDescription
}


# Directory Listings

# Permission Data

# Event Logs


Write-verbose "$(Get-Date -UFormat "%R:%S") :   end of script DC_NgenCollect.ps1"
