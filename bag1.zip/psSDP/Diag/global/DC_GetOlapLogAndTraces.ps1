New-Variable OLAP_SERVICE_KEY_MASK  -Value "HKLM:\System\CurrentControlSet\Services\*OLAP*"   -Option ReadOnly
New-Variable OLAP_CONFIG_FILE       -Value "MSMDSRV.INI"                                      -Option ReadOnly

function Get-SsasConfigFilePath([object]$OlapServiceKey)
{
	$Error.Clear()           
	trap 
	{
		"[Get-SsasConfigFilePath] : [ERROR] Trapped exception ..." | WriteTo-StdOut
		Report-Error
	}
    
    [string]$ConfigFilePath=$null
    
    if ($null -ne $OlapServiceKey)
    {
        $ImagePath =  (Get-ItemProperty -Path $OlapServiceKey.PSPath).ImagePath
        
        if ($null -ne $ImagePath)
        {    
            # The configu file path follows the -s command line parameter imbedded in the image path
            # Example Image Path:
            # "C:\Program Files\Microsoft SQL Server\MSAS10_50.SQL2008R2\OLAP\bin\msmdsrv.exe" -s "C:\Program Files\Microsoft SQL Server\MSAS10_50.SQL2008R2\OLAP\Config"
            $ConfigFilePath = ($ImagePath.Substring($ImagePath.IndexOf("-s")+3)).Trim("`"")
        }
        else
        {
            '[Get-SsasConfigFilePath] : [ERROR] Get-ItemProperty returned a null image path for the OLAP service' | WriteTo-StdOut
        }
        
    }
    else
    {
        '[Get-SsasConfigFilePath] : [ERROR] Required parameter -OlapServiceKey was not specified' | WriteTo-StdOut
    }
    
    return $ConfigFilePath
}

function Get-SsasInstanceName([string]$ServiceName)
{
	$Error.Clear()           
	trap 
	{
		'[Get-SsasInstanceName] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error 
	}
	
    if (($null -ne $ServiceName) -and (0 -lt $ServiceName.Length))
    {   
        
        # If named instance split the service name at the $ to get the instance name ...
        if ($ServiceName.Contains("$"))
        {
            $InstanceName = ($ServiceName.Split("$"))[1]
        }
        else
        {
            $InstanceName = $ServiceName
        }   
   }
   else
   {
        '[Get-SsasInstanceName] : [ERROR] Required parameter -ServiceName was not specified.' | WriteTo-StdOut
   }
   
   return $InstanceName
}

function Get-SSASLogPath([Object]$OlapServiceKey)
{
	$Error.Clear()           
	trap 
	{
		"[Get-SSASLogPath] : [ERROR] Trapped exception ..." | WriteTo-StdOut
		Report-Error 
	}
	
	[string]$PathToReturn=$null
	
    if ($null -ne $OlapServiceKey) 
    {
        # Get the instance name from the service name
        $InstanceName = Get-SsasInstanceName $OlapService.PSChildName
    	
    	if (($null -ne $InstanceName) -and (0 -lt $InstanceName.Length))
        {
            # Extract the path to the config file from the imagepath
            $ConfigFilePath = Get-SsasConfigFilePath $OlapServiceKey
            
            if ($null -ne $ConfigFilePath)
            {
                # Test Config file path retrieved from the ImagePath in the registry
                if (Test-Path $ConfigFilePath -PathType "Container")
                {    
					#Open the ini file to find the log path
					[System.Xml.XmlDocument]$xd=New-Object System.Xml.XmlDocument
					$ConfigFile = Join-Path $ConfigFilePath "msmdsrv.ini"
					$xd.Load($ConfigFile)
					$ConfigSettings=$xd.SelectNodes("/ConfigurationSettings")
					
					#Set to return the log path if not null
					if ($null -ne $ConfigSettings)
					{
						foreach ($IniFile in $ConfigSettings)
						{
							$PathToReturn = $IniFile.LogDir
						}
					}
					else
					{
						'[Get-SSASLogPath] : [ERROR] XML parsing of the SSAS ini file failed' | WriteTo-StdOut
					}
                } 
                else
                {
                    "[Get-SSASLogPath] : Invalid path to configuration file: [{0}]" -f $ConfigFilePath | WriteTo-StdOut
                    if ($true -eq (Check-IsSsasDiskResourceOnline $ConfigFilePath))
                    {
                        "[Get-SSASLogPath] : [ERROR] Path to SSAS Configuration file: [{0}] for instance: {1} is invalid" -f $DumpDir, $InstanceToCollect | WriteTo-StdOut
                    }
                }
				
			} #if ($null -ne $ConfigFilePath)
			else
			{
				'[Get-SSASLogPath] : [ERROR] Path to the OLAP config path collected was invalid' | WriteTo-StdOut
			}
			
        } # if ($null -ne $InstanceName)
        else
        {
            '[Get-SSASLogPath] : [ERROR] Get-SsasInstanceName returned a null value' | WriteTo-StdOut
        }
    } # if ($null -ne $OlapService)
    else
    {
        '[Get-SSASLogPath] : [ERROR} Required parameter -OlapService was not specified' |WriteTo-Stdout
    }
	
	return $PathToReturn
} #Get-SSASLogPath

function CopyAndCollectSsasLog([object]$OlapServiceKey)
{
	$Error.Clear()           
	trap 
	{
		"[CopyAndCollectSsasLog] : [ERROR] Trapped exception ..." | WriteTo-StdOut
		Report-Error 
	}
	
	[string]$LogFilePath=$null
	
    if ($null -ne $OlapServiceKey) 
    {
        # Get the instance name from the service name
        $InstanceName = Get-SsasInstanceName $OlapService.PSChildName
    	
    	if (($null -ne $InstanceName) -and (0 -lt $InstanceName.Length))
        {
            # Update msdt dialog that's displayed to user
        	Write-DiagProgress -Activity $ssasConfigurationCollectorStrings.ID_SSAS_CollectSSASConfigFile -Status ($ssasConfigurationCollectorStrings.ID_SSAS_CollectSSASConfigFileDesc + ": " + $InstanceName)
                
            # Extract the path to the log file
            $LogFilePath = Get-SsasLogPath $OlapServiceKey
            
            if (($null -ne $LogFilePath) -and ([string]::Empty -ne $LogFilePath))
            {
                # Test Config file path retrieved from the ImagePath in the registry
                if (Test-Path $LogFilePath -PathType "Container")
                {    
                    $LogFiles = Get-ChildItem -Path (Join-Path $LogFilePath "*") -Include "msmdsrv.log" | Sort-Object -Property Length -Descending
					
					if ($null -ne $LogFiles)
					{
						$Prefix = $ComputerName + "-" + $InstanceName
						CollectFiles -FilesToCollect $LogFiles -SectionDescription ("OLAP log files for instance {0}" -f $InstanceName) -renameOutput $true -MachineNamePrefix $Prefix
					}
                } 
                else
                {
                    "[CopyAndCollectSsasLog] : Invalid path to log file: [{0}]" -f $LogFilePath | WriteTo-StdOut
                    if ($true -eq (Check-IsSsasDiskResourceOnline $LogFilePath))
                    {
                        "[CopyAndCollectSsasLog] : [ERROR] Path to SSAS log file: [{0}] for instance: {1} is invalid" -f $DumpDir, $InstanceToCollect | WriteTo-StdOut
                    }
                }
				
			} #if ($null -ne $LogFilePath)
			else
			{
				'[CopyAndCollectSsasLog] : [ERROR] Path to the OLAP log path collected was invalid' | WriteTo-StdOut
			}
			
        } # if ($null -ne $InstanceName)
        else
        {
            '[CopyAndCollectSsasLog] : [ERROR] Get-SsasInstanceName returned a null value' | WriteTo-StdOut
        }
    } # if ($null -ne $OlapService)
    else
    {
        '[CopyAndCollectSsasLog] : [ERROR} Required parameter -OlapService was not specified' |WriteTo-Stdout
    }
	
} # function CopyAndCollectSsasLog()

function CopyAndCollectSsasTraces([object]$OlapServiceKey)
{
	$Error.Clear()           
	trap 
	{
		"[CopyAndCollectSsasTrace] : [ERROR] Trapped exception ..." | WriteTo-StdOut
		Report-Error 
	}
	
	[string]$TraceFilePath=$null
	
    if ($null -ne $OlapServiceKey) 
    {
        # Get the instance name from the service name
        $InstanceName = Get-SsasInstanceName $OlapService.PSChildName
    	
    	if (($null -ne $InstanceName) -and (0 -lt $InstanceName.Length))
        {
            # Update msdt dialog that's displayed to user
        	Write-DiagProgress -Activity $ssasConfigurationCollectorStrings.ID_SSAS_CollectSSASConfigFile -Status ($ssasConfigurationCollectorStrings.ID_SSAS_CollectSSASConfigFileDesc + ": " + $InstanceName)
                
            # Extract the path to the trace file
            $TraceFilePath = Get-SsasLogPath $OlapServiceKey
            
            if ($null -ne $TraceFilePath)
            {
                # Test Config file path retrieved from the ImagePath in the registry
                if (Test-Path $TraceFilePath -PathType "Container")
                {    
                    $TraceFiles = Get-ChildItem -Path (Join-Path $TraceFilePath "*") -Include "*.trc" | Sort-Object -Property Length -Descending
					
					if ($null -ne $TraceFiles)
					{
						$Prefix = $ComputerName + "-" + $InstanceName
						CollectFiles -FilesToCollect $TraceFiles -SectionDescription ("OLAP trace files for instance {0}" -f $InstanceName) -renameOutput $true -MachineNamePrefix $Prefix
					}
                } 
                else
                {
                    "[CopyAndCollectSsasTrace] : Invalid path to trace file: [{0}]" -f $ConfigFilePath | WriteTo-StdOut
                    if ($true -eq (Check-IsSsasDiskResourceOnline $ConfigFilePath))
                    {
                        "[CopyAndCollectSsasTrace] : [ERROR] Path to SSAS trace file: [{0}] for instance: {1} is invalid" -f $DumpDir, $InstanceToCollect | WriteTo-StdOut
                    }
                }
				
			} #if ($null -ne $ConfigFilePath)
			else
			{
				'[CopyAndCollectSsasTrace] : [ERROR] Path to the OLAP trace path collected was invalid' | WriteTo-StdOut
			}
			
        } # if ($null -ne $InstanceName)
        else
        {
            '[CopyAndCollectSsasTrace] : [ERROR] Get-SsasInstanceName returned a null value' | WriteTo-StdOut
        }
    } # if ($null -ne $OlapService)
    else
    {
        '[CopyAndCollectSsasTrace] : [ERROR} Required parameter -OlapService was not specified' |WriteTo-Stdout
    }
	
} # function CopyAndCollectSsasTrace()

$Error.Clear()           
trap 
{
	"[Get-OlapLogAndTraces] : Trapped error ..." | WriteTo-StdOut
	Show-ErrorDetails $error[0] 
}

Import-LocalizedData -BindingVariable ssasConfigurationCollectorStrings

# Get a list of the installed SSAS services from the HKLM:\SYSTEM\CurrentControlSet key
$OlapServices = @(get-childitem $OLAP_SERVICE_KEY_MASK)

if (0 -lt $OlapServices.Count)
{
	"[DC-GetOlapLogAndTraces] : Discovered {0} SSAS Service(s)" -f $OlapServices.Count | WriteTo-StdOut
	
    foreach ($OlapService in $OlapServices)
    {      
        "[DC-GetOlapLogAndTraces] : Collecting server configuration for service: {0}" -f $OlapService.PsChildName | WriteTo-StdOut
        
        CopyAndCollectSsasLog -OlapServiceKey $OlapService
		CopyAndCollectSsasTraces -OlapServiceKey $OlapService
    }
}
else
{
    "[DC_GetOlapLogAndTraces] : No OLAP services were found on server: [{0}]" -f $env:COMPUTERNAME | WriteTo-StdOut
}
