﻿#************************************************
# DC_Bluetooth-Component.ps1
# Version 1.0: Created
# Date: 2020
# Author: Walter Eder (waltere@microsoft.com)
# Description: Collects information about the Bluetooth Component.
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.id_ctsBluetooth -Status $ScriptVariable.id_ctsBluetoothDescription


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	$RunPScmd = $RunPScmd + " -ErrorAction SilentlyContinue" 
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	 |format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $OutputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	 | Out-File -FilePath $OutputFile -append
	}
}

function Get-BluetoothRadioInfo
# SYNOPSIS: collect BluetoothRadio Info
{
	$devices = Get-PnpDevice -Class Bluetooth -EA SilentlyContinue |? InstanceId -notlike "BTH*"
	if ($devices -ne $null) {
		$radios = New-Object System.Collections.ArrayList
		foreach ($device in $devices)
		{   
			$radio = New-Object PSObject
			Add-Member -InputObject $radio -MemberType NoteProperty -Name "InstanceId" -Value $device.InstanceId
			$property = Get-PnpDeviceProperty -InstanceId $device.InstanceId -KeyName 'DEVPKEY_Bluetooth_RadioAddress'
			Add-Member -InputObject $radio -MemberType NoteProperty -Name "MAC" -Value $(-join ($property.Data |  foreach { "{0:X2}" -f $_ } ))
			$radios.Add($radio) | Out-Null

			# Driver Info
			$property = Get-PnpDeviceProperty -InstanceId $device.InstanceId -KeyName 'DEVPKEY_Device_DriverDesc'
			Add-Member -InputObject $radio -MemberType NoteProperty -Name "DriverDescription" -Value $property.Data
			$property = Get-PnpDeviceProperty -InstanceId $device.InstanceId -KeyName 'DEVPKEY_Device_DriverVersion'
			Add-Member -InputObject $radio -MemberType NoteProperty -Name "DriverVersion" -Value $property.Data

			# Error Recovery
			$property = Get-PnpDeviceProperty -InstanceId $device.InstanceId -KeyName '{A92F26CA-EDA7-4B1D-9DB2-27B68AA5A2EB} 14'
			$supportedTypes = $property.Data
			if ($supportedTypes -eq 0)
			{
				Add-Member -InputObject $radio -MemberType NoteProperty -Name "ErrorRecovery" -Value "None"
			} elseif ($supportedTypes -band 1 -shl 0)
			{
				Add-Member -InputObject $radio -MemberType NoteProperty -Name "ErrorRecovery" -Value "FLDR"
			} elseif ($supportedTypes -band 1 -shl 1)
			{
				Add-Member -InputObject $radio -MemberType NoteProperty -Name "ErrorRecovery" -Value "PLDR"
			}
			
		}
		$radios | Format-Table
	}
} # end of function Get-BluetoothRadioInfo

$sectionDescription = "Bluetooth"

#----------W8/WS2012 powershell cmdlets
# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

$OutputFile = $Computername + "_Bluetooth_info_pscmdlets.TXT"
"===================================================="		| Out-File -FilePath $OutputFile -append
"Bluetooth Powershell Cmdlets"							| Out-File -FilePath $OutputFile -append
"===================================================="		| Out-File -FilePath $OutputFile -append
"Overview"													| Out-File -FilePath $OutputFile -append
"----------------------------------------"					| Out-File -FilePath $OutputFile -append
"   1. Get-BluetoothRadioInfo"								| Out-File -FilePath $OutputFile -append
"===================================================="		| Out-File -FilePath $OutputFile -append
"`n`n`n`n`n"	| Out-File -FilePath $OutputFile -append


$BluetoothServiceStatus = get-service * | where {$_.name -match "Bluetooth"}	
if ($BluetoothServiceStatus -ne $null)
{
	if ($bn -ge 6000)
	{
		Get-BluetoothRadioInfo |Out-File $OutputFile -append
		#RunPS "Get-BitsTransfer" 							-ft 	# WV, W7, W8, W8.1	#fl
	}
	else
	{
		"The operating system is older than Windows Vista / Windows Server 2008. Not running pscmdlets." 		| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The Bluetooth service does not exist." 		| Out-File -FilePath $OutputFile -append
}

CollectFiles -filesToCollect $OutputFile -fileDescription "Bluetooth information (Powershell)" -SectionDescription $sectionDescription


#----------Registry
$OutputFile= $Computername + "_Bluetooth_reg_output.TXT"
$CurrentVersionKeys =	"HKLM\Software\Microsoft\PolicyManager\current\device",
						"HKLM\HKLM\System\CurrentControlSet\Services\BTHUSB\Parameters",
						"HKLM\System\CurrentControlSet\Services\BTHPort\Parameters"

RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "Bluetooth Registry Keys" -SectionDescription $sectionDescription

#Windows Server 2008+
if ($OSVersion.Build -ge 6000)
{
	#----------Bluetooth EventLogs
	$sectionDescription = "Bluetooth EventLogs"
	$EventLogNames = "Microsoft-Windows-Bluetooth-BthLEPrepairing/Operational", "Microsoft-Windows-Bluetooth-MTPEnum/Operational"
	$Prefix = ""
	$Suffix = "_evt_"
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
}

