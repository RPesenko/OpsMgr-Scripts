﻿#************************************************
# DC_KIR-RBC-RegEntries.ps1
# Version 1.0
# Date: 2020
# Author: + Walter Eder (waltere@microsoft.com)
# Description: Collects KIR (for 2019) and RBC (for 2016)  Registry Entries
# Called from: TS_AutoAddCommands_*.ps1
#*******************************************************

function InsertRegHeader(
	[string] $RegHeader="",
	[string]$OutputFile)
{
	if($RegHeader -ne "")
	{
		$RegHeader | Out-File -FilePath $OutputFile -Append -Encoding Default
		"=" * ($RegHeader.Length) | Out-File -FilePath $OutputFile -Append -Encoding Default
	}
}

Import-LocalizedData -BindingVariable KirRegistryStrings
	
Write-DiagProgress -Activity $KirRegistryStrings.ID_KIRRegentriesActivity -Status $KirRegistryStrings.ID_KIRRegentriesStatus

$OutputFile = $ComputerName + "_reg_KIR-RBC_MyKnobs.txt"
$fileDescription = "KIR (for 2019) and RBC (for 2016) Registry Entries"

InsertRegHeader -OutputFile $OutputFile -RegHeader "KIR (for 2019) Registry Entries"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Policies" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false

Write-DiagProgress -Activity $KirRegistryStrings.ID_HivesRegentriesActivity -Status $KirRegistryStrings.ID_HivesRegentriesStatus

$OutputFile= $Computername + "_reg_System.HIV"
RegSave -RegistryKey "HKLM\SYSTEM" -OutputFile $OutputFile -fileDescription "Obtaining System Registry Hive"
$OutputFile= $Computername + "_reg_Software.HIV"
RegSave -RegistryKey "HKLM\Software" -OutputFile $OutputFile -fileDescription "Obtaining Software Registry Hive"
$OutputFile= $Computername + "_reg_Software_User.HIV"
RegSave -RegistryKey "HKCU\Software" -OutputFile $OutputFile -fileDescription "Obtaining Software_User Registry Hive"

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
