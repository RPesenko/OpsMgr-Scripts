﻿#************************************************
# TS_FirewallCheck.ps1
# Version 1.0
# Date: 5-1-2012
# Author: davidcop
# Description: Checks to see that the Windows Firewall service is running and set to the default start mode of Automatic on 2008/2008 R2 or higher Server
#************************************************

if ((($OSVersion.major -eq 6) -and (($OSVersion.minor -ge 0) -and ($OSVersion.minor -le 2))) -or ($OSVersion.major -eq 10))  # Win 7/R2 .. Win10
{
	Import-LocalizedData -BindingVariable ScriptVariable
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSFirewallRunningCheck -Status $ScriptVariable.ID_CTSFirewallRunningCheckDescription
	$InformationCollected = new-object PSObject
	$RootCauseDetected=$false
	  
	if (test-path -path "hklm:\System\CurrentControlSet\services\mpssvc")
	{
	  $WinFirewallService = get-wmiobject -query "select * from win32_service where name = 'mpssvc'"
	  if (!$WinFirewallService.Started)
	  { 
	    $RootCauseDetected=$true
		$RootCauseName = "RC_FirewallRunningCheck"
		$Solution =  $ScriptVariable.ID_FirewallRunningCheckDesc
	  }
	  if ($WinFirewallService.StartMode -ne "Auto")  
	  { 
	    $RootCauseDetected=$true
	    $RootCauseName = "RC_FirewallStartModeCheck"
		$Solution =  $ScriptVariable.ID_FirewallStartModeCheckDesc
	  }

	  add-member -inputobject $InformationCollected -membertype noteproperty -name "Service Status"  -value $WinFirewallService.state
	  add-member -inputobject $InformationCollected -membertype noteproperty -name "Service Startup"  -value $WinFirewallService.startmode
	}
	  
	if ($RootCauseDetected)
	{
	  Update-DiagRootCause -id $RootCauseName -Detected $true
	  Write-GenericMessage -RootCauseId $RootCauseName -PublicContentURL "http://technet.microsoft.com/en-us/library/cc766337(v=WS.10).aspx" -Verbosity "Warning" -Visibility 4 -SupportTopicsID 8051 -Component "Networking" -InformationCollected $InformationCollected -SolutionTitle $Solution
	}
	else
	{
	  $RootCauseName = "RC_FirewallCheck"
	  Update-DiagRootCause -id $RootCauseName -Detected $false
	}

  $string = $null
}

## 04/03: Added new Trap info
#Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
Trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_ 
	continue 
}
