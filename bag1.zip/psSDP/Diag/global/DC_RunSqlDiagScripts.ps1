# DC_RunSqlDiagScripts.ps1 
# This script has dependencies on utils_CTS and utils_DSD
#
param( [Object[]] $instances, [switch]$CollectSqlDiag, [switch]$CollectAlwaysOnInfo ) 

#_# SQLDIAG script name for SQL Server 2014
New-Variable SQL_SCRIPT_SQLDIAG_2014  -Value "sp_sqldiag12.sql"          -Option ReadOnly

# SQLDIAG script name for SQL Server 2012
New-Variable SQL_SCRIPT_SQLDIAG_2012  -Value "sp_sqldiag11.sql"          -Option ReadOnly

# SQLDIAG script name for SQL Server 2008 and SQL Server 2008 R2
New-Variable SQL_SCRIPT_SQLDIAG_2008  -Value "sp_sqldiag10.sql"          -Option ReadOnly

# SQLDIAG script name for SQL Server 2005
New-Variable SQL_SCRIPT_SQLDIAG_2005  -Value "sp_sqldiag09.sql"           -Option ReadOnly

# SQL 2012 Always-On 
New-Variable SQL_SCRIPT_ALWAYSON      -Value "AlaysOnDiagScript.sql"     -Option ReadOnly

#
# Function : Run-SqlScript
# ----------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Public - You should call this script if you want to collect SQLDIAG script output 
#
# Description:
# 			This function runs various SQL Server diagnostic scripts and collects the output
#			This is an "online" snapshot collector that utilizes SQLCMD 
# 
# Arguments:
#			$InstanceName
#				Function will find the path to the errorlogs for the instance passed 
#			$NetName
#				This is the server or virtual SQL network name to connect to
# 
# Owner:
#			DanSha 
#
function Run-SqlScript ([string]$SqlServerName, [string]$ScriptToExecute, [string]$OutFileName, [string]$SectionDescription, [string] $FileDescription )
{
	$Error.Clear()           
	trap 
	{
		"[Run-AlwaysOnScript] : [ERROR] Trapped exception ..." | WriteTo-StdOut
		Report-Error
	}
	
    if ($null -ne $SqlServerName)
    {
        if ($null -ne $ScriptToExecute)
        {
            if ($null -ne $OutFileName)        
            {    
                if ($null -ne $SectionDescription)
                {
                    if ($null -ne $FileDescription)
                    {
                        # Validate existence of script before calling Execute-SqlScript
                    	if ($true -eq (Test-Path -Path $ScriptToExecute -PathType Leaf))
                        {
                            # Write status to debug log
                        	"[Run-SqlDScript] : [INFO] Attempting to collect SQL Server Configuration information for instance: {0} using script: [{1}] as input and writing output to file: [{2}]" -f $SqlServerName, (Join-Path $PWD.Path "sqldiag_proc.sql"), (Join-Path $PWD.Path $SqlDiagOutFileName) | WriteTo-StdOut
                    	
                    	    Execute-SqlScript -ConnectToName $SqlServerName -ScriptToExecute $ScriptToExecute -OutputFileName $OutFileName -SectionDescription $SectionDescription -FileDescription "SQLDIAG"
                        }
                        else
                        {
                            "[Run-SqlScript] : [ERROR] Input file: [{0}] not found in current directory: [{1}]" -f $ScriptToExecute, $PWD.Path  | WriteTo-StdOut
                        }
                    
                    } # if ($null -ne $FileDescription)
                    else
                    {
                        '[Run-SqlScript] : [ERROR] Required parameter -FileDescription was not specified.' | WriteTo-StdOut
                    }
                    
                } # if ($null -ne $SectionDescription)
                else
                {
                    '[Run-SqlScript] : [ERROR] Required parameter -SectionDescription was not specified.' | WriteTo-StdOut
                }
                
            } # if ($null -ne $OutFileName)   
            else
            {
                '[Run-SqlScript] : [ERROR] Required parameter -OutFileName was not specified.' | WriteTo-StdOut
            }     
            
        } #   if ($null -ne $ScriptToExecute)
        else
        {
            '[Run-SqlScript] : [ERROR] Required parameter -ScriptToExecute was not specified.' | WriteTo-StdOut
        } 
        
    } # if ($null -ne $InstanceName)
    else
    {
        '[Run-SqlScript] : [ERROR] Required parameter -SqlServerName was not specified.' | WriteTo-StdOut
    }
    
} # function Run-Sqlcript()


function Get-SQlServerName([string]$InstanceName, [string]$NetName)
{
    trap 
    {
    	"[Get-SQlServerName] : [ERROR] Trapped exception ..." | WriteTo-StdOut
    	Report-Error
    }
    
    if ($null -ne $InstanceName)
    {
    	
        if ($null -ne $NetName)
        {
            if (('DEFAULT' -eq $InstanceName.ToUpper()) -or ('MSSQLSERVER' -eq $InstanceName.ToUpper()))
        	{
        		$ConnectToName = $NetName
            } 
            else 
            {
                $ConnectToName = $NetName+"\"+$InstanceName
          	}
        }
        else
        {
            '[Get-SQlServerName] : [ERROR] Required parameter -NetName was not specified.' | WriteTo-StdOut
        }
    }
    else
    {
        '[Get-SQlServerName] : [ERROR] Required parameter -InstanceName was not specified.' | WriteTo-StdOut
    }

    if ($true -eq $global:SQL:debug)
    {
        "[Get-SQlServerName] : [DEBUG] SQL Server name is: [{0}]" -f $ConnectToName | WriteTo-StdOut
    }
    
    return ($ConnectToName)
}

function Run-SqlDiagScript([PSobject]$InstanceVector)
{
    trap
    {
        '[Run-SqlDiagScript] : [ERROR] Trapped exception ...'
        Report-Error
    }

    if ($null -ne $InstanceVector) 
    {
        
        if (($null -ne $InstanceVector.NetName) -and ($null -ne $InstanceVector.InstanceName))
        {
            # Outfile name
            $SqlDiagOutFileName = "{0}_{1}_{2}_sp_sqldiag_Shutdown.OUT" -f $InstanceVector.NetName, $InstanceVector.InstanceName, (Get-LcidForSqlServer -SqlInstanceName $InstanceVector.InstanceName)

            # Script needs server name to connect to. Generate it 
            $SqlServerConnectToName = Get-SQlServerName -InstanceName $InstanceVector.InstanceName -NetName $InstanceVector.NetName
            
            Write-DiagProgress -Activity $sqlConfigurationCollectorStrings.ID_SQL_CollectSqlConfiguration -Status ($sqlConfigurationCollectorStrings.ID_SQL_CollectSqlConfigurationDesc + ": " + $instance.InstanceName)
            
            [string]$SqlDiagScriptFile=$null
            
            if ($null -ne $InstanceVector.SqlVersionMajor)
            {
                if ($global:SQL:SQL_VERSION_MAJOR_SQL2005 -eq $InstanceVector.SqlVersionMajor)
                {
                    $SqlDiagScriptFile=$SQL_SCRIPT_SQLDIAG_2005
                }
                elseif (($global:SQL:SQL_VERSION_MAJOR_SQL2008 -eq $InstanceVector.SqlVersionMajor) -or ($global:SQL:SQL_VERSION_MAJOR_SQL2008R2 -eq $InstanceVector.SqlVersionMajor))
                {
                    $SqlDiagScriptFile=$SQL_SCRIPT_SQLDIAG_2008
                }
                elseif ($global:SQL:SQL_VERSION_MAJOR_SQL2012 -eq $InstanceVector.SqlVersionMajor) 
                {
                    $SqlDiagScriptFile=$SQL_SCRIPT_SQLDIAG_2012
                }
                elseif ($global:SQL:SQL_VERSION_MAJOR_SQL2014 -eq $InstanceVector.SqlVersionMajor) 
                {
                    $SqlDiagScriptFile=$SQL_SCRIPT_SQLDIAG_2014
                }
                else
                {
                    $SqlDiagScriptFile=$SQL_SCRIPT_SQLDIAG_2014
                    '[Run-SqlDiagScript] : [ERROR] Unexpected server major version: [{0}].  SQL Diag script will assume latest version' -f $InstanceVector.SqlVersinoMajor | WriteTo-StdOut
                }
            	
                if (($null -ne $SqlDiagScriptFile) -and ([String]::Empty -ne $SqlDiagScriptFile))
                {
                    # Call wrapper to validate parameters and call Execte-SqlScript 
                    Run-SqlScript -SqlServerName $SqlServerConnectToName -ScriptToExecute $SqlDiagScriptFile -OutFileName $SqlDiagOutFileName -SectionDescription ("SQL Server Diagnostic Scripts for instance: {0}" -f $SqlServerConnectToName) -FileDescription 'SQLDIAG'
                }
                
            } # if ($null -ne $InstanceVector.SqlVersionMajor)
            else
            {
                '[Run-SqlDiagScript] : [ERROR] SqlVersionMajor value in the InstanceVector is null' | WriteTo-StdOut
            }
            
        } # if (($null -ne $InstanceVector.NetName) -and ($null -ne $InstanceVector.InstanceName))
        else
        {
            '[Run-SqlDiagScript] : [ERROR] Either the InstanceName: [{0}] or NetName: [{1}] was null in the passed InstanceVecor' -f $InstanceVector.InstanceName, $InstanceVector.NetName | WriteTo-StdOut
        }
        
    } # if ($null -ne $InstanceVector) 
    else
    {
        '[Run-SqlDiagScript] : [ERROR] Required parameter -InstanceVector was not specified' | WriteTo-StdOut
    }

}

function Run-SqlAlwaysOnDiagScript([PSobject]$InstanceVector)
{
    trap
    {
        '[Run-SqlAlwaysOnDiagScript] : [ERROR] Trapped exception ...'
        Report-Error    
    }
    
    if ($null -ne $InstanceVector) 
    {
        if (($null -ne $InstanceVector.NetName) -and ($null -ne $InstanceVector.InstanceName))
        {
            # Outfile name
            $AlwaysOnOutFileName = "{0}_{1}_{2}_AlwaysOn.OUT" -f $InstanceVector.NetName, $InstanceVector.InstanceName, (Get-LcidForSqlServer -SqlInstanceName $InstanceVector.InstanceName)

            # Script needs server name to connect to. Generate it 
            $SqlServerConnectToName = Get-SQlServerName -InstanceName $InstanceVector.InstanceName -NetName $InstanceVector.NetName
          
            # Update dialog with current progress
            Write-DiagProgress -Activity $sqlConfigurationCollectorStrings.ID_SQL_CollectSqlConfiguration -Status ($sqlConfigurationCollectorStrings.ID_SQL_CollectSqlAlwaysOnDesc + ": " + $InstanceVector.InstanceName)
           
            Run-SqlScript -SqlServerName $SqlServerConnectToName -ScriptToExecute $SQL_SCRIPT_ALWAYSON -OutFileName $AlwaysOnOutFileName -SectionDescription ("SQL Server Diagnostic Scripts for instance: {0}" -f $InstanceVector.InstanceName) -FileDescription 'AlwaysOn'
        
        } # if (($null -ne $InstanceVector.NetName) -and ($null -ne $InstanceVector.InstanceName))
        else
        {
            '[Run-SqlAlwaysOnDiagScript] : [ERROR] Either the InstanceName: [{0}] or NetName: [{1}] was null in the passed InstanceVecor' -f $InstanceVector.InstanceName, $InstanceVector.NetName | WriteTo-StdOut
        }
        
    } # if ($null -ne $InstanceVector) 
    else
    {
        '[Run-SqlAlwaysOnDiagScript] : [ERROR] Required parameter -InstanceVector was not specified' | WriteTo-StdOut
    }
    
} # function Run-SqlAlwaysOnDiagScript()

$Error.Clear()           
trap 
{
	"[DC_GetSqlServerConfiguration] : [ERROR] Trapped exception ..." | WriteTo-StdOut
	Report-Error
}
	
Import-LocalizedData -BindingVariable sqlConfigurationCollectorStrings

if ($true -eq $global:SQL:Debug)
{
    $CollectSqlDiag=$true
	$CollectAlwaysOnInfo=$true
}

# Check to be sure that there is at least one SQL Server installation on target machine before proceeding
#
if (Check-SqlServerIsInstalled -eq $true)
{
	# If $instance is null, get errorlogs for all instances installed on machine
	#
	if ($null -eq $instances)
	{
		$instances = Enumerate-SqlInstances -Offline
	}

	if ( $instances -ne $null )
	{
		foreach ($instance in $instances)
		{
            if ('DEFAULT' -eq $instance.InstanceName.ToUpper()) {$instance.InstanceName = 'MSSQLSERVER'} 
            
			if ($global:SQL:SERVICE_STATUS_RUNNING -eq $instance.ServiceStatus)
			{
                
                if ($true -eq $CollectSqlDiag)
                {
            		Run-SqlDiagScript -InstanceVector $instance
                }
                
                # If this is a SQL 2012 instance we will collect AlwaysOn information if so directed
                if (($global:SQL:SQL_VERSION_MAJOR_SQL2012 -le $instance.SqlVersionMajor) -and ($true -eq $CollectAlwaysOnInfo))
                {
                    Run-SqlAlwaysOnDiagScript -InstanceVector $instance                    
                }
                
			} 
			else 
			{
				"[DC_GetSqlServerConfiguration] : [INFO] Diagnostic scripts will not be collected for instance {0} because it is not started.  Current status is: {1}" -f $instance.InstanceName, $instance.ServiceStatus | WriteTo-StdOut
    		}
            
        } # foreach ($instance in $instances)
        
	} # if ( $instances -ne $null )
    else
    {
        "[DC_GetSqlServerConfiguration] : [ERROR] SQL Server appears to be installed on server: [{0}] yet no installed instances were found" -f $env:ComputerName | WriteTo-StdOut
    }
}
else 
{
    "[DC_GetSqlServerConfiguration] : No sql server instances are installed on: [{0}]" -f $ComputerName | WriteTo-StdOut 
}
    
