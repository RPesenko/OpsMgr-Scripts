﻿#************************************************
# DC_CollectSecurityEventLog.ps1
# Version 1.0
# Date: 05-15-2013, 10-22-2020
# Author: Matt
# Description: This script calls TS_GetEvents.ps1 to export Security event logs
#************************************************
Param($Days="1")

trap [Exception] 
{
	WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText ("Error export the security event logs.")
	continue
}

Import-LocalizedData -BindingVariable SecurityEventLogsStrings

#_#$CollectSecurityLog = Get-DiagInput -Id ID_CollectSecurityLog
write-host "Please choose to Security Event Log" -ForegroundColor Yellow
$CollectSecurityLog = Read-Host 'Do you allow to collect Security Event Log? [Yes|No] '  #_# UserInput

if($CollectSecurityLog -match "Y") #_# 
{
	"User selected [$CollectSecurityLog] to collect the security event log" | WriteTo-StdOut -ShortFormat
	$EventLogNames = "Security"
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -Days $Days -OutputFormats "EVTX"
}
