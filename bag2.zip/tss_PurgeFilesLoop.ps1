<# Filename: tss_PurgeFilesLoop.ps1 [-NrFilesToKeep] [-PollInterval] [-Folderpath] [-FilenameList] [-StopTokenFile] [-DateTime] [-Caller] [-EtlBuf] [-ProcMNrFilesToKeep]
Purpose:  avoiding disk space exhaustion, keep the number of trace & ProcMon files at a maximum of [-NrFilesToKeep]
		  the script will terminate once the stop condition [-StopTokenFile] is met

 Copyright ^(C^) Microsoft. All rights reserved.
 THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
 IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

Last-Update by waltere: 2020-09-03

#>

<#
.SYNOPSIS
The script helps to avoid disk space exhaustion, keep the number of trace & ProcMon files at a maximum of [-NrFilesToKeep]

.DESCRIPTION
The script purges older trace files and keeps only -NrFilesToKeep files 
Usage:
 .\tss_PurgeFilesLoop.ps1 [-NrFilesToKeep] [-PollInterval] [-Folderpath] [-FilenameList] [-StopTokenFile] [-DateTime] [-Caller] [-ProcMNrFilesToKeep]

If you get an error that running scripts is disabled, run 
	Set-ExecutionPolicy Bypass -force -Scope Process
and verify with 'Get-ExecutionPolicy -List' that no ExecutionPolicy with higher precedence is blocking execution of this script.
Then run the script again.

Alternate method#1: to sign .ps1 scripts: run in elevated CMD 
  tss_PS1sign.cmd Get-psSDP
Alternate method#2: If execution is blocked by machine policy, run in elevated Powershell: 
 Set-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\PowerShell -Name ExecutionPolicy -Value ByPass

.PARAMETER NrFilesToKeep
  This switch will keep only NrFilesToKeep of youngest trace files for each category
.PARAMETER PollInterval
  This switch controls how often in seconds interval purge/file deletion is done.
.PARAMETER Folderpath
 This is the data location on disk to monitor and purge.
.PARAMETER FilenameList
  This switch controls the file name/extensions to purge
.PARAMETER StopTokenFile
  This switch watches for existence of a stop trigger Filename for termination condition
.PARAMETER Caller
  This switch tells the script which caller invoked it and if it should look for trace ETL files or Procmon files
.PARAMETER DateTime
  date/time of start of repro
.PARAMETER EtlBuf
  max size of ETL trace file
.PARAMETER ProcMNrFilesToKeep
  This switch will keep only max 2x ProcMonKeep of youngest ProcMon files

.PARAMETER CreateTestFiles
  This switch is for testing only
 
.EXAMPLE
 .\tss_PurgeFilesLoop.ps1 -NrFilesToKeep 10 -PollInterval 2 Folderpath "C:\MS_DATA" -FilenameList "*dns*.etl"
 for purging "*dns*.etl" files in interval of 2 sec and keep latest 10 files in folder "C:\MS_DATA"
 
 
.LINK
email: waltere@microsoft.com
https://github.com/CSS-Windows/WindowsDiag/tree/master/ALL/TSS
#>

[CmdletBinding()]
PARAM (
	[string]$Folderpath = (Split-Path $MyInvocation.MyCommand.Path -Parent),
	[string]$FilenameList = "etl/procmon/ndiscap/NMcap",
	[int32]$NrFilesToKeep = 10,
	[int32]$ProcMNrFilesToKeep = 5,
	[string]$Caller,
	[int32]$EtlBuf = 1024,
	[int32]$PollInterval = 9,
	[string]$StopTokenFile = "tss_StopTokenFile.tmp",
	$DateTime = "$(Get-Date -UFormat "%D %R:%S")",
	[switch]$CreateTestFiles = $False,
	[switch]$WhatIf = $False
)

$ScriptVersion=1.7	#2020-09-03

[string]$Script:LogFileScript = $Folderpath +"\"+ $ENV:ComputerName + "__Purge-Files-Log.txt"
$DirScript=(Split-Path $MyInvocation.MyCommand.Path -Parent)
if ($env:PROCESSOR_ARCHITECTURE -match "AMD64") {$ProcArch="x64"} else {$ProcArch="x86"}
$MS_ProcM="$DirScript\$ProcArch\Procmon.exe"
[int32]$Script:ProcMonBlockNr=0
Unblock-File $MS_ProcM -Confirm:$false
$Host.UI.RawUI.BackgroundColor = ($bckgrnd = 'DarkGreen')

#region  ::::: [Functions] -----------------------------------------------------------#
function CreateTestFiles ([switch]$CreateTestFiles)
{
	# SYNOPSIS: Testing: Create 12 test files, 1 second after each other
	1..12 | % {
		Remove-Item -Path "$Folderpath\$_.txt" -EA SilentlyContinue
		$_ | Out-File "$Folderpath\$_.txt"
		Write-Host "..created $_.txt "
		Start-Sleep -Seconds 1
	}
}
function Start-Procmon {
# SYNOPSIS: Start Procmon
  # force a queue depth of 1 million // check if procmon was run before
  Set-ItemProperty "HKCU:\Software\Sysinternals\Process Monitor" -Name "HistoryDepth" -Value 1
  Push-Location "$DirScript\$ProcArch"
  Unblock-File .\Procmon.exe -Confirm:$false
	#load config - if file exists in script folder: /LoadConfig ProcmonConfiguration.pmc -, avoid it if you don't know exactly, what you are looking for! Otherwise just trace all with default settings
  .\Procmon.exe /AcceptEula /BackingFile `"$tracePath\$Date_time\$env:COMPUTERNAME`_procmon.pml`" /NoFilter /Minimized
  Pop-Location
}

function Stop-Procmon {
# SYNOPSIS: Stop Procmon
	Start-Process "$Script:ScriptPath\Procmon.exe" -ArgumentList "/terminate"
}

function RestartProcMon ($ProcMNrFilesToKeep)
{
	# SYNOPSIS: ProcMon writes blocks with N ProcMNrFilesToKeep files, then terminates and restarts; delete N-2 block
	Clear-ItemProperty "HKCU:\Software\Sysinternals\Process Monitor" -Name "LogFile"
	Push-Location "$DirScript\$ProcArch"
	
	$Script:ProcMonBlockNr +=1
	$ProcmonNminus2=$Script:ProcMonBlockNr-2
	Write_Transcript "[Restart ProcMon $Script:ProcMonBlockNr]"
	Write-Debug "[RestartProcMon $(Get-Date -UFormat "%R:%S")] Unblock-File $MS_ProcM -Confirm:$false" 
	 Unblock-File -Path $MS_ProcM -Confirm:$false
	Write-Verbose "[RestartProcMon $(Get-Date -UFormat "%R:%S")] [$Script:ProcMonBlockNr]... terminate + restarting Procmon Cnt= $Script:ProcMonBlockNr - DEL: ProcMon_$ProcmonNminus2 * - LoopCnt= $Script:LoopCnt - Keep: $ProcMNrFilesToKeep"
	Write-Verbose "[RestartProcMon $(Get-Date -UFormat "%R:%S")] Start-Process $MS_ProcM -ArgumentList '/Terminate'"
	 Start-Process $MS_ProcM -ArgumentList "/Terminate"

	$PM_BackingFile=$Folderpath +"\"+ $env:COMPUTERNAME +"_"+ $DateTime +"_ProcMonPurge_"+ $Script:ProcMonBlockNr +".pml"
	Write-Debug "[RestartProcMon $(Get-Date -UFormat "%R:%S")] BackingFile: $PM_BackingFile"
	Write-Verbose "[RestartProcMon $(Get-Date -UFormat "%R:%S")] Start-Process $MS_ProcM -ArgumentList '/waitforidle' -wait" # https://trwagner1.wordpress.com/2010/03/25/using-powershell-with-process-monitor/
	 Start-Process $MS_ProcM -ArgumentList "/waitforidle" -wait
	Write-Verbose "[RestartProcMon $(Get-Date -UFormat "%R:%S")] Start-Process $MS_ProcM -ArgumentList '/AcceptEula /BackingFile $PM_BackingFile /NoFilter /Minimized'"
	 Start-Process $MS_ProcM -ArgumentList "/AcceptEula /BackingFile $PM_BackingFile /NoFilter /Minimized" # /waitforidle" -wait
	Write-Verbose "[RestartProcMon $(Get-Date -UFormat "%R:%S")] Start-Process $MS_ProcM -ArgumentList '/waitforidle' -wait" # https://trwagner1.wordpress.com/2010/03/25/using-powershell-with-process-monitor/
	 Start-Process $MS_ProcM -ArgumentList "/waitforidle" -wait
	# remove older files
	Start-Sleep -Seconds 2
	#Get-ChildItem -Path "$Folderpath\*ProcMon*_$ProcmonNminus2*" | Where-Object {-not $_.PsIsContainer}| Remove-Item -Force 
	Get-ChildItem -Path "$Folderpath\*ProcMon*.pml" -Recurse| Where-Object {-not $_.PsIsContainer}| sort CreationTime -desc| select -Skip $ProcMNrFilesToKeep | Remove-Item -Force -EA SilentlyContinue
	Pop-Location
}
function Write_Transcript ($Content) {"$(Get-date -Format G) | $($Content)" | Out-File $Script:LogFileScript -Append }
function Write-Log {
	# SYNOPSIS: Writes script information to a log file and to the screen when -Verbose is set.
	[CmdletBinding()]param([string]$text, [Switch]$tee = $false, [string]$foreColor = $null, [string]$backColor = "DarkBlue")
	$foreColors = $backColors = "Black","Blue","Cyan","DarkBlue","DarkCyan","DarkGray","DarkGreen","DarkMagenta","DarkRed","DarkYellow","Gray","Green","Magenta","Red","White","Yellow"
	# check the log file, create if missing
	$isPath = Test-Path $LogFileScript
	if (!$isPath) {
		"tss_PurgeFilesLoop.ps1 v$ScriptVersion Log started on $($ENV:ComputerName) - $($Script:osVer) - $($Script:osNameLong) " 	| Out-File $LogFileScript -Force
		"Local log file path: $LogFileScript" 														| Out-File $LogFileScript -Append
		"PowerShell version:  $Script:PSver " 														| Out-File $LogFileScript -Append
		"Start time (UTC):    $((Get-Date).ToUniversalTime())" 										| Out-File $LogFileScript -Append
		"Start time (Local):  $((Get-Date).ToLocalTime()) $(if ((Get-Date).IsDaylightSavingTime()) {([System.TimeZone]::CurrentTimeZone).DaylightName} else {([System.TimeZone]::CurrentTimeZone).StandardName})`n" | Out-File $LogFileScript -Append
	Write-Verbose "$(Get-Date -Format "HH:mm:ss") Local log file path: $LogFileScript"
  }
  # write to log
  "$(Get-date -Format G) | $text" | Out-File $LogFileScript -Append
  # write text verbosely
  Write-Verbose $text
  if ($tee)
  {
    # make sure the foreground color is valid
    if ($foreColors -contains $foreColor -and $foreColor)
    {
      Write-Host -ForegroundColor $foreColor -BackgroundColor $backColor $text
    } else {
      Write-Host $text
    }
  }
} # end Write-Log
#endregion  ::::: [Functions] -----------------------------------------------------------#
#region ::::: CONSTANTS AND VARIABLES ------------------------------------------------#

# OS version
#[void]( $Script:OSinfo = (Get-CimInstance Win32_OperatingSystem) )
$Script:osVer = (Get-WmiObject win32_operatingsystem).Version
$Script:osNameLong = $Script:osName = (Get-WmiObject win32_operatingsystem).Name
$Script:osMajVer = [System.Environment]::OSVersion.Version.Major
$Script:osMinVer = [System.Environment]::OSVersion.Version.Minor
$Script:osBldVer = [System.Environment]::OSVersion.Version.Build
$Script:PSver = $PSVersionTable.PSVersion.Major

#endregion ::::: CONSTANTS AND VARIABLES ---------------------------------------------#

$invocation = (Get-Variable MyInvocation).Value
$scriptName = $MyInvocation.MyCommand.Name
$ScriptBeginTimeStamp = Get-Date
if ($CreateTestFiles.IsPresent) { CreateTestFiles }

#region  ::::: [MAIN] ----------------------------------------------------------------#
Write-Log -tee -foreColor Yellow -backColor black "*** Please DON'T CLOSE this PURGE window while TSS is running, in order to avoid running out of diskspace."
Write-Log -tee "Script will stop automatically once $StopTokenFile exists"
Write-Log -tee "  Trace NrFilesToKeep   : $NrFilesToKeep"
Write-Log -tee "  EtlBuffer size        : $EtlBuf MB"
Write-Log -tee "  ProcMon pml keep      : $ProcMNrFilesToKeep"
Write-Log -tee "  PollInterval          : $PollInterval seconds"
Write-Log -tee "  Repro Start time      : $DateTime"
Write-Log -tee "  Data Folder Folderpath: $Folderpath"
Write-Log -tee "  Caller                : $Caller"
Write-Log -tee "  FilenameList to purge : '$FilenameList'`n"

$host.ui.RawUI.WindowTitle = "DON'T close this PS Purge Window keep $NrFilesToKeep trace files, $ProcMNrFilesToKeep ProcMon, Interval: $PollInterval sec"
Write-Log -tee -foreColor Cyan -backColor black "[ACTION] Purging files:`n Keep only latest $ProcMNrFilesToKeep ProcMon and $NrFilesToKeep Trace (*.Etl or *cap*) files in $Folderpath with filenames containing '$FilenameList', PollInterval: $PollInterval sec `n"

$Script:LoopCnt = 0
$Script:PMpurgeCnt=$ProcMNrFilesToKeep

# calculate disk space
#$FileCriteriaList = ($FilenameList.Trim() -split " ") 
$FileCriteriaList = ($FilenameList.Trim("/"," ") -split "/") 
Write-Log -tee "FileCriteriaList: '$FileCriteriaList' `n "
$calcETL = $($NrFilesToKeep * $($FileCriteriaList).count * $EtlBuf )
$calcProcM = $($ProcMNrFilesToKeep * 300)
Write-Log -tee -foreColor Cyan -backColor black "[INFO] Diskspace (estimated):`n For a longtime repro: Expected minimum required diskspace on $Folderpath is: $calcETL MB ETL's + $calcProcM MB ProcMon = $($calcETL + $calcProcM) MB total, excluding Perfmon/iDNA/ProcDump `n"

Write-Log -tee -foreColor Green -backColor black "...waiting for 'TSS OFF' or stop condition met to stop."
Write_Transcript "LoopCnt: "

# consider to use LastWriteTime instead of CreationTime to get results consistent with that shown in Windows Explorer.
While ( -not (Test-Path $StopTokenFile)) {
	Write-Host -backgroundColor Blue -foregroundColor Cyan -NoNewline -Object "." -Separator .
	Start-Sleep -Seconds $PollInterval
	# ETL purge, including *ndiscap* *NMcap* chained traces
	ForEach ($FileCrit in $FileCriteriaList) {
		$FileCrit = "*" + $FileCrit + "_*"	# file name criteria must end with '_'
		write-Debug "[Purge-Main] FileCrit: $FileCrit"
		#_# Write-Log -tee "[Purge-Main] FileCrit: $FileCrit"
		Get-ChildItem -Path "$Folderpath\*$FileCrit" -Exclude *ProcMon* -Recurse| Where-Object {-not $_.PsIsContainer}| sort CreationTime -desc| select -Skip $NrFilesToKeep | Remove-Item -Force 
		}
	$Script:LoopCnt +=1
	"$Script:LoopCnt " | Out-File $Script:LogFileScript -Append -NoNewline
	# ProcMon purge
	$PMfilesCount = ((Get-ChildItem -Path "$Folderpath\*.pml" | Where-Object {-not $_.PsIsContainer}).count)
	if ($PMfilesCount) {
		$PM_nr_filesCount = ((Get-ChildItem -Path ($Folderpath +"\*procmon*_"+ $Script:ProcMonBlockNr +"*.pml") | Where-Object {-not $_.PsIsContainer}).count)
		Write-Verbose " [ $Script:LoopCnt] total PMfilesCount: $PMfilesCount - Block PM-Nr: $Script:ProcMonBlockNr - PMpurgeCnt $Script:PMpurgeCnt -ge keep: $ProcMNrFilesToKeep ? PM_nr_filesCount= $PM_nr_filesCount -ge $ProcMNrFilesToKeep ?"
		if (($Caller -match "ProcMon") -and ($PMfilesCount -gt $ProcMNrFilesToKeep) -and ($PM_nr_filesCount -ge $ProcMNrFilesToKeep))  { # consider -clike instead of -match
			Write-Verbose "[Purge-Main] Current Procmon Files: $PMfilesCount, $Script:LoopCnt purging... `n"
			RestartProcMon $ProcMNrFilesToKeep
			$Script:PMpurgeCnt=0
		}
	}
	$Script:PMpurgeCnt +=1
}

# doublecheck if Procmon is stopped
#	Start-Process $MS_ProcM -ArgumentList "/Terminate"
	$p = Get-Process -Name "procmon" -EA SilentlyContinue
	if ($p) { Write-Log -tee ".. sending a second 'ProcMon.exe /Terminate'"
			  Start-Process $MS_ProcM -ArgumentList "/Terminate"
			  #Stop-Process -InputObject $p		# avoid killing as it might corrupt *.pml
			  #Get-Process | Where-Object {$_.HasExited}
			}


Write-Log -tee "`n[Purge-Main] End-Trigger: $StopTokenFile exists"
$ScriptEndTimeStamp = Get-Date
$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
Write-Log -tee -backColor Gray -foreColor Black "[Purge-Main] $(Get-Date -UFormat "%R:%S") Done on this PC $env:COMPUTERNAME; script $scriptName $ScriptVersion took $Duration - will close in 20 sec`n"
Start-Sleep -Seconds 20
#endregion  ::::: [MAIN] -------------------------------------------------------------#

#region  ::::: [ToDo] ----------------------------------------------------------------#
<# TodDo: - done roughly: calculate max disk space usage -> now fully in tss_PrereqCheck.ps1
		-  log all purge actions logfile
  Info: 4577110 How to setup unattended circular ProcMon capture
#>
#endregion  ::::: [ToDo] -------------------------------------------------------------#