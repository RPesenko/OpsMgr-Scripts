<# Filename: tss_EventCreate.ps1 [-EventID -EvtLogName] [-Computername]
:: Purpose:  create an Event log entry in [EvtLogName] with [Event ID]
::           the tss.cmd script has a switch to stop data collection upon such event.
:: Example: tss_EventCreate.cmd 999 Application
::
::  Copyright ^(C^) Microsoft. All rights reserved.
::  THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
::  IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
::
:: Last-Update by waltere: 2020-08-13

The tss_EventCreate.cmd can only write event ID 0 - 1000 using EVENTCREATE.exe

:: in Powershell 
:: 1.  do this once to register a new Event Source ( not needed for writing events with a known Source: 
   New-EventLog –LogName "Application" –Source 'TSS'
:: 2.  Write-EventLog -LogName "Application" -Source "TSS" -EventID 15004 -EntryType Information -Message "TSS added this EventID as stop trigger." -Category 1 -RawData 10,20 -ComputerName $Env:Computername
:: in CMD script you would invoke: Powershell "Write-EventLog -LogName 'Application' -Source 'TSS' -EventID 999 -EntryType Information -Message 'TSS added this EventID as stop trigger.' -Category 1 -RawData 10,20 -ComputerName $Env:Computername"

:: for testing it is sufficient to specify an exiting "Source", just look up an esiting eventlog entry
example:
  Write-EventLog -LogName "Application" -Source "Outlook" -EventID 59 -EntryType Information -Message "Test this EventID as stop trigger." -Category 1 -RawData 10,20 -ComputerName $Env:Computername
#>

<#
.SYNOPSIS
	Write any EventID into any Eventlog file, i.e. for testing a TSS Stop:Evt:<ID> trigger
	see Get-Help Write-EventLog -detailed
	for registering an own source, use: New-EventLog –LogName "Application" –Source 'TSS'

.DESCRIPTION  
	Script will write any EventID into any Eventlog file, i.e. for testing a TSS Stop:Evt:<ID> trigger
	You can also register a new event Source 'TSS', but this source will be bound to the eventlog name. so if you change the eventlog name you need to specify a new source-name, or use Unregister-Event.
	Please look up any existing event in the <eventlog>.evtx file you are interested in and remember the ID and Source

.NOTES

.PARAMETER LogName
 	Specify the name of the Windwos Event Log, default = "Application"
	Default is current folder
.PARAMETER Source
	The Event Source, which is known to exist in the given EventLog, default = "Outlook"
.PARAMETER EntryType
	The type of Event, default = "Warning"
.PARAMETER Message
	The Event message you want to log, example "Testing this EventID as stop trigger. Event-ID was sent by computer $Env:Computername"
.PARAMETER Computername
	Which computer do you want to write the eventlog, default = $Env:Computername	
.PARAMETER EventID
	default EventID = 999, because TSS listens always to EventID 999 in addition to other IDs specified in trigger Stop:Evt:<ID>
	
.PARAMETER UseExitCode
	 This switch will cause the script to close after the error is logged if an error occurs.
	 It is used to pass the error number back to the task scheduler or CMD script.

.EXAMPLE
	Write-EventLog -LogName "Application" -Source "Outlook" -EventID 59 -EntryType Information -Message "Test this EventID as stop trigger." -Category 1 -RawData 10,20 -ComputerName $Env:Computername
	Example 1: will  write the EventID 59 into local or remote computers "Application" Eventlog with the given informational message
#>

param(
	[string]$LogName 	= "Application",						# Application","System",""
	[string]$Source 	= "Outlook",							# Source module, which is known to exist in the given EventLog
	[string]$EntryType 	= "Warning",							# "Information","Warning","Error"
	[string]$Computername = "$Env:Computername",				# Remote Computername
	[string]$Username 	= "$Env:USERDOMAIN\$Env:Username",		# (domain) user who has permission to write into the remote computer'S eventlog
	[string]$Message 	= "StopMe Event ID: $EventID test from script $scriptName in order to stop data collection. Event was sent by user $Username on computer $Env:Computername at $SendTimeStamp UTC",
	[int32]$EventID 	= 999,									# Event ID number
	[string]$Folderpath = $(Split-Path $MyInvocation.MyCommand.Path -Parent),
	[switch]$UseExitCode = $true								# This will cause the script to bail out after the error is logged if an error occurs.
)


#region: customization section of script, logging configuration ----------------------#
	$LogFileScript 	= $Folderpath +"\"+ $ENV:ComputerName + "__WriteEventLog.txt"
	$ErrorThrown 	= $null
	$ScriptVersion	= 1.00	#2020-08-13
#endregion: customization section of script, logging configuration ------------------#
$scriptName = $MyInvocation.MyCommand.Name
$ScriptBeginTimeStamp = Get-Date

#region: Helper Functions -----------------------------------------------------------#
function ExitWithCode ($Ecode) {
	# set ErrorLevel to be picked up by invoking CMD script
	if ( $UseExitCode ) {
		WriteInfo "Return Code $Ecode"
		#error.clear()	# clear script errors
		exit $Ecode
		} #end UseExitCode
}
#endregion: Helper Functions

#region: MAIN

try {
	#$SendTimeStamp = $(Get-Date -Format hh:mm:ss)
	$SendTimeStamp = (Get-Date).ToUniversalTime().ToString("yyMMdd-HHmmss.fffffff")
	Write-Host "...sending Event ID $EventID Type $EntryType to $LogName eventlog on $Computername, sent by $Username at $SendTimeStamp UTC from $Env:Computername"
	Write-EventLog -LogName $LogName -Source $Source -EventID $EventID -EntryType $EntryType -Message "This is StopMe Event ID: $EventID from script $scriptName in order to stop data collection. Event was sent by user $Username on computer $Env:Computername at $SendTimeStamp UTC" -Category 1 -ComputerName $Env:Computername
}
catch {
	Write-Host -ForegroundColor Red -BackgroundColor Black "An Error occured"
	Write-Host -ForegroundColor Red -BackgroundColor Black $error[0].Exception.Message
	$ErrorThrown = $true
}
finally {
	$ScriptEndTimeStamp = Get-Date
	$LogLevel = 0
	Write-Host -ForegroundColor Black -BackgroundColor Gray "`nScript $scriptName v$ScriptVersion execution finished. Duration interaction: $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)"

  if($ErrorThrown) {Throw $error[0].Exception.Message}
}
#endregion: MAIN