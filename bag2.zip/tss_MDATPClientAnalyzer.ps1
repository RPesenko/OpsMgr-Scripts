<#
.SYNOPSIS
 
.NOTES
    Author: MDATP OPS Team
    Date/Version: See $ScriptVer
	
	with adjusments for running inside TSS # 2020-09-06
	:: Source from https://aka.ms/BetaMDATPanalyzer 
#>
param (
    [string]$outputDir = $PSScriptRoot, 
    ##Enter Url or IpAddress for Proxy
    [Alias("p")][string]$manualProxy = "", 
    ## To collect netsh traces -n 
    [Alias("n")][switch]$netTrace,
    [Alias("w", "wfp")][switch]$wfpTrace,
    ##To collect Sense performance traces '-l' or '-h'
    [Alias("l")][switch]$wprpTraceL,
    [Alias("h")][switch]$wprpTraceH,
	##To collect Sense app compat traces '-c'
    [Alias("c")][switch]$AppCompatC,
	##To collect Sense dumps '-d'
	[Alias("d")][switch]$CrashDumpD,
	##To collect traces for isolation issues '-i'
	[Alias("i")][switch]$NetTraceI,
	##To collect boot traces issues at startup '-b'
	[Alias("b")][switch]$BootTraceB,
	##To collect traces for WD AntiVirus pref issues '-a'
	[Alias("a")][switch]$WDPerfTraceA,
	##To collect verbose traces for WD AntiVirus issues '-v'
	[Alias("v")][switch]$WDVerboseTraceV,
	##To collect verbose traces for DLP issues '-t'
	[Alias("t")][switch]$DlpT,
	##To collect quick DLP Diagnose run '-q'
	[Alias("q")][switch]$DlpQ,
	##To prepare the machine for full dump collection '-z'
	[Alias("z")][switch]$FullCrashDumpZ,
	##To set the machine for remote data collection '-r'
	[Alias("r")][switch]$RemoteRun,
	##To set the minutes to run for data collection '-m'
	[Alias("m")][int]$MinutesToRun = "5",
	##To crash the machine and create a memory dump immediately '-k'
	[Alias("K")][switch]$notmyfault
)

#region  ::::: Configruation parameters ----------------------------------------------#
# Global variables
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8  # MDATPClientAnalyzer.exe outputs UTF-8, so interpret its output as such
$ProcessWaitMin=5	# wait max minutes to complete MSinfo32
#_# $ToolsDir = Join-Path $outputDir "Tools"
 $ToolsDir = Join-Path $PSScriptRoot "DefenderTools"
 $DirScript=(Split-Path $MyInvocation.MyCommand.Path -Parent)
 if ($env:PROCESSOR_ARCHITECTURE -match "AMD64") {$ProcArch="x64"} else {$ProcArch="x86"}	# for PromMon, ProcDump and NotMyFault

$buildNumber = ([System.Environment]::OSVersion).Version.build

# Define outputs
$resultOutputDir = Join-Path $outputDir "MDATPClientAnalyzerResult"
$psrFile = Join-Path $resultOutputDir "Psr.zip"
$ProcMonlog = Join-Path $resultOutputDir "Procmonlog.pml"
$connectivityCheckFile = Join-Path $resultOutputDir "MDATPClientAnalyzer.txt"
$connectivityCheckUserFile = Join-Path $resultOutputDir "MDATPClientAnalyzer_User.txt"
$MsSenseDump = Join-Path $resultOutputDir "MsSense.dmp"
$MsSenseSDump = Join-Path $resultOutputDir "MsSenseS.dmp"
$outputZipFile = Join-Path $outputDir "MDATPClientAnalyzerResult.zip"
$WprpTraceFile = Join-Path  $resultOutputDir "FullSenseClient.etl"
$XmlLogFile = Join-Path $resultOutputDir "MDATPClientAnalyzer.xml"
$OSPreviousVersion = $false
$AVPassiveMode = $false
$EndpointList = Join-Path $ToolsDir "endpoints.txt"
$ScriptVer = "17082020"
#endregion ::::: Configruation parameters --------------------------------------------#

#region  ::::: [Functions] -----------------------------------------------------------#
# function to read Registry Value
function Get-RegistryValue { param (
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$Path,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$Value
    )

    if (Test-Path -path $Path) {
        return Get-ItemProperty -Path $Path | Select-Object -ExpandProperty $Value -ErrorAction silentlycontinue
    } else {
        return $false
    }
}

# This telnet test does not support proxy as-is
Function TelnetTest($RemoteHost, $port) { 
    [int32]$TimeOutSeconds = 10000
	Try {
		$tcp = New-Object System.Net.Sockets.TcpClient
		$connection = $tcp.BeginConnect($RemoteHost, $Port, $null, $null)
		$connection.AsyncWaitHandle.WaitOne($TimeOutSeconds,$false)  | Out-Null 
		if($tcp.Connected -eq $true) {
			$ConnectionResult = "Successfully connected to Host: $RemoteHost on Port: $Port"
		} else {
			$ConnectionResult = "Could not connect to Host: $RemoteHost on Port: $Port"
		}
    } 
	Catch {
		$ConnectionResult = "Unknown Error"
	}
	return $ConnectionResult
}

# Function to write messages into XML
function WriteMessage($severity, $id, $desc) {
    $descLine = ((Get-Date).ToString("u") + " [$severity] $id : $desc" )
    if ($severity -eq "error") {
        Write-Host -BackgroundColor Red -ForegroundColor Yellow $descLine
    } elseif ($severity -eq "warning") {
        Write-Host -ForegroundColor Yellow $descLine
    } else {
        Write-Host $descLine
    }

    $xmlNode = $script:xmlRoot.AppendChild($xmldoc.CreateElement("msg"))
    $xmlNode.SetAttribute("severity", $severity)
    $xmlNode.SetAttribute("id", $id)
    $xmlNode.SetAttribute("desc", $desc)

    $descLine | Out-File $connectivityCheckFile -append
}

# Initialize XML log - for consumption by external parser
function InitXmlLog {
    $script:xmlDoc = New-Object System.Xml.XmlDocument
    $script:xmlRoot = $xmlDoc.AppendChild($xmlDoc.CreateElement("MDATP"))
    $script:xmlRoot.SetAttribute("script_version", $ScriptVer)
}

function SaveXmlLog {
    $script:xmlDoc.Save($XmlLogFile)
}

function Format-XML ([xml]$xml)
{
    $StringWriter = New-Object System.IO.StringWriter
    $XmlWriter = New-Object System.XMl.XmlTextWriter $StringWriter
    $xmlWriter.Formatting = [System.Xml.Formatting]::Indented
    $xml.WriteContentTo($XmlWriter)
    Write-Output $StringWriter.ToString()
}

function ShowDlpPolicy($policyName)
{
    $byteArray = Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection' -Name $policyName
    $memoryStream = New-Object System.IO.MemoryStream(,$byteArray)
    $deflateStream = New-Object System.IO.Compression.DeflateStream($memoryStream,  [System.IO.Compression.CompressionMode]::Decompress)
    $streamReader =  New-Object System.IO.StreamReader($deflateStream, [System.Text.Encoding]::Unicode)
    $policyStr = $streamReader.ReadToEnd()
    $policy = $policyStr | ConvertFrom-Json
    $policyBodyCmd = ($policy.body | ConvertFrom-Json).cmd
    $policyBodyCmd | Format-List -Property hash,type,cmdtype,id,priority,timestamp,enforce | Out-File "$resultOutputDir\DLP\$policyName.txt"

    $timestamp = [datetime]$policyBodyCmd.timestamp
    "Timestamp: $($timestamp.ToString('u'))" | Out-File "$resultOutputDir\DLP\$policyName.txt" -Append

    # convert from/to json so it's JSON-formatted
    $params = $policyBodyCmd.paramsstr | ConvertFrom-Json
    $params | ConvertTo-Json -Depth 20 > "$resultOutputDir\DLP\$policyName.json"

    if ($params.SensitiveInfoPolicy) {
        foreach ($SensitiveInfoPolicy in $params.SensitiveInfoPolicy) {
            $configStr = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($SensitiveInfoPolicy.Config))
            $config = [xml]$configStr
            Format-XML $config | Out-File "$resultOutputDir\DLP\rule_$($SensitiveInfoPolicy.RulePackageId).xml"
        }
    }
}

function Get-DLPTraces {
	$WptState = Check-WptState
	Start-Wpr
	Start-PSRRecording
	if (!$OSPreviousVersion) {
		start-MpCmdRunTrace
	}
	$MinutesToRun = Get-MinutesValue
	StartTimer
	Stop-PSRRecording
	Stop-Wpr
	Stop-MpCmdRunTrace
	$DLPHealthCheck = Join-Path $ToolsDir "DLPDiagnose.ps1"
    &Powershell.exe $DLPHealthCheck
	Get-DefenderAV
}

function Set-BootTraces {
	#_# $ProcmonCommand = Join-Path $ToolsDir "Procmon.exe"
	$ProcmonCommand = Join-Path $DirScript\$ProcArch "Procmon.exe"
	Write-Host "Checking if WPR Boot trace is already running"
	$WptState = Check-WptState
	if ((!$OSPreviousVersion) -and ($WptState -eq "Ready")) {
		Start-Process -wait -WindowStyle minimized wpr.exe -ArgumentList "-boottrace -stopboot `"$WprpTraceFile`"" | out-Null
	}
	Write-Host "Saving any running ProcMon Boot trace"
	Start-Process -wait $ProcmonCommand -ArgumentList "-accepteula -convertbootlog `"$ProcMonlog`""
	$procmonlogs = Get-Item "$resultOutputDir\*.pml"
	if ($procmonlogs -eq $null) {
		& $ProcmonCommand -accepteula -enablebootlogging -nofilter -quiet -minimized
		if ((!$OSPreviousVersion) -and ($WptState -eq "Ready")) {
			&wpr.exe -boottrace -addboot "$ToolsDir\Sense.wprp" -filemode 
		}
		Write-Host "Boot logging ready"
		Write-Host -BackgroundColor Red -ForegroundColor Yellow "Please run the tool again with '-b' parameter when the machine is back online" 
		if ($RemoteRun) {
			Write-Warning "Restarting remote machine..."
		} else {
			Read-Host "Press ENTER when you are ready to restart..."
		}
		Restart-Computer -ComputerName . -Force
	}
	else {
		Write-Host "Boot logs were collected successfully"
		Get-DefenderAV
	}
}

function Set-FullCrashDump {
	Set-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl' -name CrashDumpEnabled -Type DWord -Value "1"
	Write-Host "Registry settings for full dump collection have been configured"
}

function Set-CrashOnCtrlScroll {
	Set-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Services\i8042prt\Parameters' -name CrashOnCtrlScroll -Type DWord -Value "1"
	Set-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Services\kbdhid\Parameters' -name CrashOnCtrlScroll -Type DWord -Value "1"
	Set-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Services\hyperkbd\Parameters' -name CrashOnCtrlScroll -Type DWord -Value "1" -ErrorAction SilentlyContinue
	Write-Host "Registry settings for CrashOnCtrlScroll have been configured as per https://docs.microsoft.com/en-us/windows-hardware/drivers/debugger/forcing-a-system-crash-from-the-keyboard"
}

function Start-PSRRecording {
	if ($RemoteRun) {
		"`r`nSkipping PSR recording as it requires an interactive user session." | Out-File $connectivityCheckFile -Append
	} 
	else {
		& psr.exe -stop
		Start-Sleep -Seconds 2
		& psr.exe -start -output "$resultOutputDir\psr.zip" -gui 0 -maxsc 99 -sc 1
	}
}

function Stop-PSRRecording {
	if ($RemoteRun) {
		"`r`nSkipping PSR recording as it requires an interactive user session." | Out-File $connectivityCheckFile -Append
	} 
	else {
		& psr.exe -stop
	}
}

function Start-MpCmdRunTrace {
	if ($NetTraceI) {
		Start-Process -WindowStyle minimized MpCmdRun.exe -WorkingDirectory $CurrentMpCmdPath.ToString() -ArgumentList "-trace -grouping 0x1B -level 0x3F"
	} elseif ($DlpT) {
		Start-Process -WindowStyle minimized MpCmdRun.exe -WorkingDirectory $CurrentMpCmdPath.ToString() -ArgumentList "-trace -grouping 0x109 -level 0x3F"
	}
}

function Stop-MpCmdRunTrace {
	$MpCmdRunProcess = Get-Process | Where-Object {$_.MainWindowTitle -like "*MpCmdRun.ex*"}
	start-sleep 1
	if ($MpCmdRunProcess) {
		[void][WindowFocus]::SetForeGroundWindow($MpCmdRunProcess.MainWindowHandle) 
		[System.Windows.Forms.SendKeys]::SendWait("~")
	}
}

function Get-WdAvVerboseTrace {
	if (!$OSPreviousVersion) {
		Start-Process -WindowStyle minimized MpCmdRun.exe -WorkingDirectory $CurrentMpCmdPath.ToString() -ArgumentList "-trace -grouping 0x1FF -level ff"
		#_#&$MpCmdRunCommand -CaptureNetworkTrace -path $resultOutputDir\DefenderAV\Capture.npcap
		&$MpCmdRunCommand -CaptureNetworkTrace -path C:\Users\Public\Downloads\Capture.npcap
		Start-WinEventDebug Microsoft-Windows-SmartScreen/Debug
	}
	elseif (Test-Path -path "$env:ProgramFiles\Microsoft Security Client\MpCmdRun.exe") {
		Start-Process -WindowStyle minimized MpCmdRun.exe -WorkingDirectory $CurrentMpCmdPath -ArgumentList "-trace -grouping ff -level ff"
	}
	start-Sleep 1
	Start-PSRRecording
	$MinutesToRun = Get-MinutesValue
	StartTimer
	Stop-PSRRecording
	Get-DefenderAV
	if (Test-Path -Path  $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-SmartScreen%4Debug.evtx') {
		Stop-WinEventDebug Microsoft-Windows-SmartScreen/Debug
		Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-SmartScreen%4Debug.evtx' -Destination $resultOutputDir\EventLogs\SmartScreen.evtx
	}
}

function Get-WdAvPerfTrace {
	$WptState = (check-WptState xperf.exe)
	if ($WptState -eq "Ready") {
		Write-Host "Starting XPERF trace"
		Start-Process -WindowStyle minimized XPERF.exe -WorkingDirectory $resultOutputDir -ArgumentList "-on Base+DiagEasy+Latency+FileIO+DISPATCHER+REGISTRY+PERF_COUNTER -stackWalk Profile+CSwitch+ReadyThread+FileCreate+FileClose -f Kernel.etl -BufferSize 1024"
		start-Sleep 1
		Start-Process -WindowStyle minimized XPERF.exe -WorkingDirectory $resultOutputDir -ArgumentList "-start AMXperf -on e4b70372-261f-4c54-8fa6-a5a7914d73da+cfeb0608-330e-4410-b00d-56d8da9986e6+8e92deef-5e17-413b-b927-59b2f06a3cfc+751ef305-6c6e-4fed-b847-02ef79d26aef+0A002690-3839-4E3A-B3B6-96D8DF868D99 -f amxperftrace.etl"
		start-Sleep 1
		$MinutesToRun = Get-MinutesValue
		StartTimer
		Start-Process -WindowStyle minimized XPERF.exe -WorkingDirectory $resultOutputDir -ArgumentList "-stop -stop AMXperf"
		Write-Host "Stopping XPERF trace"
		start-Sleep 5
		Write-Host "Merging XPERF trace"
		Start-Process -WindowStyle minimized XPERF.exe -WorkingDirectory $resultOutputDir -ArgumentList "-merge Kernel.etl amxperftrace.etl Merged.etl -compress"
	}
	Get-DefenderAV
}

function Get-CrashDumps {
	New-Item -ItemType Directory -Path "$resultOutputDir\CrashDumps" -ErrorAction SilentlyContinue | out-Null
	Write-Host "Attempting to collect a memory dump of the sensor"
	if ($ARM) {
		$ProcDumpCommand = Join-Path $ToolsDir "ProcDump64a.exe"
	} else {
		#_# $ProcDumpCommand = Join-Path $ToolsDir "procdump.exe" 
		 $ProcDumpCommand = Join-Path $PSScriptRoot "procdump.exe" 
	}
    if ($OSPreviousVersion) {
		$processes = @(Get-Process -Name MsSenseS) + @(Get-Process -Name MonitoringHost)
        if ($processes -eq $null) {
			Write-Host "No running Sensor processes found"
		}
		else {
			foreach ($process in $processes) {
				& $ProcDumpCommand -accepteula -ma -mk $process.Id "$resultOutputDir\CrashDumps\$($process.name)_$($process.Id).dmp"
			}
		}
    }
    elseif ($buildNumber -ge "15063") {
		Write-Host "The MDATPClientAnalyzer does not support capturing a memory dump of a tamper protected process at this time."
		Write-Host "Attempting to capture a memory dump of the DiagTrack service"
		$DiagTrackSvc = (Get-WmiObject Win32_Service -Filter "Name='DiagTrack'")
		$DiagTrackID = $DiagTrackSvc.ProcessId
        if ($DiagTrackID -eq $null) {
			Write-Host "No running processes to capture"
		}
		else {
			$Processes = @(Get-Process -Id $DiagTrackID)
			foreach ($process in $processes) {
				& $ProcDumpCommand -accepteula -ma -mk $process.Id "$resultOutputDir\CrashDumps\$($process.name)_$($process.Id).dmp"
			}
		}
	}
}

function Get-NetTraces {
	New-Item -ItemType Directory -Path "$resultOutputDir\NetTraces" -ErrorAction SilentlyContinue | out-Null
	$traceFile = "$resultOutputDir\NetTraces\NetTrace.etl"
    $WptState = Check-WptState
	Start-Wpr
    &netsh trace stop | Out-Null
    &netsh wfp capture stop | Out-Null
	start-Sleep 2
	&ipconfig /flushdns | Out-Null
	&netsh interface ip delete arpcache | Out-Null
	start-sleep 1
    $NetshProcess = Get-Process | Where-Object { $_.Name -eq "netsh" } -ErrorAction SilentlyContinue
    if ($NetshProcess -ne $null) {
		foreach ($process in $NetshProcess) {stop-Process $process}
    }
    if ($buildNumber -le 7601) {
		&netsh trace start overwrite=yes capture=yes scenario=InternetClient report=yes maxSize=500 traceFile=$traceFile fileMode=circular | Out-Null
	}
	else {
		&netsh trace start overwrite=yes capture=yes scenario=InternetClient_dbg report=yes maxSize=500 traceFile=$traceFile fileMode=circular | Out-Null
	}
    &netsh advfirewall set allprofiles logging allowedconnections enable   # enable firewall logging for allowed traffic
    &netsh advfirewall set allprofiles logging droppedconnections enable   # enable firewall logging for dropped traffic
    Start-Process -WindowStyle hidden netsh.exe -WorkingDirectory "$resultOutputDir\NetTraces" -ArgumentList "wfp capture start file=wfpdiag.cab keywords=19" # start capturing  WFP log
	Start-PSRRecording
	&netstat -anob | Out-File "$resultOutputDir\NetTraces\NetStatOutputAtStart.txt"
	"Netstat output above was taken at: " + (Get-Date) | Out-File "$resultOutputDir\NetTraces\NetStatOutputAtStart.txt" -Append
	if ($OSPreviousVersion) {
		$OMSPath = "$env:ProgramFiles\Microsoft Monitoring Agent\Agent\Tools"
		if (Test-Path -path $OMSPath) {
			$MMAPathExists = "True"
			Get-Service HealthService | Stop-Service -ErrorAction SilentlyContinue
			&$OMSPath\StopTracing.cmd | Out-Null
			&$OMSPath\StartTracing.cmd VER | Out-Null
			Get-Service HealthService | Start-Service -ErrorAction SilentlyContinue
		}
	}
	if (!$OSPreviousVersion) {
		Start-MpCmdRunTrace
	}
    $MinutesToRun = Get-MinutesValue
    StartTimer
	Stop-Wpr
    Write-Host "Note: Stopping network and wfp traces may take a while..."
	&netstat -anob | Out-File "$resultOutputDir\NetTraces\NetStatOutputAtStop.txt"
	"Netstat output above was taken at: " + (Get-Date) | Out-File "$resultOutputDir\NetTraces\NetStatOutputAtStop.txt" -Append
    &netsh wfp capture stop
	Stop-PSRRecording
	stop-MpCmdRunTrace
    &netsh trace stop
	&netsh advfirewall set allprofiles logging allowedconnections disable   # disable firewall logging for allowed traffic
    &netsh advfirewall set allprofiles logging droppedconnections disable   # disable firewall logging for dropped traffic
	Copy-Item $env:SystemRoot\system32\LogFiles\Firewall\pfirewall.log -Destination "$resultOutputDir\NetTraces\" -ErrorAction SilentlyContinue
	if ($MMAPathExists) { 
		&$OMSPath\StopTracing.cmd | Out-Null
		Copy-Item $env:SystemRoot\Logs\OpsMgrTrace\* -Destination "$resultOutputDir\NetTraces\" -ErrorAction SilentlyContinue
	}
	Get-DefenderAV
	if (!$OSPreviousVersion) {
		if ($system) {
			&robocopy $env:ProgramData\Microsoft\Diagnosis "$resultOutputDir\NetTraces\Diagnosis" /E /ZB /w:1 /r:1 /log:"$resultOutputDir\NetTraces\copy.log"
		} else {
			#_# $PSExecCommand = Join-Path $ToolsDir "PsExec.exe"
			$PSExecCommand = Join-Path $PSScriptRoot "PsExec.exe"
			&$PSExecCommand $ARMcommand -accepteula -nobanner -s robocopy $env:ProgramData\Microsoft\Diagnosis "$resultOutputDir\NetTraces\Diagnosis" /E /ZB /w:1 /r:1 /log:"$resultOutputDir\NetTraces\copy.log"
		}
	}
	Get-ChildItem HKLM:\SOFTWARE\microsoft\windows\currentversion\diagnostics -recurse | Out-File "$resultOutputDir\SystemInfoLogs\DiagTrackReg.txt"
	# Dump HOSTS file content to file
	Copy-Item $env:SystemRoot\System32\Drivers\etc\hosts -Destination "$resultOutputDir\SystemInfoLogs" -ErrorAction SilentlyContinue
}

# Define C# functions to extract info from Windows Security Center (WSC)
# WSC_SECURITY_PROVIDER as defined in Wscapi.h or http://msdn.microsoft.com/en-us/library/bb432509(v=vs.85).aspx
# And http://msdn.microsoft.com/en-us/library/bb432506(v=vs.85).aspx
$wscDefinition = @"
		[Flags]
        public enum WSC_SECURITY_PROVIDER : int
        {
            WSC_SECURITY_PROVIDER_FIREWALL = 1,				// The aggregation of all firewalls for this computer.
            WSC_SECURITY_PROVIDER_AUTOUPDATE_SETTINGS = 2,	// The automatic update settings for this computer.
            WSC_SECURITY_PROVIDER_ANTIVIRUS = 4,			// The aggregation of all antivirus products for this computer.
            WSC_SECURITY_PROVIDER_ANTISPYWARE = 8,			// The aggregation of all anti-spyware products for this computer.
            WSC_SECURITY_PROVIDER_INTERNET_SETTINGS = 16,	// The settings that restrict the access of web sites in each of the Internet zones for this computer.
            WSC_SECURITY_PROVIDER_USER_ACCOUNT_CONTROL = 32,	// The User Account Control (UAC) settings for this computer.
            WSC_SECURITY_PROVIDER_SERVICE = 64,				// The running state of the WSC service on this computer.
            WSC_SECURITY_PROVIDER_NONE = 0,					// None of the items that WSC monitors.
			
			// All of the items that the WSC monitors.
            WSC_SECURITY_PROVIDER_ALL = WSC_SECURITY_PROVIDER_FIREWALL | WSC_SECURITY_PROVIDER_AUTOUPDATE_SETTINGS | WSC_SECURITY_PROVIDER_ANTIVIRUS |
            WSC_SECURITY_PROVIDER_ANTISPYWARE | WSC_SECURITY_PROVIDER_INTERNET_SETTINGS | WSC_SECURITY_PROVIDER_USER_ACCOUNT_CONTROL |
            WSC_SECURITY_PROVIDER_SERVICE | WSC_SECURITY_PROVIDER_NONE
        }

        [Flags]
        public enum WSC_SECURITY_PROVIDER_HEALTH : int
        {
            WSC_SECURITY_PROVIDER_HEALTH_GOOD, 			// The status of the security provider category is good and does not need user attention.
            WSC_SECURITY_PROVIDER_HEALTH_NOTMONITORED,	// The status of the security provider category is not monitored by WSC. 
            WSC_SECURITY_PROVIDER_HEALTH_POOR, 			// The status of the security provider category is poor and the computer may be at risk.
            WSC_SECURITY_PROVIDER_HEALTH_SNOOZE, 		// The security provider category is in snooze state. Snooze indicates that WSC is not actively protecting the computer.
            WSC_SECURITY_PROVIDER_HEALTH_UNKNOWN
        }

		
        [DllImport("wscapi.dll")]
        private static extern int WscGetSecurityProviderHealth(int inValue, ref int outValue);

		// code to call interop function and return the relevant result
        public static WSC_SECURITY_PROVIDER_HEALTH GetSecurityProviderHealth(WSC_SECURITY_PROVIDER inputValue)
        {
            int inValue = (int)inputValue;
            int outValue = -1;

            int result = WscGetSecurityProviderHealth(inValue, ref outValue);

            foreach (WSC_SECURITY_PROVIDER_HEALTH wsph in Enum.GetValues(typeof(WSC_SECURITY_PROVIDER_HEALTH)))
                if ((int)wsph == outValue) return wsph;

            return WSC_SECURITY_PROVIDER_HEALTH.WSC_SECURITY_PROVIDER_HEALTH_UNKNOWN;
        }
"@

# Add-type to use SetForegroundWindow api https://docs.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setforegroundwindow
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 
Add-Type @"
  using System;
  using System.Runtime.InteropServices;
  public class WindowFocus {
     [DllImport("user32.dll")]
     [return: MarshalAs(UnmanagedType.Bool)]
     public static extern bool SetForegroundWindow(IntPtr hWnd);
  }
"@

function Get-DefenderAV{
	New-Item -ItemType Directory -Path "$resultOutputDir\DefenderAV" -ErrorAction SilentlyContinue | out-Null
	if (($WDVerboseTraceV) -and (!$OSPreviousVersion)) {
		&$MpCmdRunCommand -CaptureNetworkTrace
		start-Sleep 2
		Stop-MpCmdRunTrace
	}
	StartGet-MSInfo -NFO $true -TXT $false -OutputLocation "$resultOutputDir\SystemInfoLogs"
	&gpresult /SCOPE COMPUTER /H "$resultOutputDir\SystemInfoLogs\GP.html"
	if ($MpCmdRunCommand) {
		&$MpCmdRunCommand -getfiles
		Move-Item -Path "$MpCmdResultPath\MpSupportFiles.cab" -Destination "$resultOutputDir\DefenderAV\"
		Move-Item -path "C:\Users\Public\Downloads\Capture.npcap" -Destination "$resultOutputDir\DefenderAV\" -ErrorAction SilentlyContinue
		# Dump Defender related polices
		Get-ChildItem "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender" -recurse | Out-File "$resultOutputDir\DefenderAV\Policy-DefenderAV.txt"
		Get-ChildItem "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\RestrictedServices\Configurable\" -recurse | Out-File "$resultOutputDir\DefenderAV\Policy-Firewall.txt"
		Get-ChildItem "HKU:\S-1-5-18\SOFTWARE\Microsoft\Windows Defender" -recurse -ErrorAction SilentlyContinue | Out-File "$resultOutputDir\DefenderAV\Policy-SystemService.txt"
		Get-ChildItem "HKU:\S-1-5-20\SOFTWARE\Microsoft\Windows Defender" -recurse -ErrorAction SilentlyContinue | Out-File "$resultOutputDir\DefenderAV\Policy-NetworkService.txt"
	}
	&fltmc instances -v "$env:SystemDrive" > $resultOutputDir\SystemInfoLogs\filters.txt
	if ($OSProductName.tolower() -notlike ("*server*"))  {
		Write-output "`r`n##################### Windows Security Center checks ######################" | Out-File $connectivityCheckFile -Append
		$wscType=Add-Type -memberDefinition $wscDefinition -name "wscType" -UsingNamespace "System.Reflection","System.Diagnostics" -PassThru
 
		"            Firewall: " + $wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_FIREWALL) | Out-File $connectivityCheckFile -Append
		"         Auto-Update: " + $wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_AUTOUPDATE_SETTINGS) | Out-File $connectivityCheckFile -Append
		"          Anti-Virus: " + $wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_ANTIVIRUS) | Out-File $connectivityCheckFile -Append
		"        Anti-Spyware: " + $wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_ANTISPYWARE) | Out-File $connectivityCheckFile -Append
		"   Internet Settings: " + $wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_INTERNET_SETTINGS) | Out-File $connectivityCheckFile -Append
		"User Account Control: " + $wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_USER_ACCOUNT_CONTROL) | Out-File $connectivityCheckFile -Append
		"         WSC Service: " + $wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_SERVICE) | Out-File $connectivityCheckFile -Append

		if ($wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_FIREWALL) -eq $wscType[2]::WSC_SECURITY_PROVIDER_HEALTH_POOR) {
			Write-output "Windows Defender firewall settings not optimal" | Out-File $connectivityCheckFile -Append
		}
		if ($wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_USER_ACCOUNT_CONTROL) -eq $wscType[2]::WSC_SECURITY_PROVIDER_HEALTH_POOR) {
			Write-output "User Account Controller (UAC) is switched off" | Out-File $connectivityCheckFile -Append
		}
		if ($wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_ANTIVIRUS) -eq $wscType[2]::WSC_SECURITY_PROVIDER_HEALTH_GOOD) {
			Write-output "Windows Defender anti-virus is running and up-to-date" | Out-File $connectivityCheckFile -Append
		}
	}
}

function StartTimer {
	$timeout = New-TimeSpan -Minutes $MinutesToRun
	$sw = [diagnostics.stopwatch]::StartNew()
	$DiagTrackSvc = (Get-WmiObject Win32_Service -Filter "Name='DiagTrack'")
	$DiagTrackID = $DiagTrackSvc.ProcessId
	$NetConnection = {} | Select State,RequestedState,CreationTime,RemoteAddress | format-table -AutoSize
	if ((!$OSPreviousVersion) -and ($buildNumber -le "17134")) {
		Write-output "##################### DiagTrack uploading route check #####################" | Out-File $connectivityCheckFile -Append
		Write-output "Connections identified from DiagTrack service will be listed below" | Out-File $connectivityCheckFile -Append
	}
	if (!$DiagTrackID) {
		Write-output "Could not find DiagTrack PID" | Out-File $connectivityCheckFile -Append 
    }
	if ($RemoteRun) {
		Write-Warning "The trace collection was initiated remotely. Please wait for data collection timer to complete."
	}
	while ($sw.elapsed -lt $timeout){
		Start-Sleep -Seconds 1
        $rem = $timeout.TotalSeconds - $sw.elapsed.TotalSeconds
		if ($RemoteRun) {
			Write-Host "Remaining seconds: " ([math]::Round($rem))
		} else {
			Write-Progress -Activity "Collecting traces, run your scenario now and press 'q' to stop data collection at any time" -Status "Progress:"  -SecondsRemaining $rem -PercentComplete (($sw.elapsed.Seconds/$timeout.TotalSeconds)*100)
		}
		if (($DiagTrackID) -and (!$OSPreviousVersion) -and ($buildNumber -le "17134")) {
			try {
                $NetConnection = Get-NetTCPConnection -AppliedSetting Internet | Where-Object OwningProcess -eq $DiagTrackID | select -Property State,RequestedState,CreationTime,RemoteAddress
				$NetConnections += $NetConnection
            }
            catch {
            }
		}
		if (!$RemoteRun) {
			if ([console]::KeyAvailable) {
				$key = [System.Console]::ReadKey() 
				if ( $key.key -eq 'q') {
					Write-Warning  "The trace collection action was ended by user exit command"
					break 
				}
			}
		}
    }
	$UniqueNetConnections = $NetConnections | Sort-Object CreationTime -Unique
	$UniqueNetConnections | Out-File $connectivityCheckFile -Append
}

function Get-MinutesValue {
	if ($RemoteRun) {
		"`r`nLog Collection was started from a remote machine." | Out-File $connectivityCheckFile -Append
		return $MinutesToRun
	} 
	else {
		try {
			[int]$MinutesToRun=(Read-Host "Enter the number of minutes to collect traces")
			return $MinutesToRun
		}
		catch {
			 Write-Warning  ($_.Exception.Message).split(':')[1]
			 return $MinutesToRun = $false
		}
	}
}

function StartTraces() {
    if ($netTrace) {
        netsh trace start capture=yes report=yes traceFile=$traceFile fileMode=single
    }
    if ($wfpTrace) {
        netsh advfirewall set allprofiles logging allowedconnections enable   # enable firewall logging for allowed traffic
        netsh advfirewall set allprofiles logging droppedconnections enable   # enable firewall logging for dropped traffic
        netsh wfp capture start keywords=19   # start capturing  WFP log
    }
 }

function Check-WptState($CheckCommand) {
	if (!$WDPerfTraceA) {
		$CheckCommand = "wpr.exe"
	}
	# This line will reload the path so that a recent installation of wpr will take effect immediately:
	$env:path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
	$command = Get-Command $CheckCommand -ErrorAction SilentlyContinue
	$SenseWprp7 =  Join-Path $ToolsDir "SenseW7.wprp"
	$SenseWprp10 = Join-Path $ToolsDir "SenseW10.wprp"
	$SenseWprp = Join-Path $ToolsDir "Sense.wprp"
	$DlZipFile = Join-Path $ToolsDir "WPT.cab"
	if ($command -eq $null){
		Write-Warning "Performance Toolkit is not installed on this machine. It is required for full traces to be collected."
		Write-host -ForegroundColor Green "Please wait while we download WPT installer files (~50Mb) to MDATPClientAnalyzer directory. Refer to https://aka.ms/adk for more information about the 'Windows ADK'."
		$WPTURL = "https://aka.ms/MDATPWPT"
		Import-Module BitsTransfer
		$BitsResult = Start-BitsTransfer -Source $WPTURL -Destination "$DlZipFile" -TransferType Download -Asynchronous
		$DownloadComplete = $false
		if (!(Test-Path -path $DlZipFile)) {
			while ($DownloadComplete -ne $true) {
				start-Sleep 1
				$jobstate = $BitsResult.JobState;
				$percentComplete = ($BitsResult.BytesTransferred / $BitsResult.BytesTotal) * 100
				Write-Progress -Activity ('Downloading' + $result.FilesTotal + ' files') -Status "Progress:" -PercentComplete $percentComplete 
				if ($jobstate.ToString() -eq 'Transferred') {
				    $DownloadComplete = $true
					Write-Progress -Activity ('Downloading' + $result.FilesTotal + ' files') -Completed close 
				}
				if ($jobstate.ToString() -eq 'TransientError') {
                    $DownloadComplete = $true
                    Write-host "Unable to download ADK installation package."
                }
			}
		$BitsResult | complete-BitsTransfer
		}
		if (Test-Path -path "$DlZipFile") {
			#Expand-Archive CMDlet or System.IO.Compression.ZipFile does not work with some older PowerShell/OS combinations so using the below for backwards compatbility 
			&expand.exe "$DlZipFile" "`"$($ToolsDir.TrimEnd('\'))`"" -F:*
			Write-host -ForegroundColor Green "Download complete. Starting installer..."
			start-Sleep 1
			Write-Host -BackgroundColor Red -ForegroundColor Yellow "Please click through the installer steps to deploy the Microsoft Windows Performance Toolkit (WPT) before proceeding"
			if ($buildNumber -eq 7601) {
				$AdkSetupPath = Join-Path $ToolsDir "8.0\adksetup.exe"
				Start-Process -wait -WindowStyle minimized "$AdkSetupPath" -ArgumentList "/ceip off /features OptionId.WindowsPerformanceToolkit"
				Read-Host "Press ENTER if intallation is complete and you are ready to resume..."	
			}
			elseif ($buildNumber -gt 7601) {
				$AdkSetupPath = Join-Path $ToolsDir "adksetup.exe"
				Start-Process -wait -WindowStyle minimized "$AdkSetupPath" -ArgumentList "/ceip off /features OptionId.WindowsPerformanceToolkit"
				Read-Host "Press ENTER if intallation is complete and you are ready to resume..."
			}
		}
		else {
			Write-host "Please download and install manually from https://aka.ms/adk" 
		}
		$env:path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
		$command = Get-Command $CheckCommand -ErrorAction SilentlyContinue
		if ($command -eq $null){
			Write-Host -BackgroundColor Red -ForegroundColor Yellow "WPT was not installed. Only partial data will be collected"
			return $WptState = "Missing"
		}
		elseif ($buildNumber -eq 7601) {
			Write-Warning "Note: Windows7/2008R2 machines also require running 'wpr.exe -disablepagingexecutive on' and rebooting"
			Write-Warning "To disable, run 'wpr.exe -disablepagingexecutive off' once data collection is complete"
			Read-Host "Press ENTER to allow MDATPClientAnalyzer to turn on 'disablepagingexecutive' and restart your Machine automatically"
			Start-Process -wait -WindowStyle minimized wpr.exe -ArgumentList "-disablepagingexecutive on"
			Restart-Computer -ComputerName .
		}
    }
	Write-Host "Stopping any running WPR trace profiles"
	Start-Process -wait -WindowStyle minimized wpr.exe -ArgumentList "-cancel" | out-Null
	if ($buildNumber -le 9600) {
		Copy-Item -path $SenseWprp7 -Destination $senseWprp -Force	
	}
	else {
		Copy-Item -path $SenseWprp10 -Destination $senseWprp -Force
	}		
	return $WptState = "Ready"
}

function Start-Wpr {
	if ($wprpTraceH -and $WptState -eq "Ready"){
		&wpr.exe -start GeneralProfile -start CPU -start FileIO -start DiskIO -start "$ToolsDir\Sense.wprp" -filemode 
	}
	elseif ($WptState -eq "Ready") {
		&wpr.exe -start "$ToolsDir\Sense.wprp" -filemode
	}
}

function Stop-Wpr {
    if ($WptState -eq "Ready") {
		&wpr.exe -stop $WprpTraceFile | Out-Null
	}
}

function Copy-RecentItems($ParentFolder, $DestFolderName) {
	$ParentFolder = (Get-ChildItem -Path $ParentFolder)
	$ParentFolder = ($ParentFolder | ? {$_.LastWriteTime -gt (Get-Date).AddDays(-2)} -ErrorAction SilentlyContinue)
	if ($ParentFolder -ne $null) {
		foreach ($subfolder in $ParentFolder) {
			Copy-Item -Recurse -Path $subfolder.FullName -Destination $resultOutputDir\$DestFolderName\$subfolder -ErrorAction SilentlyContinue
		}
	}
}

function Start-WinEventDebug($DebugLogName) {
    $log = New-Object System.Diagnostics.Eventing.Reader.EventLogConfiguration $DebugLogName
	if ($log.IsEnabled -ne $true) {
		$log.IsEnabled=$true
		$log.SaveChanges()
	}
}

function Stop-WinEventDebug($DebugLogName) {
    $log = New-Object System.Diagnostics.Eventing.Reader.EventLogConfiguration $DebugLogName
    $log.IsEnabled=$false
    $log.SaveChanges()
    $DebugLogPath = [System.Environment]::ExpandEnvironmentVariables($log.LogFilePath)
    Copy-Item -path "$DebugLogPath" -Destination "$resultOutputDir\EventLogs\"
}

function SetLocalDumps() {
	# If already implementing LocalDumps as per https://docs.microsoft.com/en-us/windows/win32/wer/collecting-user-mode-dumps, then backup the current config
	if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps") {
		&Reg export "HKLM\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps" "$ToolsDir\WerRegBackup.reg" /y 2>&1 | Out-Null
	}  
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps" -Recurse -ErrorAction SilentlyContinue | out-Null
	New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting" -Name "LocalDumps" -ErrorAction SilentlyContinue | out-Null
	New-Item -ItemType Directory -Path "$resultOutputDir\CrashDumps" -ErrorAction SilentlyContinue | out-Null
	New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps" -Name "DumpFolder" -Value "$resultOutputDir\CrashDumps" -PropertyType "ExpandString" -ErrorAction SilentlyContinue | out-Null
	New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps" -Name "DumpCount" -Value 5 -PropertyType DWord -ErrorAction SilentlyContinue | out-Null
	New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps" -Name "DumpType" -Value 2 -PropertyType DWord -ErrorAction SilentlyContinue | out-Null
}

function RestoreLocalDumps() {
	if (Test-Path "$ToolsDir\WerRegBackup.reg") {
		$RegImport = (&reg import "$ToolsDir\WerRegBackup.reg" 2>&1)
	} else {
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps" -ErrorAction SilentlyContinue | out-Null
	}
}

# function to download a given cab file and expand it
function Download-WebFile($webfile) {
	$DlZipFile = Join-Path $ToolsDir "webfile.cab"
    Write-host -ForegroundColor Green "Please wait while we download additional required files to MDATPClientAnalyzer from: " $webfile
	Import-Module BitsTransfer
	$BitsJob = Start-BitsTransfer -source $webfile -Destination "$DlZipFile" -Description "Downloading additional files" -RetryTimeout 60 -RetryInterval 60 -ErrorAction SilentlyContinue
	if (Test-Path -path "$DlZipFile") {
		#Expand-Archive CMDlet or System.IO.Compression.ZipFile does not work with some older PowerShell/OS combinations so using the below for backwards compatbility 
		&expand.exe "$DlZipFile" "`"$($ToolsDir.TrimEnd('\'))`"" -F:*
	}
}

function Get-AppCompatTraces() {
	if (!$OSPreviousVersion) {
		$SymChkCommand = Join-Path $ToolsDir "\x86\symchk.exe"
		if (!(test-path $SymChkCommand)) {
			Download-WebFile "https://aka.ms/MDATPSYMCHK"
		}  
		if (test-path $SymChkCommand) {
			&$SymChkCommand /q /r /s "." "$env:ProgramFiles\Windows Defender Advanced Threat Protection" /om "$resultOutputDir\SystemInfoLogs\symbolsManifest.txt"
		}
    }
	if ($ARM) {
		$ProcmonCommand = Join-Path $ToolsDir "Procmon64a.exe"
	} else {
		#_# $ProcmonCommand = Join-Path $ToolsDir "Procmon.exe"
		$ProcmonCommand = Join-Path $DirScript\$ProcArch "Procmon.exe"
	}
	& $ProcmonCommand -accepteula -terminate
	SetLocalDumps
	$WptState = Check-WptState
	Start-wpr
	Remove-Item $ToolsDir\*.pml -Force -ErrorAction SilentlyContinue
	$MinutesToRun =  Get-MinutesValue
	& $ProcmonCommand -accepteula -backingfile "$resultOutputDir\procmonlog.pml" -nofilter -quiet -minimized 
	Start-PSRRecording
	Start-WinEventDebug Microsoft-Windows-WMI-Activity/Debug
	StartTimer
	& $ProcmonCommand -accepteula -terminate
	Start-Sleep 2
	Stop-PSRRecording
	Stop-Wpr
	if (Test-Path -Path  $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-DeviceManagement-Enterprise-Diagnostics-Provider%4Admin.evtx') {
		Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-DeviceManagement-Enterprise-Diagnostics-Provider%4Admin.evtx' -Destination $resultOutputDir\EventLogs\MdmAdmin.evtx
		Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-DeviceManagement-Enterprise-Diagnostics-Provider%4Operational.evtx' -Destination $resultOutputDir\EventLogs\MdmOperational.evtx -ErrorAction SilentlyContinue
	}
	Stop-WinEventDebug Microsoft-Windows-WMI-Activity/Debug
	Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-WMI-Activity%4Operational.evtx' -Destination $resultOutputDir\EventLogs\WMIActivityOperational.evtx
	Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\System.evtx' -Destination $resultOutputDir\EventLogs\System.evtx
	Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\Application.evtx' -Destination $resultOutputDir\EventLogs\Application.evtx
	Get-DefenderAV
	Start-Sleep 2
	$DestFolderName = "WER"
	Copy-RecentItems $env:ProgramData\Microsoft\Windows\WER\ReportArchive $DestFolderName
	Copy-RecentItems $env:ProgramData\Microsoft\Windows\WER\ReportQueue $DestFolderName
	RestoreLocalDumps
}		

 function Stop-PerformanceCounters{
        param (
            $DataCollectorSet,
            $DataCollectorName
        )
        try{
            $DataCollectorSet.Query($DataCollectorName,$null)
            if($DataCollectorSet.Status -ne 0){
                $DataCollectorSet.stop($false)
                Start-Sleep 10
            }
           
            $DataCollectorSet.Delete()
        }
        catch [Exception] {
            $_.Exception.Message
        }
 }

 function Get-PerformanceCounters {
    param (
        [Alias("r")][switch]$RunCounter
    )

    $filePathToXml = "$ToolsDir\PerfCounter.xml"
        if($RunCounter){
                if (($buildNumber -eq 9600) -or ($buildNumber -eq 7601)){
                        Copy-Item  -path "$ToolsDir\PerfCounterW7.xml" -Destination  "$ToolsDir\PerfCounter.xml" -Force
                }
                else {
                        Copy-Item  -path "$ToolsDir\PerfCounterW10.xml"  -Destination  "$ToolsDir\PerfCounter.xml" -Force
                    }   
                $xmlContent = New-Object XML
                $xmlContent.Load($filePathToXml)
                $xmlContent.SelectNodes("//OutputLocation") | ForEach-Object {  $_."#text" = $_."#text".Replace('c:\',$ToolsDir) }
                $xmlContent.SelectNodes("//RootPath") | ForEach-Object {  $_."#text" = $_."#text".Replace('c:\',$ToolsDir) }
                $xmlContent.Save($filePathToXml)
    }

    $DataCollectorName = "MDATP-Perf-Counter"
    $DataCollectorSet = New-Object -COM Pla.DataCollectorSet
    [string]$xml = Get-Content $filePathToXml
    $DataCollectorSet.SetXml($xml)
	Write-Host "Stopping any running perfmon trace profiles"
    Stop-PerformanceCounters -DataCollectorSet  $DataCollectorSet -DataCollectorName $DataCollectorName
    if ($RunCounter){
        $DataCollectorSet.Commit("$DataCollectorName" , $null , 0x0003) | Out-Null
        $DataCollectorSet.Start($false)
    }
 }

function Get-PerformanceTraces() {
	$WPtState = Check-WptState
	if (!$RemoteRun) {
		$MinutesToRun = $null
	}
	while (![int]$MinutesToRun){
        $MinutesToRun =  Get-MinutesValue
    }
    if ($wprpTraceL) {
		Get-PerformanceCounters -r
		Start-Wpr
		StartTimer
	}
    elseif  ($wprpTraceH) {
	 	Start-Wpr
		StartTimer
    }			
	Stop-Wpr
    if ($wprpTraceL) {
        Get-PerformanceCounters
    }
	Get-DefenderAV
	$Perfmonlogs = Get-Item $ToolsDir\*.blg
    if (($Perfmonlogs) -ne $null) {
		Move-Item -Path $Perfmonlogs -Destination $resultOutputDir
    } 
}

function StopTraces() {
    if ($netTrace) {
        netsh trace stop
    }
    if ($wfpTrace) {
        netsh wfp capture stop
        Move-Item -Path $PSScriptRoot\wfpdiag.cab -Destination $resultOutputDir
        Copy-Item $env:SystemRoot\system32\LogFiles\Firewall\pfirewall.log -Destination $resultOutputDir
    }
}

function SetUrlList {
    param (
        [parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]$OSPreviousVersion
    )
    $regionInfos = @{
        US=@{cnc1='eus'; cnc2='cus'; vortex='us'};
        EU=@{cnc1='neu'; cnc2='weu'; vortex='eu'};
        UK=@{cnc1='ukw'; cnc2='uks'; vortex='uk'};
        FFL4=@{cnc1='usgv'; cnc2='usgt'; vortex='us4'};
        FFL5=@{cnc1='usde'; cnc2='usdc'; vortex='us5'};
    }
    $cncUrl = "https://winatp-gw-ToReplace.microsoft.com/test"
    $vortexUrl = "https://ToReplace.vortex-win.data.microsoft.com/ping"
    $vortexUrlv20 = "https://ToReplace-v20.events.data.microsoft.com/ping"
	$DiagTrackSettingsUrl = "https://settings-win.data.microsoft.com/qos"
    if (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection" -Value OnboardedInfo ){
        $Region = (((Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\").OnboardedInfo | ConvertFrom-Json).body | ConvertFrom-Json).vortexGeoLocation
        Clear-Content -Path $EndpointList
        Add-Content $EndpointList -value $cncUrl.Replace('ToReplace',$regionInfos.($Region).cnc1)
        Add-Content $EndpointList -value $cncUrl.Replace('ToReplace',$regionInfos.($Region).cnc2)
		Add-Content $EndpointList -value $DiagTrackSettingsUrl
        if (($Region) -notmatch 'FFL'){
            # Exist only for not FF tenants
                Add-Content $EndpointList -value $vortexUrl.Replace('ToReplace',$regionInfos.($Region).vortex)
                Add-Content $EndpointList -Value "http://ctldl.windowsupdate.com/msdownload/update/v3/static/trustedr/en/disallowedcertstl.cab	NoPinning"
            }
            Add-Content $EndpointList -value $vortexUrlv20.Replace('ToReplace',$regionInfos.($Region).vortex)
    }
    elseif ($OSPreviousVersion) {
        Clear-Content -Path $EndpointList
        $Regions = ('US','UK','EU')
         foreach ($Region in $Regions){
            Add-Content $EndpointList -value $cncUrl.Replace('ToReplace',$regionInfos.($Region).cnc1)
            Add-Content $EndpointList -value $cncUrl.Replace('ToReplace',$regionInfos.($Region).cnc2)
        }
    }
}

function ValidateURLs {
	# Add warning to output if any EDR Cloud checks failed
	# Based on https://docs.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/configure-proxy-internet#verify-client-connectivity-to-microsoft-defender-atp-service-urls
	# "If at least one of the connectivity options returns a (200) status, then the Microsoft Defender ATP client can communicate with the tested URL properly using this connectivity method."
	Write-output "`r`n#################### Defender ATP cloud service check #####################" | Out-File $connectivityCheckFile -Append
	$Streamer = New-Object System.IO.StreamReader( $connectivityCheckFile)
	$SuccessCounter = -1
	while (($Line = $Streamer.ReadLine()) -ne $null) {
		If ($Line -like "*Testing URL :*") {
			$SuccessCounter = 0       
			For ($i=0; $i -le 5; $i++)  {
				$Line = $Streamer.ReadLine()
				If ($Line -like "*(200)*") {
					$SuccessCounter+=1
				}
			}
			If ($SuccessCounter -eq 0) {
				Break;
			}
		}
	}
	$Streamer.Dispose()
	if ($SuccessCounter -eq -1) {
		WriteMessage -severity "warning" -id "EDRCheckErr" -desc ( `
			"EDR Cloud checks have not run successfully.")
	} elseif ($SuccessCounter -gt 0) {
			WriteMessage -severity "info" -id "EDRCloudOK" -desc ( `
				"Test connection to the Defender ATP cloud service completed successfully.")
	} else {
			WriteMessage -severity "warning" -id "EDRCloudErr" -desc ( `
				"Some test connections to the Defender ATP (EDR) cloud service URLs may have failed.`r`n" `
				+ "Please make sure connections to Defender ATP cloud URLs are not blocked:`r`n" `
				+ "https://docs.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/configure-proxy-internet#enable-access-to-microsoft-defender-atp-service-urls-in-the-proxy-server `r`n" `
				+ "For details review $resultOutputDir") 
	}
}

function CheckConnectivity { param (
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$OSPreviousVersion,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$connectivityCheckFile,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$connectivityCheckUserFile
    )

    [version]$mindotNet="4.0.30319"
    
    SetUrlList -OSPreviousVersion $OSPreviousVersion

    if ((Get-RegistryValue -Path  "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Client" -Value Version)) {
        [version]$dotNet = Get-RegistryValue -Path  "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Client" -Value Version
    } else {
        [version]$dotNet = "0.0.0000"
    }

    if (!$OSPreviousVersion) {
        StartTraces        
		$MDATPClientAnalyzerCommand = Join-Path $ToolsDir "MDATPClientAnalyzer.exe"
		# check if running with system context (i.e. script was most likely run remotely via "psexec.exe -s \\machine command")
        if ($system){
			"`r`nConnectivity output, running as System:" | Out-File $connectivityCheckFile -Append
			Set-Location -Path $ToolsDir
			&$MDATPClientAnalyzerCommand >> $connectivityCheckFile
			Set-Location -Path $outputDir
        } else {
			"`r`nConnectivity output, using psexec -s:" | Out-File $connectivityCheckFile -Append
			Write-Host "The tool checks connectivity to Microsoft Defender ATP service URLs. This may take longer to run if URLs are blocked."
			& ($PSScriptRoot + "\PsExec.exe") $ARMcommand -accepteula -nobanner -s -w "$ToolsDir" "$MDATPClientAnalyzerCommand" -p $manualProxy >> $connectivityCheckFile
			# Run the tool as interactive user (for authenticated proxy scenario)
			Start-Process -wait -WindowStyle minimized $MDATPClientAnalyzerCommand -WorkingDirectory $ToolsDir -RedirectStandardOutput $connectivityCheckUserFile
		}
		ValidateURLs
        StopTraces
    }
    elseif ($dotNet -ge $mindotNet) {
        StartTraces

        $PSExecCommand = Join-Path $PSScriptRoot "PsExec.exe"
		Write-Host "The tool checks connectivity to Microsoft Defender ATP service URLs. This may take longer to run if URLs are blocked."
		$MDATPClientAnalyzerPreviousVersionCommand = Join-Path $ToolsDir "MDATPClientAnalyzerPreviousVersion.exe"
		# check if running with system context (i.e. script was most likely run remotely via "psexec.exe -s \\machine command")
        if ($system){
			Set-Location -Path $ToolsDir
			$Global:connectivityresult = (&$MDATPClientAnalyzerPreviousVersionCommand)
			Set-Location -Path $outputDir
        } else {
			$Global:connectivityresult = (& $PSExecCommand -accepteula -s -nobanner -w "`"$($ToolsDir.TrimEnd('\'))`"" "$MDATPClientAnalyzerPreviousVersionCommand" )
			# Run the tool as interactive user (for authenticated proxy scenario)
			Start-Process -wait -WindowStyle minimized $MDATPClientAnalyzerPreviousVersionCommand -WorkingDirectory $ToolsDir -RedirectStandardOutput $connectivityCheckUserFile
			$Global:connectivityresultUser = (Get-Content $connectivityCheckUserFile)
		}
            
        #Run MMA Connectivity tool
        $MMARootFolder = "$env:ProgramFiles\Microsoft Monitoring Agent\Agent"
        if(Test-Path -path $MMARootFolder){
            $Global:TestOMSResult = & $MMARootFolder\TestCloudConnection.exe 
        }

        StopTraces
    } else {
        Write-Host -BackgroundColor Red -ForegroundColor Yellow "To run URI validation tool please install .NET framework 4.0  or higher"
            "To run URI validation tool please install .NET framework 4.0 or higher" | Out-File $connectivityCheckFile -Append
        $Global:connectivityresult = $false
        $Global:connectivityresultUser = $false
        $Global:TestOMSResult = $false
    }

	if ($OSPreviousVersion) {
		$HealthServiceDll = "$env:ProgramFiles\Microsoft Monitoring Agent\Agent\HealthService.dll"
		if (Test-Path -path $HealthServiceDll) {
			$healthserviceprops = @{
				Message = ""
				Valid = $true
				Version = [string]((Get-ItemProperty -Path "$HealthServiceDll").VersionInfo).ProductMajorPart +'.' +[string]((Get-ItemProperty -Path "$HealthServiceDll").VersionInfo).ProductMinorPart +'.'+[string]((Get-ItemProperty -Path "$HealthServiceDll").VersionInfo).ProductBuildPart +'.'+[string]((Get-ItemProperty -Path "$HealthServiceDll").VersionInfo).FilePrivatePart
			}
			$Global:healthservicedll = new-object psobject -Property $healthserviceprops

			If ($OSBuild -eq "7601") {
				<#
				Supported versions for Windows Server 2008 R2 / 2008 / Windows 7
				x64 - 10.20.18029,  10.20.18038, 10.20.18040
				x86 - 10.20.18049
				#>
				if ([Environment]::Is64BitOperatingSystem) {
					[version]$HealthServiceSupportedVersion = '10.20.18029'
				} else {
					[version]$HealthServiceSupportedVersion = '10.20.18049'
				}

				If ([version]$Global:healthservicedll.version -lt $HealthServiceSupportedVersion) {
					$Global:healthservicedll.Valid = $false
					$Global:healthservicedll.Message = "The Log Analytics Agent version installed on this machine ("+$Global:healthservicedll.version+") is deprecated as it does not support SHA2 for code signing.`r`n" `
					+"Note that the older versions of the Log Analytics will no longer be supported and will stop sending data in a future timeframe. More information: https://aka.ms/LAAgentSHA2 `r`n" `
					+"Please upgrade to the latest version:`r`n" `
					+"- Windows 64-bit agent - https://go.microsoft.com/fwlink/?LinkId=828603 `r`n"`
					+"- Windows 32-bit agent - https://go.microsoft.com/fwlink/?LinkId=828604"
				} else {
					$Global:healthservicedll.Message = "The version " +$Global:healthservicedll.version +" of HealthService.dll is supported"
				}
			}
		}
	}
	
    if ('$env:SystemRoot\\System32\wintrust.dll') {
        [version]$wintrustMinimumFileVersion = '6.1.7601.23971'
        $wintrustprops = @{
            Message = ""
            Valid = $true
            Version = [string]((Get-ItemProperty -Path $env:SystemRoot\\System32\wintrust.dll).VersionInfo).ProductMajorPart +'.' +[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\wintrust.dll).VersionInfo).ProductMinorPart +'.'+[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\wintrust.dll).VersionInfo).ProductBuildPart +'.'+[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\wintrust.dll).VersionInfo).FilePrivatePart
        }
        $Global:wintrustdll = new-object psobject -Property $wintrustprops

        if (([version]$Global:wintrustdll.version -lt $wintrustMinimumFileVersion) ) {
            $Global:wintrustdll.Valid = $false
            $Global:wintrustdll.Message = "Environment is not supported: "+[System.Environment]::OSVersion.VersionString+ "`r`nMDATP can't start - it requires wintrust.dll version $wintrustMinimumFileVersion or higher, while this machine has version " + $wintrustdll.version + ". `r`n" `
                +"You should install one of the following updates:`r`n" `
                +"* KB4057400 - 2018-01-19 preview of monthly rollup.`r`n" `
                +"* KB4074598 - 2018-02-13 monthly rollup.`r`n" `
                +"* A later monthly rollup that supersedes them.`r`n"
        } else {
            $Global:wintrustdll.Message = "The version " +$Global:wintrustdll.version +" of wintrust.dll is supported"
        }
    }

    if (('$env:SystemRoot\\System32\tdh.dll')) {
		$tdhprops = @{
            Message = ""
            Valid = $true
            Version = [string]((Get-ItemProperty -Path $env:SystemRoot\\System32\tdh.dll).VersionInfo).ProductMajorPart +'.' +[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\tdh.dll).VersionInfo).ProductMinorPart +'.'+[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\tdh.dll).VersionInfo).ProductBuildPart +'.'+[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\tdh.dll).VersionInfo).FilePrivatePart
        }
        $Global:tdhdll = new-object psobject -Property $tdhprops
		
		if ($OSBuild -eq "9600") {
			[version]$gdrTdhMinimumFileVersion = '6.3.9600.17958'
		}
		else {
			[version]$gdrTdhMinimumFileVersion = '6.1.7601.18939'
			[version]$ldrMinimumFileVersion = '6.1.7601.22000'
			[version]$ldrTdhMinimumFileVersion = '6.1.7601.23142'
		}
	
		if ([version]$Global:tdhdll.Version -lt $gdrTdhMinimumFileVersion) {
			$Global:tdhdll.Valid = $false
			$Global:tdhdll.Message =  "Environment is not supported: "+[System.Environment]::OSVersion.VersionString+ "`r`nMDATP can't start - it requires tdh.dll version $gdrTdhMinimumFileVersion or higher, while this machine has version " + $tdhdll.version + ". `r`n" `
				+"You should install the following update:`r`n" `
				+"* KB3080149 - Update for customer experience and diagnostic telemetry.`r`n"
		}
		elseif ($OSBuild -eq "7601" -and [version]$Global:tdhdll.Version -ge $ldrMinimumFileVersion -and [version]$tdhdll.Version -lt $ldrTdhMinimumFileVersion) {
			$Global:tdhdll.Valid = $false
			$Global:tdhdll.Message =  "Environment is not supported: "+[System.Environment]::OSVersion.VersionString+ "`r`nMDATP can't start - it requires tdh.dll version $ldrTdhMinimumFileVersion or higher, while this machine has version " + $tdhdll.version + ". `r`n" `
				+"You should install the following update:`r`n" `
				+"* KB3080149 - Update for customer experience and diagnostic telemetry.`r`n"
		} else {
			$Global:tdhdll.Message = "The version " +$Global:tdhdll.version +" of tdh.dll is supported"
		}
	}

    $protocol = [Enum]::ToObject([System.Net.SecurityProtocolType], 3072)
    [string]$global:SSLProtocol = $null
    try {
        [System.Net.ServicePointManager]::SecurityProtocol = $protocol
    } catch [System.Management.Automation.SetValueInvocationException] {
        $global:SSLProtocol = "`r`nEnvironment is not supported , the missing KB must be installed`r`n"`
            +"" +[System.Environment]::OSVersion.VersionString+", MDATP requires TLS 1.2 support in .NET framework 3.5.1, exception "+$_.Exception.Message +" . You should install the following updates:`n" `
            +"* KB3154518 - Support for TLS System Default Versions included in the .NET Framework 3.5.1 on Windows 7 SP1 and Server 2008 R2 SP1`n"`
            +"* .NET framework 4.0 or later.`n"`
            +"########################################################################################################################" 
    } Catch [Exception] {
        $global:SSLProtocol = $_.Exception.Message
    }
}

function TestASRRules() {
    #Taken from: https://docs.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/attack-surface-reduction#block-process-creations-originating-from-psexec-and-wmi-commands
    $ASRRuleBlockPsExec = "d1e49aac-8f56-4280-b9ba-993a6d77406c"

	$ASRRules = (Get-MpPreference).AttackSurfaceReductionRules_Ids
	$ASRActions = (Get-MpPreference).AttackSurfaceReductionRules_Actions
	if (($ASRRules) -and ($ASRActions) -and (!$system)) {
		Write-output "############################ ASR rule check ###############################" | Out-File $connectivityCheckFile -Append
		# Check for existance of 'Block' mode ASR rule that can block PsExec from running
        $RuleIndex = $ASRRules::indexof($ASRRules,$ASRRuleBlockPsExec)
		if (($RuleIndex -ne -1) -and ($ASRActions[$RuleIndex] -eq 1)) {
			# Check if exclusions on script path are set
			$ASRRulesExclusions = (Get-MpPreference).AttackSurfaceReductionOnlyExclusions
			if (($ASRRulesExclusions) -and (($ASRRulesExclusions -contains $PSScriptRoot + '\') -or ($ASRRulesExclusions -contains $PSScriptRoot))) {
				"ASR rule 'Block process creations originating from PSExec and WMI commands' exists in block mode, but script path is excluded as needed" | Out-File $connectivityCheckFile -Append
                Write-Host -BackgroundColor Green -ForegroundColor black "Script path is excluded from ASR rules so URL checks can run as expected."
			} 
            else {
                "ASR rule 'Block process creations originating from PSExec and WMI commands' exists on the machine and is in Block mode" | Out-File $connectivityCheckFile -Append
			    Write-Host -BackgroundColor Red -ForegroundColor Yellow "Please note that ASR rule 'Block process creations originating from PSExec and WMI commands' is enabled and can block this tool from performing network validation if no exclusion is set" 			
            }
		}
	}
}

#This function expects to receive the EventProvider, EventId and Error string and returns the error event if found
function Get-MatchingEvent($EventProvider, $EventID, $ErrorString) {
	$event = Get-WinEvent -ProviderName $EventProvider -MaxEvents 1000 -ErrorAction SilentlyContinue `
	| Where-Object -Property Id -eq $EventID `
	| ? {$_.Properties.Value -like "*$ErrorString*"} `
	| Sort-Object -Property TimeCreated -Unique `
    | Select-Object -L 1
	
	return $EventError = $event;
}

function CheckProxySettings() {		
	$RegPathHKLM = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings"
	$RegPathHKU = "HKU:\S-1-5-18\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings"
	$RegPathHKCU = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings"
	$RegPathDefault = "HKU:\.DEFAULT\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings"

	if (Get-RegistryValue -Path $RegPathHKLM -Value "ProxyServer") {
		"Proxy settings in machine level were detected" | Out-File $connectivityCheckFile -append
		"The detected Proxy settings in machine path (HKLM) are :  " + (Get-RegistryValue -Path $RegPathHKLM -Value "ProxyServer" ) | Out-File $connectivityCheckFile -append
		"ProxyEnable is set to :  " + (Get-RegistryValue -Path $RegPathHKLM -Value "ProxyEnable" ) | Out-File $connectivityCheckFile -append
	} 
	
	if (Get-RegistryValue -Path $RegPathHKU -Value "ProxyServer") {
	    "Proxy settings in SYSTEM SID level were detected" | Out-File $connectivityCheckFile -append
	    "The detected proxy settings in SYSTEM HKU path (S-1-5-18) are :  " + (Get-RegistryValue -Path $RegPathHKU -Value "ProxyServer" ) | Out-File $connectivityCheckFile -append
		"ProxyEnable is set to :  " + (Get-RegistryValue -Path $RegPathHKU -Value "ProxyEnable" ) | Out-File $connectivityCheckFile -append
	} 

	if (Get-RegistryValue -Path $RegPathHKCU -Value "ProxyServer") {
	    "Proxy setting in current user level were detected" | Out-File $connectivityCheckFile -append
		"The detected proxy settings in current user path (HKCU) are :  " + (Get-RegistryValue -Path $RegPathHKCU -Value "ProxyServer" ) | Out-File $connectivityCheckFile -append
		"ProxyEnable is set to :  " + (Get-RegistryValue -Path $RegPathHKCU -Value "ProxyEnable" ) | Out-File $connectivityCheckFile -append
	}
	if (Get-RegistryValue -Path $RegPathDefault -Value "ProxyServer") {
	    "Proxy setting in DEFAULT user level were detected" | Out-File $connectivityCheckFile -append
		"The detected proxy settings in the default user path (.DEFAULT) are :  " + (Get-RegistryValue -Path $RegPathDefault -Value "ProxyServer" ) | Out-File $connectivityCheckFile -append
		"ProxyEnable is set to :  " + (Get-RegistryValue -Path $RegPathDefault -Value "ProxyEnable" ) | Out-File $connectivityCheckFile -append
	}
}
function GetAddRemovePrograms($regpath) {
	    $programsArray = $regpath | % { New-Object PSObject -Property @{
        DisplayName = $_.GetValue("DisplayName")
        DisplayVersion = $_.GetValue("DisplayVersion")
        InstallLocation = $_.GetValue("InstallLocation")
        Publisher = $_.GetValue("Publisher")
    }}
    $ProgramsArray | ? { $_.DisplayName }
}

function FormatTimestamp($TimeStamp) {
	if ($TimeStamp) {
		return ([DateTime]::FromFiletime([Int64]::Parse($TimeStamp))).ToString("U")
	} 
	else {
		return "Unknown"
	}
}

function Dump-ConnectionStatus {
	"Last SevilleDiagTrack LastNormalUploadTime TimeStamp: " + (FormatTimestamp($LastCYBERConnected)) | Out-File $connectivityCheckFile -append
	"Last SevilleDiagTrack LastRealTimeUploadTime TimeStamp: " + (FormatTimestamp($LastCYBERRTConnected)) | Out-File $connectivityCheckFile -append
    "Last SevilleDiagTrack LastInvalidHttpCode: " + $LastInvalidHTTPcode | Out-File $connectivityCheckFile -append
}

function Get-MachineInfo {
	"Machine name: " + $env:computername | Out-File $connectivityCheckFile -append
	"Machine Operating System: " + $OSProductName | Out-File $connectivityCheckFile -append
	"Machine build number: " + [System.Environment]::OSVersion.VersionString + " Minor build number: " + $MinorBuild | Out-File $connectivityCheckFile -append
	"Machine Edition: " + $OSEditionName | Out-File $connectivityCheckFile -append
	"Machine Architecture: " + $arch | Out-File $connectivityCheckFile -append
}

function Collect-RegValues {
	[int]$MinorBuild = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\" -Value "UBR" )
	[string]$SenseId = (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\Windows Advanced Threat Protection" -Value "SenseId")
	[string]$DeviceTag = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection\DeviceTagging" -Value "Group")
	[string]$GroupIds = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection" -Value "GroupIds") 
	[string]$LastCnCConnected = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\Status" -Value LastConnected)
	if (!$OSPreviousVersion) {
		$sensepr = (Get-item -Path "C:\Program Files\Windows Defender Advanced Threat Protection\MsSense.exe" -ErrorAction SilentlyContinue)    
	} else {
		$sensepr = Get-ChildItem -Path "C:\Program Files\Microsoft Monitoring Agent\Agent\Health Service State\Monitoring Host Temporary File*" -Filter mssenses.exe -Recurse -ErrorAction SilentlyContinue | Sort-Object -Property LastWriteTime -Unique
	}
	Get-MachineInfo
	if (!$SenseId) {
		# Option to get SenseID from event log as some older OS versions only post Sense Id to log
		$SenseId = (Get-WinEvent -ProviderName Microsoft-Windows-SENSE -ErrorAction SilentlyContinue | Where-Object -Property Id -eq 13 | Sort-Object -Property TimeCreated | Select-Object -L 1).Message			
	}
	if ($SenseId) {
		"Device ID is: " + $SenseId | Out-File $connectivityCheckFile -append
		"OrgID is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\Status" -Value "OrgID") | Out-File $connectivityCheckFile -append
		if ($sensepr) {
			[version]$SenseVer = [string](($sensepr).VersionInfo).ProductMajorPart +'.' +[string](($sensepr).VersionInfo).ProductMinorPart +'.'+[string](($sensepr).VersionInfo).ProductBuildPart +'.'+[string](($sensepr).VersionInfo).FilePrivatePart
			"Sense version is: "+$SenseVer | Out-File $connectivityCheckFile -append
		}
		"Sense ConfigurationVersion is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\Status" -Value "ConfigurationVersion" ) | Out-File $connectivityCheckFile -append
		"Sense GUID is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection" -Value "senseGuid") | Out-File $connectivityCheckFile -append
		if ($DeviceTag -ne $False) {
			"Optional Sense DeviceTag is: " + $DeviceTag | Out-File $connectivityCheckFile -append
		}		
		if ($GroupIds) {
			"Optional Sense GroupIds is: " + $GroupIds | Out-File $connectivityCheckFile -append
		}
		if ($LastCnCConnected) {
			"Last Sense Seen TimeStamp is: " + (FormatTimestamp($LastCnCConnected)) | Out-File $connectivityCheckFile -append
		}
	}
	if (!$IsOnboarded) {
        "Machine is: not onboarded" | Out-File $connectivityCheckFile -append
    }
}

Function StartGet-MSInfo ([boolean]$NFO=$true, [boolean]$TXT=$true, [string]$OutputLocation=$PWD.Path, [string]$Suffix = '') {
	$Process = "msinfo32.exe"
	
	if (test-path (join-path ([Environment]::GetFolderPath("System")) $Process)) {
		$ProcessPath = (join-path ([Environment]::GetFolderPath("System")) $Process)
	} elseif (test-path (join-path ([Environment]::GetFolderPath("CommonProgramFiles")) "Microsoft Shared\MSInfo\$Process")) {
		$ProcessPath = (join-path ([Environment]::GetFolderPath("CommonProgramFiles")) "Microsoft Shared\MSInfo\$Process")
	} else {
		$ProcessPath = "cmd.exe /c start /wait $Process"
	}

	if ($TXT) {
		$InfoFile = Join-Path -Path $OutputLocation -ChildPath ("msinfo32" + $Suffix + ".txt")
		&$ProcessPath /report "$InfoFile"
	}
	if ($NFO) {
		$InfoFile = Join-Path -Path $OutputLocation -ChildPath ("msinfo32" + $Suffix + ".nfo")
		&$ProcessPath /nfo "$InfoFile"
	}
}


function EndGet-MSInfo() {
	$proc = Get-Process msinfo32 -EA SilentlyContinue
	if ($proc) {
		Write-Host "Waiting max $ProcessWaitMin minutes on MsInfo32 processes to complete "
		Wait-Process -InputObject $proc -Timeout ($ProcessWaitMin * 60) -EA SilentlyContinue
		$MsInfoProcess = Get-Process | Where-Object { $_.Name -eq "msinfo32" } -EA SilentlyContinue
		if ($MsInfoProcess -ne $null) {
			Write-Host "MSInfo32 timeout reached ..."
			foreach ($process in $MsInfoProcess) {stop-Process $process -Force -EA SilentlyContinue}
		}
	}
}
#endregion  ::::: [Functions] --------------------------------------------------------#

#region  ::::: MAIN [Execution]-------------------------------------------------------#
InitXmlLog
[int]$OSBuild = Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Value CurrentBuild
[string]$OSEditionID = Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Value EditionID
[string]$OSProductName =  Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Value ProductName
[string]$OSEditionName = Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Value InstallationType
[string]$IsOnboarded = Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\Status" -Value OnboardingState 
[int]$PsMjVer = $PSVersionTable.PSVersion.Major
[string]$arch = $env:PROCESSOR_ARCHITECTURE
if ($arch -like "ARM*") {
	$ARM = $true
	$ARMcommand = "-ARM"
}
[string]$context = (&whoami.exe)
if ($context -eq "nt authority\system") {
	$system = $true 
} 

# Storing HKU reg path for later use
New-PSDrive HKU Registry HKEY_USERS -ErrorAction SilentlyContinue | Out-Null

if (($OSBuild -le 7601) -And ($PsMjVer -le 2)) { 
	Write-Host -ForegroundColor Yellow "We recommend installing at least 'Windows Management Framework 3.0' (KB2506143) or later for optimal script results: `r`nhttps://www.microsoft.com/en-us/download/details.aspx?id=34595"
}

if ((Test-Path -Path $ToolsDir) -eq $False) {
	Write-Host -ForegroundColor Yellow "Missing 'Tools' directory. Exiting script."
	[Environment]::Exit(1)
}

#Store paths for MpCmdRun.exe usage
if ((Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WinDefend" -Value ImagePath) -and ($OSBuild -ge 14393)) {
	$MsMpEngPath = Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WinDefend" -Value ImagePath
	[System.IO.DirectoryInfo]$CurrentMpCmdPath = $MsMpEngPath -replace "MsMpEng.exe" -replace """"
	$MpCmdRunCommand = Join-Path $CurrentMpCmdPath "MpCmdRun.exe"
	$MpCmdResultPath = "$env:ProgramData\Microsoft\Windows Defender\Support"
}
elseif (Test-Path -path "$env:ProgramFiles\Microsoft Security Client\MpCmdRun.exe") {
	$CurrentMpCmdPath = "$env:ProgramFiles\Microsoft Security Client\"
	$MpCmdRunCommand = "$env:ProgramFiles\Microsoft Security Client\MpCmdRun.exe"
	$MpCmdResultPath = "$env:ProgramData\Microsoft\Microsoft Antimalware\Support"
}

# Delete previous output if exists
if(Test-Path $resultOutputDir) {
    Remove-Item -Recurse -Force $resultOutputDir -ErrorVariable FileInUse;
    while ($FileInUse) {
        Write-Warning "Please close any opened log files from previous MDATPClientAnalyzer run and then try again."
        Read-Host "Press ENTER once you've closed all open files."
        Remove-Item -Recurse -Force $resultOutputDir -ErrorVariable FileInUse
    }
}
if(Test-Path $outputZipFile) {
    Remove-Item -Recurse -Force  $outputZipFile
}

# Create output folders
New-Item -ItemType directory -Path $resultOutputDir | Out-Null
New-Item -ItemType Directory -Path "$resultOutputDir\EventLogs" | out-Null
New-Item -ItemType Directory -Path "$resultOutputDir\SystemInfoLogs" | out-Null

"Script Version: " + $ScriptVer | Out-File $connectivityCheckFile -append
"Script run time: " + (Get-Date) | Out-File $connectivityCheckFile -append
Write-output "######################## Machine Info summary #############################" | Out-File $connectivityCheckFile -append
if ((($OSBuild -ge 7601 -and $OSBuild -le 14393) -and ($OSProductName -notmatch 'Windows 10')) -and (($OSEditionID -match 'Enterprise') -or ($OSEditionID -match 'Pro') -or ($OSEditionID -match 'Ultimate') -or ($OSEditionID -match 'Server'))) {
    $OSPreviousVersion = $true
	Collect-RegValues
    CheckConnectivity -OSPreviousVersion $OSPreviousVersion -connectivityCheckFile $connectivityCheckFile -connectivityCheckUserFile $connectivityCheckUserFile
      
    if ($Global:tdhdll.Valid -and $Global:wintrustdll.Valid -and !($global:SSLProtocol)) {
        "OS Environment is  supported: "+[System.Environment]::OSVersion.VersionString | Out-File $connectivityCheckFile -append
    } else {
        "OS Environment is not  supported: "+[System.Environment]::OSVersion.VersionString + " More information below" | Out-File $connectivityCheckFile -append
    }

    if ($Global:connectivityresult -match "failed" ) {
        "Command and Control channel as System Account : Some of the MDATP APIs failed , see details below" | Out-File $connectivityCheckFile -append
    } elseif (!$Global:connectivityresult) {
        "Command and Control channel as System Account: Not tested" | Out-File $connectivityCheckFile -append 
    } else {
        "Command and Control channel as System Account: Passed validation" | Out-File $connectivityCheckFile -append 
    }

    if ($Global:connectivityresultUser -match "failed" ) {
        "Command and Control channel as User Account : Some of the MDATP APIs failed , see details below" | Out-File $connectivityCheckFile -append
    } elseif (!$Global:connectivityresultUser) {
        "Command and Control channel as User Account: Not tested" | Out-File $connectivityCheckFile -append 
    } else {
        "Command and Control channel as User Account: Passed validation" | Out-File $connectivityCheckFile -append 
    }

	if (Test-Path -Path "HKLM:\SYSTEM\CurrentControlSet\services\HealthService\Parameters")  {
		Get-ChildItem HKLM:\SYSTEM\CurrentControlSet\services\HealthService\Parameters -recurse | Format-table -AutoSize | Out-File "$resultOutputDir\SystemInfoLogs\HealthServiceReg.txt"
		# Test if multiple MMA workspaces are configured
		$AgentCfg = New-Object -ComObject AgentConfigManager.MgmtSvcCfg
		$workspaces = $AgentCfg.GetCloudWorkspaces()
		if ($workspaces.Item(1)) {
			Write-output "`r`n############################ Multiple workspaces check ###############################" | Out-File $connectivityCheckFile -Append
			WriteMessage -severity "warning" -id "MmaWorkspaceCheck" -desc ( `
                "Please note the machine has multiple MMA (Microsoft Monitoring Agent) workspaces.`r`n" `
                + "If the machine is onboarded to Defender ATP via ASC (Azure Security Center) integration, then it is recommended to remove the MDATP workspace to avoid cyber upload issues.`r`n" `
				+ "For more information on ASC integration with Defender ATP please refer to: https://docs.microsoft.com/en-us/azure/security-center/security-center-wdatp#onboarding-servers-to-security-center`r`n") 
		}
	}
} 

if (!$OSPreviousVersion) {
    if ((Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\Status" -Value OnboardingState ) -eq $True) {
		$IsOnboarded = $True		
		Collect-RegValues
        "Sense service state is: " + (Get-Service -Name Sense).Status | Out-File $connectivityCheckFile -append
        "UTC service state is: " + (Get-Service -Name DiagTrack).Status | Out-File $connectivityCheckFile -append
        "Defender service state is: " + (Get-Service -Name WinDefend).Status | Out-File $connectivityCheckFile -append
		if ($OSEditionName -notlike "*core") {
			"Microsoft Account Sign-in Assistant service start type is: " + (Get-Service -Name wlidsvc).StartType | Out-File $connectivityCheckFile -append
		}
        if (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Defender" -Value "PassiveMode") {
			$AVPassiveMode = $true
            "Windows Defender is in passive mode" | Out-File $connectivityCheckFile -append
        }
        "Windows Defender AV Signature Version is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Defender\Signature Updates" -Value "AVSignatureVersion" )  + "  Engine Version is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Defender\Signature Updates" -Value "EngineVersion" )  | Out-File $connectivityCheckFile -append
        if ($IsOnboarded) {
			if ($OSBuild -eq 14393) {
				$LastCYBERConnected = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\SevilleSettings" -Value LastNormalUploadTime)
				$LastCYBERRTConnected = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\SevilleSettings" -Value LastRealTimeUploadTime)
				$LastInvalidHTTPcode = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\HeartBeats\Seville" -Value LastInvalidHttpCode)
				Dump-ConnectionStatus 
			} elseif ($OSBuild -le 17134) {
				$LastCYBERConnected = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\Tenants\P-WDATP" -Value LastNormalUploadTime)
				$LastCYBERRTConnected = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\Tenants\P-WDATP" -Value LastRealTimeUploadTime)
				$LastInvalidHTTPcode = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\HeartBeats\Seville" -Value LastInvalidHttpCode)
				Dump-ConnectionStatus
			} elseif ($OSBuild -ge 17763) {
				$LastCYBERConnected = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\TelLib" -Value LastSuccessfulNormalUploadTime)
				$LastCYBERRTConnected = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\TelLib" -Value LastSuccessfulRealtimeUploadTime)
				$LastInvalidHTTPcode = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\TelLib\HeartBeats\Seville" -Value LastInvalidHttpCode)
				Dump-ConnectionStatus
			}
		}


	# Test for events indicating expired OrgID in Sense event logs
	Write-output "`r`n############################ OrgID error check ###############################" | Out-File $connectivityCheckFile -Append
	$OrgId = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\Status" -Value "OrgID" )
	$EventError = (Get-MatchingEvent Microsoft-Windows-SENSE 67 "400")
	if (!$EventError) {
		$EventError = (Get-MatchingEvent Microsoft-Windows-SENSE 5 "400")
	}
	$EventOk = (Get-MatchingEvent Microsoft-Windows-SENSE 4 "winatp")
	if (!$EventError) {
		"Based on SENSE log, no OrgId mismatch errors were found in events" | Out-File $connectivityCheckFile -Append
	} 		
	if (($EventOk) -and ($EventError)) {
		if ((Get-Date $EventOk.TimeCreated) -gt (Get-Date $EventError.TimeCreated)) {
			"Based on SENSE log, the machine is linked to an active Organization ID: $orgID`r`n" | Out-File $connectivityCheckFile -Append
		} 
	} elseif ($EventError) {
		Write-output "Event Log error information:" | Out-File $connectivityCheckFile -Append
		$EventError | ft -Wrap | Out-File $connectivityCheckFile -Append
		WriteMessage -severity "error" -id "OrgIdExpired" -desc ( `
		"Machine is reporting to an expired Organization ID: $orgID`r`n" `
		+ "You should offboard the machine from this organization, and then onboard it to your current organization.`r`n" `
		+ "Contact Microsoft Support if you don't have access to the offboarding script with the above mentioned OrgID.`r`n" `
		+ "Note: To view the current OrgID, please go to the MDATP portal (securitycenter.microsoft.com) and click on the user name in the top right corner.`r`n")
	}
} 

	# Dump Registry OnboardingInfo if exists
	$RegOnboardingInfo = Get-RegistryValue "HKLM:\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection\" -Value OnboardingInfo 
	$RegOnboardedInfo = Get-RegistryValue "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\" -Value OnboardedInfo 
	if (($RegOnboardingInfo -eq $False) -or ($RegOnboardingInfo -eq $null)) {
		Get-MachineInfo
		"`r`Note: OnboardingInfo could not be found in the registry. This can be expected if machine was offboarded or onboarding was not yet executed." | Out-File $connectivityCheckFile -Append
	} else {
		($RegOnboardingInfo | ConvertFrom-Json).body | Out-File "$resultOutputDir\SystemInfoLogs\RegOnboardingInfoPolicy.Json"
		($RegOnboardedInfo | ConvertFrom-Json).body | Out-File "$resultOutputDir\SystemInfoLogs\RegOnboardedInfoCurrent.Json"
	}

    CheckConnectivity -OSPreviousVersion $OSPreviousVersion -connectivityCheckFile $connectivityCheckFile -connectivityCheckUserFile $connectivityCheckUserFile
}

if ((($OSBuild -ge 7601 -and $OSBuild -le 14393) -and ($OSProductName -notmatch 'Windows 10')) -and (($OSEditionID -match 'Enterprise') -or ($OSEditionID -match 'Pro') -or ($OSEditionID -match 'Ultimate') -or ($OSEditionID -match 'Server'))) {
    "`r`n###################### OMS validation details  ###########################" | Out-File $connectivityCheckFile -append
    if ($Global:TestOMSResult -match "Connection failed" -or $Global:TestOMSResult -match "Blocked Host") {
        "OMS channel: Some of the OMS APIs failed , see details below" | Out-File $connectivityCheckFile -append
    } elseif (!$Global:TestOMSResult) {
        "OMS channel: Not tested" | Out-File $connectivityCheckFile -append 
    } else {
        "OMS channel: Passed validation" | Out-File $connectivityCheckFile -append 
		"Service Microsoft Monitoring Agent is " + (Get-Service -Name HealthService -ErrorAction SilentlyContinue).Status | Out-File $connectivityCheckFile -append
		"Health Service DLL version is: "+$Global:healthservicedll.version | Out-File $connectivityCheckFile -append
		If (!$Global:healthservicedll.Valid) {
			"`n" | Out-File $connectivityCheckFile -append
			WriteMessage -severity "warning" -id "OMSHealthWarning" -desc ($Global:healthservicedll.Message)
		}
    } 
    "`r`n###################### OS validation details  ###########################" | Out-File $connectivityCheckFile -append
    $Global:tdhdll.Message  | Out-File $connectivityCheckFile -append
    $Global:wintrustdll.Message  | Out-File $connectivityCheckFile -append
    $global:SSLProtocol | Out-File $connectivityCheckFile -append
    Write-output "##########################################################################`n" | Out-File $connectivityCheckFile -append  
    "######## Connectivity details for Command and Control  validation  #######" | Out-File $connectivityCheckFile -append
    $connectivityresult | Out-File $connectivityCheckFile -append
    Write-output "##########################################################################`n" | Out-File $connectivityCheckFile -append  
    "################# Connectivity details for OMS  validation  #########" | Out-File $connectivityCheckFile -append
    $Global:TestOMSResult | Out-File $connectivityCheckFile -append
    Write-output "##########################################################################`n" | Out-File $connectivityCheckFile -append  
}

if (!$OSPreviousVersion) {
	Write-output "`r`n################# Defender AntiVirus cloud service check ##################" | Out-File $connectivityCheckFile -Append
	if ($MpCmdRunCommand) {
		$MAPSCheck = &$MpCmdRunCommand -ValidateMapsConnection
		$MAPSErr = $MAPSCheck | Select-String -pattern "ValidateMapsConnection failed"
		if ($MAPSErr) { 
			WriteMessage -severity "warning" -id "AVCloudErr" -desc ( `
			"Test connection to the Windows Defender Antivirus cloud service failed:`r`n" `
			+ "$MAPSErr`r`n" `
			+ "If Windows Defender Antivirus is not in passive mode (ie. it is operating as your primary antivirus solution) - please make sure connections to AV cloud URLs are not blocked:`r`n" `
			+ "https://docs.microsoft.com/en-us/windows/security/threat-protection/windows-defender-antivirus/configure-network-connections-windows-defender-antivirus#allow-connections-to-the-windows-defender-antivirus-cloud-service `r`n")
		} else {
			$MAPSOK = $MAPSCheck | Select-String -pattern "ValidateMapsConnection successfully"
			if ($MAPSOK) {
				WriteMessage -severity "info" -id "AVCloudOK" -desc ( `
				"Test connection to the Windows Defender Antivirus cloud service completed successfully.`r`n")
			}
		}
	}
}

#Collect Performance traces if flagged
if ($wprpTraceL -or $wprpTraceH) {
	Get-PerformanceTraces
}

elseif ($AppCompatC) {
	Get-AppCompatTraces
}

elseif ($NetTraceI) {
	Get-NetTraces
}

elseif ($WDPerfTraceA) {
	Get-WdAvPerfTrace
}

elseif ($WDVerboseTraceV) {
	Get-WdAvVerboseTrace
}

elseif ($BootTraceB) {
	Set-BootTraces
}

elseif ($DlpT) {
	Get-DLPTraces
}

elseif ($DlpQ) {
	$DLPHealthCheck = Join-Path $ToolsDir "DLPDiagnose.ps1"
    &Powershell.exe $DLPHealthCheck
}

if ($CrashDumpD) {
	Get-CrashDumps
}

if ($FullCrashDumpZ) {
	Set-CrashOnCtrlScroll
	Set-FullCrashDump
	Write-Host -BackgroundColor Red -ForegroundColor Yellow "Please reboot the machine for the change in settings to apply" 
	Write-Host -ForegroundColor Green "To force the system to crash for memory dump collection, hold down the RIGHT CTRL key while pressing the SCROLL LOCK key twice"
	Write-Host "Note: This is not expected to work during Remote Desktop Protocol (RDP). For RDP please use the script with -k parameter instead"
}

if ($notmyfault) {
	Set-FullCrashDump
	if (!$RemoteRun) {
		[string]$notmyfault=(Read-Host "Type 'crashnow' and press ENTER to crash the machine and create a full machine dump now")
	}
	if (($notmyfault -eq "crashnow") -or ($RemoteRun)) {
		if ([Environment]::Is64BitOperatingSystem) {
			#_# $NotMyFaultCommand = Join-Path $ToolsDir "NotMyFaultc64.exe"
			$NotMyFaultCommand = Join-Path $DirScript\$ProcArch "NotMyFault.exe"
		} else {
			#_# $NotMyFaultCommand = Join-Path $ToolsDir "NotMyFaultc.exe"
			$NotMyFaultCommand = Join-Path $DirScript\$ProcArch "NotMyFault.exe"
		}
		& $NotMyFaultCommand /accepteula /Crash 1
	}
}

if (Test-Path -Path  $env:SystemRoot\System32\'Winevt\Logs\Operations Manager.evtx') {
	Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\Operations Manager.evtx' -Destination $resultOutputDir\EventLogs\OperationsManager.evtx
}

if (Test-Path -Path  $env:SystemRoot\System32\'Winevt\Logs\OMS Gateway Log.evtx') {
	Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\OMS Gateway Log.evtx' -Destination $resultOutputDir\EventLogs\OMSGatewayLog.evtx
}

if (test-path -Path $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-UniversalTelemetryClient%4Operational.evtx') {
	Copy-Item -path $env:SystemRoot\System32\Winevt\Logs\Microsoft-Windows-UniversalTelemetryClient%4Operational.evtx -Destination $resultOutputDir\EventLogs\utc.evtx
}

if (Test-Path -Path $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-SENSE%4Operational.evtx') {
	Copy-Item -path $env:SystemRoot\System32\Winevt\Logs\Microsoft-Windows-SENSE%4Operational.evtx -Destination $resultOutputDir\EventLogs\sense.evtx
	Copy-Item -path $env:SystemRoot\System32\Winevt\Logs\Microsoft-Windows-SenseIR%4Operational.evtx -Destination $resultOutputDir\EventLogs\senseIR.evtx -ErrorAction SilentlyContinue
}

# Test for ASR rule blocking PsExec
if ((!$OSPreviousVersion) -and (!$AVPassiveMode)){
	TestASRRules    
}

# Check if automatic update of Trusted Root Certificates is blocked
$AuthRootLocal = get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\SystemCertificates\AuthRoot" -ErrorAction SilentlyContinue
$AuthRootGPO = get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\SystemCertificates\AuthRoot" -ErrorAction SilentlyContinue
if (($AuthRootLocal.DisableRootAutoUpdate -eq "1") -or ($AuthRootGPO.DisableRootAutoUpdate -eq "1")) {
	Write-output "`r`n######################## Auth Root Policies #########################" | Out-File $connectivityCheckFile -Append
    WriteMessage -severity "info" -id "AuthRootChk" -desc ( `
	"Please note this machine is not set to automatically update Trusted Root Certificates from Windows Update`r`n" `
	+ "$AuthRootLocal`r`n" `
    + "$AuthRootGPO")
    if ($OSPreviousVersion) {
		$EventError = Get-MatchingEvent HealthService 2132 "12175L"
	} else {
		$EventError = Get-MatchingEvent Microsoft-Windows-SENSE 5 "12175"
	}
    if ($EventError) {
		WriteMessage -severity "Error" -id "AuthRootErr" -desc ( `
		"This machine has errors in EventLogs\OperationsManager.evtx indicating secure connection could not be negotiated in the event logs.`r`n" `
		+ "Please ensure the Trusted Root lists are correctly updated from WSUS or Windows Update.`r`n" `
		+ "If you are manually updating Trusted Roots, please ensure you follow guidelines in KB2813430:`r`n" `
		+ "https://support.microsoft.com/en-us/help/2813430/an-update-is-available-that-enables-administrators-to-update-trusted-a `r`n")
		$EventError | ft -Wrap | Out-File $connectivityCheckFile -Append
	} 
} else {
	"############## Connectivity Check for ctldl.windowsupdate.com #############" | Out-File $connectivityCheckFile -append
	$urlctldl =  "http://ctldl.windowsupdate.com/msdownload/update/v3/static/trustedr/en/pinrulesstl.cab"
	$webRequest = [net.WebRequest]::Create("$urlctldl")
	try {
		"StatusCode for " + $urlctldl + " IS : " + $webRequest.GetResponse().StatusCode | Out-File $connectivityCheckFile -append
	} catch [System.Net.WebException] {
		$ErrorMessage = $Error[0].Exception.ErrorRecord.Exception.Message;
        "Exception occurred for " + $urlctldl + " :" + $ErrorMessage | Out-File $connectivityCheckFile -append
        $Error[0].Exception.InnerException.Response | Out-File $connectivityCheckFile -append
		WriteMessage -severity "warning" -id "CertWuErr" -desc ( `
			"The trusted root certificates cannot be updated from Windows Update.`r`n" `
			+ "This can cause issues with Sensor CNC heartbeats or cyber data upload to cloud.`r`n" `
			+ "You must allow access to Automatic Root Certificates Update URL. For more information, refer to: `r`n" `
			+ "https://docs.microsoft.com/en-us/windows/privacy/manage-windows-1809-endpoints#certificates `r`n" `
			+ "Or, to facilitate the distribution of certificates for a disconnected environment, you must deploy a server that can download the CTL files from the automatic update mechanism: `r`n" `
			+ "https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2012-r2-and-2012/dn265983(v=ws.11) `r`n")
	}
}

# Validate certificate revocation
# public .cer file was fetched from the https://winatp-gw-cus.microsoft.com/test this needs to be updated if certificate changes
if (!$OSPreviousVersion) {
	"`r`n##################### certificate validation check ########################" | Out-File $connectivityCheckFile -Append	
	$CertResults = "$resultOutputDir\SystemInfoLogs\CertValidate.log"
	$certutilcommand = Join-Path $PSScriptRoot "PsExec.exe"
	if (!$system) {
	&$certutilcommand -accepteula -s -nobanner certutil.exe -verify -urlfetch "$ToolsDir\winatp.cer" | Out-File $CertResults
	} else {
		&certutil.exe -verify -urlfetch "$ToolsDir\winatp.cer" | Out-File $CertResults
	}
	$Certlog = (Get-Content $CertResults)
	if (!$Certlog) {
		WriteMessage -severity "warning" -id "CertVerifyNotTested" -desc ( `
			"Certificate revocation was not tested.`r`n" `
			+ "If the machine is in 'Impaired communications' status, try manually running 'certutil.exe -verify -urlfetch winatp.cer' from system context, to ensure revaction checks are working.`r`n") 
	} else {
		if (($Certlog -like "*Element.dwErrorStatus*") -or ($Certlog -like "*0x80072ee7*")) {
			WriteMessage -severity "warning" -id "CertVerifyFail" -desc ( `
				"Cloud connectivity may be impaired due to certificate revocation failures.`r`n" `
				+ "For details review $CertResults`r`n") 
		} else {
			WriteMessage -severity "info" -id "CertVerifyOK" -desc ( `
				"Certificate validation for the Defender ATP cloud service completed successfully.`r`n")
		}
	}
}

Write-Host "Evaluating sensor condition..."
"########################### PROXY SETTINGS ################################" | Out-File $connectivityCheckFile -append
 CheckProxySettings

(netsh winhttp show proxy) | Out-File $connectivityCheckFile -append

If (!$OSPreviousVersion) {
	# Test for DiagTrack listener on RS4 and earlier Win10 builds or SenseOms for Down-level OS, and export network proxy Registry settings
	Write-output "`r`n#################### Data Collection Registry setting #####################" | Out-File $connectivityCheckFile -Append

	$DiagTrackSvcStartType = (get-service -name diagtrack).StartType 
	If ($DiagTrackSvcStartType -eq "Disabled") {
		WriteMessage -severity "warning" -id "UTCDisabled" -desc ( `
			"UTC Service is Disabled. This machine may not be able to upload cyber data. Make the service is not disabled by Policy`r`n")
	}
	Get-Item HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection -ErrorAction SilentlyContinue| Out-File $connectivityCheckFile -Append
}
if ((!$OSPreviousVersion) -and ($buildNumber -le "17134")){
	Write-output "`r`n######################## DiagTrack Listener check #########################" | Out-File $connectivityCheckFile -Append
	$DiagTrackListener = &logman Diagtrack-Seville-Listener -ets
	$DiagTrackListener > "$resultOutputDir\SystemInfoLogs\DiagTrackListener.txt"
	$SevilleProv = $DiagTrackListener | Select-String "CB2FF72D-D4E4-585D-33F9-F3A395C40BE7"
	if ($SevilleProv -eq $null) {
		WriteMessage -severity "warning" -id "UTCListenerMissing" -desc ( `
		"DiagTrack (UTC) listener missing. This machine is unable to upload cyber data.`r`n" `
		+ "This can happen if *.settings-win.data.microsoft.com is blocked in your network and UTC the service cannot download a 1kb config file - contact Microsoft support if issue persists.`r`n")
	}
	else {
		WriteMessage -severity "info" -id "UTCListenerDetected" -desc ( `
		"DiagTrack (UTC) service listener detected.`r`n")
	}	
} elseif ($OSPreviousVersion) {
	Write-output "`r`n######################## SenseOms Listener check #########################" | Out-File $connectivityCheckFile -Append
	$SenseOmsListener = &logman SenseOms -ets
	$SenseOmsListener > "$resultOutputDir\SystemInfoLogs\SenseOmsListener.txt"
	$OmsProv = $SenseOmsListener | Select-String "CB2FF72D-D4E4-585D-33F9-F3A395C40BE7"
	if ($OmsProv -eq $null) {
		WriteMessage -severity "warning" -id "OmsListenerMissing" -desc ( `
		"SenseOms listener missing. This machine is unable to upload cyber data - contact Microsoft support if issue persists.`r`n")
	}
	else {
		WriteMessage -severity "info" -id "OmsListenerDetected" -desc ( `
		"SenseOms listener detected.`r`n")
	}	
}

if (!$OSPreviousVersion) {
	"################ Connectivity Check for Live Response URL ################" | Out-File $connectivityCheckFile -append
	$TestLR1 = TelnetTest "global.notify.windows.com" 443
	$TestLR2 = TelnetTest "client.wns.windows.com" 443
	$TestLR1 | Out-File $connectivityCheckFile -append
	$TestLR2 | Out-File $connectivityCheckFile -append
	# the abvoe test does not support proxy configuration as-is
	#if (($TestLR1 -notlike "Successfully connected*") -Or ($TestLR2 -notlike "Successfully connected*")) {
	#	WriteMessage -severity "warning" -id "LRcheckFail" -desc ( `
	#	"Failed to reach Windows Notification Service URLs required for Live Response.`r`n" `
	#	+ "Please ensure Live Response URLs are not blocked.`r`n" `
	#	+ "For more information, see: https://docs.microsoft.com/en-us/windows/uwp/design/shell/tiles-and-notifications/firewall-allowlist-config")
	#} elseif (($TestLR1 -like "Successfully connected*") -and ($TestLR2 -like "Successfully connected*")) {
	#	WriteMessage -severity "info" -id "LRcheckOK" -desc ( `
	#	"Windows Notification Service URLs required for Live Response are reachable.`r`n")
	#}
}

# Test for existence of unsupported ProcessMitigationOptions and dump IFEO
# Reference https://docs.microsoft.com/en-us/windows/security/threat-protection/override-mitigation-options-for-app-related-security-policies
Get-childItem -Recurse "HKLM:SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options" | Out-File "$resultOutputDir\SystemInfoLogs\IFEO.txt"
Get-Item "HKLM:SYSTEM\CurrentControlSet\Control\Session Manager\kernel" | Out-File "$resultOutputDir\SystemInfoLogs\SessionManager.txt"
if ((!$OSPreviousVersion) -and ($buildNumber -le "17134") -and ((Get-Service DiagTrack).Status -eq "StartPending")){
	If (Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" -Value "MitigationOptions") {
		Write-output "`r`n######################## ProcessMitigations check #########################" | Out-File $connectivityCheckFile -Append
		WriteMessage -severity "error" -id "ProcessMitigations" -desc ( `
		"DiagTrack service is unable to start. This may be caused by incompatible process MitigationOptions.`r`n" `
		+ "Note that certain Process Mitigation options may also cause the DiagTrack listener to appear as missing.`r`n" `
		+ "Please try removing registry settings from below path and check if the problem persists:`r`n" `
		+ "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel\MitigationOptions`r`n" `
		+ "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\svchost.exe\MitigationOptions`r`n" `
		+ "The current Kernel or SvcHost ProcessMitigation have been exported to MDATPClientAnalyzerResult\SystemInfoLogs directory for reference.`r`n")
		&Reg export "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" "$resultOutputDir\SystemInfoLogs\KernelProcessMitigation.reg" /y 2>&1 | Out-Null
		&Reg export "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\svchost.exe" "$resultOutputDir\SystemInfoLogs\SvchostProcessMitigation.reg" /y 2>&1 | Out-Null
	}	
}

# Test for existence of faulty EccCurves SSL settings and gather additional useful reg keys for troubleshooting
# Refernce https://docs.microsoft.com/en-us/windows-server/security/tls/manage-tls
$SSLSettings = "$resultOutputDir\SystemInfoLogs\SSL_00010002.txt"
$SCHANNEL = "$resultOutputDir\SystemInfoLogs\SCHANNEL.txt"
Get-ChildItem "HKLM:SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL" -Recurse -ErrorAction silentlycontinue | Out-File $SSLSettings
Get-ChildItem "HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL" -Recurse -ErrorAction silentlycontinue | Out-File $SCHANNEL
if ((Get-Content $SSLSettings) -like "*EccCurves : {}*") {
    WriteMessage -severity "warning" -id "EccCurvesFail" -desc ( `
		"Cloud connectivity may be impaired due to faulty EccCurves SSL settings.`r`n" `
        + "If you did not intend to modify the ECC curves, please remove these group policy settings:`r`n" `
		+ "https://docs.microsoft.com/en-us/windows-server/security/tls/manage-tls#managing-windows-ecc-curves-using-group-policy `r`n") 
} 

# Test if running on unsupported Windows 10 or 2012 RTM OS
if ((($OSProductName -match 'Windows 10') -and ($OSBuild -lt "14393")) -or ($OSBuild -eq "9200")) {
	Write-output "`r`n######################## Unsupported Win OS check #########################" | Out-File $connectivityCheckFile -Append
	WriteMessage -severity "error" -id "UnsupportedOS" -desc ( `
	"Please note the machine OS build is not supported by MDATP and cannot be onboarded: $OSBuild`r`n" `
	+ "Please refer to this article for a list of supported Windows versions: https://docs.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/minimum-requirements#hardware-and-software-requirements `r`n")
}

# Test for WSAEPROVIDERFAILEDINIT event related to LSP in netsh winsock catalog
if (!$OSPreviousVersion) {
	$EventError = Get-MatchingEvent Microsoft-Windows-UniversalTelemetryClient 29 "2147952506"
	if ($EventError) {
		Write-output "`r`n############################ Winsock error check ###############################" | Out-File $connectivityCheckFile -Append
		WriteMessage -severity "error" -id "ProviderInitFail" -desc ( `
		"Please note this machine has error ID WSAEPROVIDERFAILEDINIT in EventLogs\utc.evtx.`r`n" `
		+ "This may be caused by deprecated LSPs (Layered Service Providers) installed on the system.`r`n" `
		+ "Please review SystemInfoLogs\winsock_catalog.txt for any non-default LSPs which may be causing the issue`r`n" `
		+ "For more information on LSPs please refer to: https://docs.microsoft.com/en-us/windows/win32/winsock/categorizing-layered-service-providers-and-applications `r`n")
		$EventError | ft -Wrap | Out-File $connectivityCheckFile -Append
		$Winsock = &netsh winsock show catalog
		$winsock | Out-File $resultOutputDir\SystemInfoLogs\winsock_catalog.txt
		if ($winsock -like "*FwcWsp64.dll*") {
			WriteMessage -severity "error" -id "UnsupportedTMG" -desc ( `
			"Provider Initialization errors on this machine may be cause by no longer supported Forefront TMG Client Winsock LSP.`r`n" `
			+ "Please uninstall TMG firewall client from the affected machine and check if issue persists.`r`n")
		}
	}
}

# Dump FSUTIL USN queryjournal output to log
$DriveLetters = (Get-PSDrive -PSProvider FileSystem) | where {$_.Free -ne $null} | ForEach-Object {$_.Name}
Write-output "`r`n######################## FSUTIL USN journal query #########################" | Out-File $connectivityCheckFile -Append
foreach ($DriveLetter in $DriveLetters) {
    Write-output "USN query journal output for Drive: " $DriveLetter | Out-File $connectivityCheckFile -Append
    &fsutil usn queryjournal ("$DriveLetter" + ":") |  Out-File $connectivityCheckFile -Append
}

# Dump AddRemovePrograms to file
$uninstallKeys = Get-ChildItem HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall
$dstfile = "$resultOutputDir\SystemInfoLogs\AddRemovePrograms.csv"
GetAddRemovePrograms $uninstallKeys | Export-Csv -Path $dstfile -NoTypeInformation -Encoding UTF8
$uninstallKeysWOW64 = Get-ChildItem HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall -ErrorAction SilentlyContinue
$dstfileWOW64 = "$resultOutputDir\SystemInfoLogs\AddRemoveProgramsWOW64.csv"
if ($uninstallKeysWOW64) {
	GetAddRemovePrograms $uninstallKeysWOW64 | Export-Csv -Path $dstfileWOW64 -NoTypeInformation -Encoding UTF8
}

# Check if machine was onboarded using VDI script and dump relevant information
If (Get-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection\DeviceTagging" -Value "VDI") {
	Write-output "`r`n######################## VDI Information #########################" | Out-File $connectivityCheckFile -Append
	$StartupFolder = (get-ChildItem -Recurse -path $env:SystemRoot\system32\GroupPolicy\Machine\Scripts\Startup) 
	WriteMessage -severity "info" -id "NonPersistentVDI" -desc ( `
	"Machine was onboarded via VDI PowerShell Script. Please ensure best practices are implemented based on below articles: `r`n" `
	+ "https://docs.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/configure-endpoints-vdi `r`n" `
	+ "https://docs.microsoft.com/en-us/windows/security/threat-protection/windows-defender-antivirus/deployment-vdi-windows-defender-antivirus `r`n" `
	+ "Content of Startup folder will be logged below for reference:`r`n" `
	+ "$StartupFolder`r`n")
}

# Check for issues with certificate store or time skew
if (($OSPreviousVersion) -and (Test-Path -Path $env:SystemRoot\System32\'Winevt\Logs\Operations Manager.evtx')) {
	$EventError = Get-MatchingEvent "Service Connector" 3009 "80090016"
	if ($EventError) {
		Write-output "`r`n###################### MMA certificate error check #########################" | Out-File $connectivityCheckFile -Append
		WriteMessage -severity "error" -id "privateKeyFail" -desc ( `
		"Please note the machine has error 'Loading the private key for the client authentication certificate' in the OpsMgr log.`r`n" `
		+ "Please uninstall and re-install MMA (Microsoft Monitoring Agent) on this machine and check if the issue persists.")
		$EventError | ft -Wrap | Out-File $connectivityCheckFile -Append
	}
	$EventError = Get-MatchingEvent "Service Connector" 4002 "ClockSkew"
	if ($EventError) {
		Write-output "`r`n######################### Client TimeSkew check ############################" | Out-File $connectivityCheckFile -Append	
		WriteMessage -severity "error" -id "ClockSkewIssue" -desc ( `
		"The local time on the machine is not matching the time in Azure`r`n" `
		+ "Please check that the local system time is accurate and the correct time zone is set.`r`n" `
		+ "If this machine is domain joined, please ensure that the 'Windows Time' is running and the machine is synchronized with your domain time.`r`n" `
		+ "For more information on how to configure and control time synchronization please refer to:`r`n" `
		+ "https://docs.microsoft.com/en-us/windows-server/networking/windows-time-service/how-the-windows-time-service-works `r`n" `
		+ "If this machine is an offline standalone machine, please ensure local time in BIOS is accurate.")
		$EventError | ft -Wrap | Out-File $connectivityCheckFile -Append
	}
}

# Check for issues with Default paths or reg keys
# Taken from amcore/wcd/Source/Setup/Manifest/Windows-SenseClient-Service.man
$DefaultPaths = 
    @{
        Name = "Default MDATP Policies key"
        Path  = "HKLM:\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection"
    },
    @{
        Name = "Default MDATP Sensor Service key"
        Path  = "HKLM:\SYSTEM\CurrentControlSet\Services\Sense"
    },
        @{
        Name = "Default MDATP directory path"
        Path  = "$env:ProgramFiles\Windows Defender Advanced Threat Protection"
    },
        @{
        Name = "Default MDATP ProgramData directory path"
        Path = "$env:ProgramData\Microsoft\Windows Defender Advanced Threat Protection"
    },
        @{
        Name = "Default MDATP Cache directory path"
        Path  = "$env:ProgramData\Microsoft\Windows Defender Advanced Threat Protection\Cache"
    },
        @{
        Name = "Default MDATP Cyber directory path"
        Path  = "$env:ProgramData\Microsoft\Windows Defender Advanced Threat Protection\Cyber"
    },
        @{
        Name = "Default MDATP Temp directory path"
        Path  = "$env:ProgramData\Microsoft\Windows Defender Advanced Threat Protection\Temp"
    },
        @{
        Name = "Defalt MDATP Trace directory path"
        Path  = "$env:ProgramData\Microsoft\Windows Defender Advanced Threat Protection\Trace"
}
if ((!$OSPreviousVersion) -and (!$ARM)) {
	foreach ($item in $DefaultPaths) {
		if (!(Test-Path $item.Path)) {
			$MissingDefaultPath += $("`r`n" + $item.Name)
			$MissingDefaultPath += $("`r`n" + $item.Path + "`n")
		}
	}
	if ($MissingDefaultPath) {
		Write-Host -BackgroundColor Red -ForegroundColor Yellow "Default paths are missing. Please ensure the missing path(s) exist and have not been renamed:"
		Write-Host $MissingDefaultPath
		Write-output "`r`n###################### Missing default path check #########################" | Out-File $connectivityCheckFile -Append
		WriteMessage -severity "error" -id "MissingPaths" -desc ( `
		"Default paths are missing. Please ensure the missing path(s) exist and have not been renamed:`r`n" `
		+ "$MissingDefaultPath `r`n") 
	}
}

# Check if onboarding via SCCM failed due to registry issues
if (test-path -path $env:windir\ccm\logs\DcmWmiProvider.log) {
	$SCCMErr = Select-String -Path $env:windir\ccm\logs\DcmWmiProvider.log -Pattern 'Unable to update WATP onboarding' | Sort-Object CreationTime -Unique
	if ($SCCMErr) { 
		Write-output "`r`n############################ SCCM onboarding check ###############################" | Out-File $connectivityCheckFile -Append
		Copy-Item -path $env:windir\ccm\logs\DcmWmiProvider.log -Destination "$resultOutputDir\EventLogs\DcmWmiProvider.log"
		WriteMessage -severity "error" -id "SCCMOnboardFail" -desc ( `
        "This machine fails to onboard via Microsoft Endpoint Configuration Manager.`r`n" `
        + "This issue can happen if the regsitry key 'Windows Advanced Threat Protection' is missing from: HKLM:\SOFTWARE\Microsoft\`r`n See error information from: $SCCMErr`r`n") 
	}
}

# Check if onboarding via MMA failed due to unsupported OS env
if (Test-Path -Path $env:SystemRoot\System32\'Winevt\Logs\Operations Manager.evtx') {
	$EventError = Get-MatchingEvent "HealthService" 4509 "NotSupportedException"
	if ($EventError) {
		Write-output "`r`n########################## MMA unsupported OS check ##########################" | Out-File $connectivityCheckFile -Append
		WriteMessage -severity "error" -id "EnvNotSupported" -desc ( `
		"This machine attemped to onboard through Microsoft Monitoring Agent (MMA) agent but failed as it does not support onboarding using this method.`r`n" `
		+ "Please refer to our online documentation to understand what onboarding method is appropriate for this machine's Operating System:`r`n" `
		+ "https://docs.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/onboard-configure")
		$EventError | ft -Wrap | Out-File $connectivityCheckFile -Append
	}
}

# Check if running latest SCEP edition for downlevel OS
$SCEP = GetAddRemovePrograms $uninstallKeys | where { $_.DisplayName -like "*Endpoint Protection"}
if ($SCEP -And ("$env:ProgramFiles\Microsoft Security Client\")) {	
	if ([version](($SCEP).DisplayVersion) -lt [version]"4.10.209.0") {
		Write-output "`r`n############################ SCEP Client check ###############################" | Out-File $connectivityCheckFile -Append	
		WriteMessage -severity "error" -id "SCEPCompatIssue" -desc ( `
        "Machine is running an older version of System Center Endpoint Protection: $SCEP`r`n" `
        + "You should upgrade to latest available version to ensure compatbility and allow malware detections to be logged in Defender ATP security portal`r`n") 
	}
}

Write-output "`r`n################## MDATP CommandLine usage information ####################"  | Out-File $connectivityCheckFile -Append 
[environment]::GetCommandLineArgs() | Out-File $connectivityCheckFile -Append

# Dump DLP related policy information from registry
if ($DlpT -or $AppCompatC -or $DlpQ) {
	if ((!$OSPreviousVersion) -and ($OSBuild -ge 17763)) {
		New-Item -ItemType Directory -Path "$resultOutputDir\DLP" | out-Null
		if (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection" -Value dlpPolicy) {
			ShowDlpPolicy dlpPolicy
			ShowDlpPolicy dlpSensitiveInfoTypesPolicy
			$DLPlogs = Get-Item "$env:SystemDrive\DLPDiagnoseLogs\*.log" -ErrorAction SilentlyContinue
            if ($DLPlogs) {
                Move-Item -Path $DLPlogs -Destination "$resultOutputDir\DLP\"
            }
		} else {
		Write-output "No DLP polices found in the registry of this machine"| Out-File "$resultOutputDir\DLP\NoDlp.txt"
		}
	}
}

# Dump dsregcmd info to results
if (test-path -path $env:windir\system32\dsregcmd.exe) {
	&dsregcmd /status | Out-File "$resultOutputDir\SystemInfoLogs\dsregcmd.txt"
}

SaveXmlLog

# Check if MSinfo is still running and allow to run until timeout is reached
EndGet-MSInfo

[version]$PSMinVer = '2.0.1.1'
if ( $PSVersionTable.PSVersion -gt $PSMinVer) {
	Write-Host "Compressing results directory..."
	Add-Type -Assembly "System.IO.Compression.FileSystem";
    [System.IO.Compression.ZipFile]::CreateFromDirectory($resultOutputDir, $outputZipFile)
    Write-Host "Result is available at: " $outputZipFile
} else {
     Write-Host "Result is available at: " $resultOutputDir
}
#endregion  ::::: MAIN [Execution]-------------------------------------------------------#