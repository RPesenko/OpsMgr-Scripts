<# Script name: tss_Cluster_WriteEvtToAllNodes.ps1
Purpose: - write event $EventID into Application Event logs of all custer nodes
		 - Gather basic Cluster Info
#>

param(
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Choose EventID ')]
	[int32]$EventID = 5120
	,
	[Parameter(Mandatory=$False,Position=1,HelpMessage='Choose a writable output folder location, i.e. C:\Temp\ ')]
	[string]$DataPath = (Split-Path $MyInvocation.MyCommand.Path -Parent)
	,
	[Parameter(Mandatory=$False,Position=2,HelpMessage='Choose name of EventLog-File to be monitored' )]
	[string]$EventlogName #= "Application" #= "Microsoft-Windows-PowerShell/Operational" #"Microsoft-Windows-SmbClient/Connectivity"
)

$Script:HostName= $env:COMPUTERNAME 	# Get ComputerName of local machine
$ClusterNodes	= Get-ClusterNode 		# Get all cluster nodes
$EventSource	= "TSS-$EventID"		# Define source to be registered for writing EventID

" ...loop through all cluster nodes and write event $EventID into $EventlogName Event log"
ForEach($ClusterNode in $ClusterNodes){
	# Register the new Source TSS-EventID in Eventlog on each cluster Node
New-EventLog  -ComputerName $ClusterNode -LogName $EventlogName -Source $EventSource -ErrorAction SilentlyContinue 
	# Write Message TSS-Event to the Eventlog 
Write-host "Write-Eventlog -ComputerName $ClusterNode -LogName $EventlogName -Source $EventSource -EventId $EventID -EntryType Warning -Message ""TSS-Event - MS Custom EventLog Entry triggered by $HostName from script $($MyInvocation.MyCommand.Name)"""
Write-Eventlog -ComputerName $ClusterNode -LogName $EventlogName -Source $EventSource -EventId $EventID -EntryType Warning -Message "TSS-Event - MS Custom EventLog Entry triggered by $HostName from script $($MyInvocation.MyCommand.Name)"
}


# Lets gather some additional basic Cluster Info
function GatherClusterInfo{
  param(
    $ClusterName, # could be replaced by the Cluster Name as string to run remotely
    $ClusterNodes
  )
   " ...Start Gathering ClusterInfo"
  
  $C= New-Object PSObject -Property @{ # Create your own Object with your properties 
    Name=      $ClusterName
    CSV=      Get-ClusterSharedVolume
    CSVParm=    Get-ClusterSharedVolume | Get-ClusterParameter
    CSVState=    Get-ClusterSharedVolumeState
    Group=     Get-ClusterGroup
    Net=      Get-ClusterNetwork
    NIC=      Get-ClusterNetworkInterface
    Node=      Get-ClusterNode
    Param=     Get-Cluster -Name $ClusterName | fl *
    Quorum=     Get-ClusterQuorum
    Res=      Get-ClusterResource
  }
  # Export Cluster Info 
  $FileName= "$DataPath`\$($ClusterName.Name)`_$HostName`_ClusterInfo.XML"
  $C | Export-Clixml -Path $FileName
  
  # Create Dependency Reports and save to DataPath
  #$ClusterGroups= $C.Group
  #ForEach($ClusterGroup in $ClusterGroups){
  #  Get-ClusterResourceDependencyReport -Group $ClusterGroup -ErrorAction SilentlyContinue | Copy-Item -Destination "$DataPath\DependencyReports"
  #  Rename-Item -Path "$DataPath\DependencyReports\$($ClusterGroup.Id).htm" -NewName "$ClusterGroup-ClusGroupDependencyRep.htm" -ErrorAction SilentlyContinue
  #}

}

# GatherClusterInfo -ClusterName "."